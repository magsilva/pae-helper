#Exercicio 2:
class Palavras:

    # Funcao para inicializacao
    def __init__ (self, p=[]):
        self.palavra = p

    #Funcao que conta o nro de caracteres de cada palavra
    def conta_char (self):
        return len(self.palavra)


    #Funcao que conta o nro de ocorrencias de um dado caracter
    def conta_o_char (self, letra):
        return self.palavra.count(letra)

#Fim da Classe Palavras
#-----------------------------------------------------------------------------
#Exercicio 3:
class Tabela:
    #Funcao de inicializacao
    def __init__(self, M =[]):
        self.texto = M
        

    def quebra (self):
        self.palavras = []
        
        while self.texto.count(" "):        
            while self.texto[0] == (" "):
                self.texto = self.texto[1:]
            pal = self.texto[:self.texto.index(" ")]
            self.palavras.append(pal)
            self.texto = self.texto[self.texto.index(" ")+1:]
        self.palavras.append(self.texto)
        
    #Funcao conta palavras...
    def numero_palavra (self):
        
        maxlen = -1

        for i in range(0,len(self.palavras)):
            if len(self.palavras[i]) > maxlen:
                maxlen = len(self.palavras[i])

        while maxlen > 0:
            count = 0
            for i in self.palavras:
                x = Palavras(i)
                if x.conta_char() == maxlen:
                  count += 1
            if count:        
                print ("ha ", count, "palavras com ", maxlen, "letras")
            maxlen -= 1
#Fim da Classe Tabela
#------------------------------------------------------------------------------
L = Palavras("lagosta")
print L.palavra
print L.conta_char()
print L.conta_o_char("a")


temp = str(raw_input("Digite o texto e tecle <enter> quando terminar: "))
tab = Tabela(temp)
print tab.texto
tab.quebra()
print tab.palavras
tab.numero_palavra()
