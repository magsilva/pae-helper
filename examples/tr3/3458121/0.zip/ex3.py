#Exercicio 4:
import random

artigo = ('o','a','um', 'uma')
substantivo = ('gata','cao','cidade','carro', 'bicicleta')
verbo = ('andou','correu','pulou', 'caiu')
preposicao = ('de','sobre','sob', 'embaixo')

for i in range (0,20):
    temp = []
    temp = artigo[int(random.random()*len(artigo))] + " " + substantivo[int(random.random()*len(artigo))] + " " + verbo[int(random.random()*len(artigo))] + " " + preposicao[int(random.random()*len(artigo))] + " " + artigo[int(random.random()*len(artigo))] + " " + substantivo[int(random.random()*len(artigo))]+ "."
    temp = temp.capitalize()
    print temp

