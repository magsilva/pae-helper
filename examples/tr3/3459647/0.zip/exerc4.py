#exercicio 4 da lista
#chamada: a = Frases()
#         a.Gerar()

class Frases :
    def __init__(self) :
        self.artigo = ['o', 'a', 'um', 'uma']
        self.substantivo = ['gata', 'cao', 'cidade', 'carro', 'bicicleta', 'caixa', 'tomate']
        self.verbo = ['andou', 'correu', 'pulou', 'caiu', 'passou', 'se escondeu']
        self.preposicao = ['de', 'sobre', 'sob', 'ante','apos']

    def Gerar(self) :
        import random
        self.listafrases = []
        for n in range (0,20) :
            self.frase = ''
            self.frase = self.frase + random.choice(self.artigo) + ' '
            self.frase = self.frase + random.choice(self.substantivo) + ' '
            self.frase = self.frase + random.choice(self.verbo) + ' '
            self.frase = self.frase + random.choice(self.preposicao) + ' '
            self.frase = self.frase + random.choice(self.artigo) + ' '
            self.frase = self.frase + random.choice(self.substantivo) + '.'
            fraseupper = self.frase.capitalize()
            self.listafrases.append(fraseupper)
        for obj in self.listafrases :
            print obj
