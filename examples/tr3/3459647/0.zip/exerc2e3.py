#classe do exercicio 2 da lista
#chamada: a = Palavra('coisa')
#         a.conta_char()
#         a.conta_o_char('s')

class Palavra :
    def __init__(self, p='') :
        self.palavra = p

    def conta_char(self) :
        return len(self.palavra)

    def conta_o_char(self, char) :
        return self.palavra.count(char)


#programa do exercicio 3 da lista

c1 = 0
c2 = 0
c3 = 0
c4 = 0
c5mais = 0
print 'Digite o texto (entre com linha em branco para terminar):\n'
linha = raw_input()
while linha != '' :
    lstpalavras = linha.split(' ')
    for pal in lstpalavras :
        p = Palavra(pal)
        count = p.conta_char()
        if count == 1 :
            c1 += 1
        elif count == 2 :
            c2 += 1
        elif count == 3 :
            c3 += 1
        elif count == 4 :
            c4 += 1
        elif count >= 5 :
            c5mais += 1
    linha = raw_input()
print '\n\nNumero de Palavras com:\n'
print '1 letra: %d' %c1
print '2 letras: %d' %c2
print '3 letras: %d' %c3
print '4 letras: %d' %c4
print '5 ou mais letras: %d' %c5mais
