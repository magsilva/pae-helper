**********************************************
*                 Alunos                     * 
*      Santiago de Moura Luz 3560495         *
*    Marco Aurelio Rescia Alher 3560481      *
**********************************************

Lista de Exerc�cios

1) Responda objetivamente com suas palavras:

* Construtor de objetos � um m�todo que faz a instancia��o do objeto dentro de um 
programa. O objeto precisa ser instanciado (criado) para ser utilizado.
  Destrutor de objetos � um m�todo que desfaz a instancia��o do objeto dentro de um
programa. O objeto ser� destru�do (apagado) e n�o poder� mais ser utilizado.
  Para se criar o objeto o podemos apenas instancia-lo como:
  a=0 ou lista=[] que cria um objeto a com valor inteiro zero ou cria um objeto chamado
lista com valor de uma lista vazia.
  podemos criar utilizando def __init__(self) que faz a cria��o da classe inteira.
  Para destruir podemos apenas dar o comando del(nome do objeto)

* Formas de acesso: direto e indireto

* 5 conceitos:
	1- objetos e classes
	2- comunica��o com mensagens
	3- heran�a
	4- encapsulamento
	5- sobrecarga e polimorfismo

* Classe: � a defini��o de um conjunto de m�todos especificos com seus objetos 
espec�ficos. As classes permitem ao programador modelar objetows que tem atributos,
comportamento ou opera��es.
  Objeto: � uma abstra��o de algo cujas caracter�sticas e comportamento s�o conhecidos 
e que tem uma interface definida e restrita com entidades externas.	

* Vantagens de POO: A utiliza��o de POO permite aumentar a produtividade do 
programador com maior expansabilidade e reuso do software e controlar a complexidade 
e o custo de manuten��o do software.

******************************************************************************************

2) Programa: COnta numero de caracteres gerais e especificado

class palavras:
    def __init__(self,palavra):
        self.palavra=palavra
        
    def conta_char(self):
        return len(self.palavra)
    
    def conta_o_char(self,x):
        return self.palavra.count(x)


3) programa: Acessar frases do teclado e contar os caracteres
das palavras

class tabela:
    def __init__(self):
	self.resultado=[]
	self.lista=[]
	self.le()
	self.resultado=self.calcula()
	frase="      " + str(self.resultado[0]) + "         " + str(self.resultado[1]) + "          " + str(self.resultado[2]) + "          " + str(self.resultado[3]) + "          " + str(self.resultado[4]) + "            " + str(self.resultado[5])
	print('                         Tabela de resultados                        ')
	print('*********************************************************************')
	print('* 1 letra * 2 letras * 3 letras * 4 letras * 5 letras * mais letras *')
	print(frase)
	print('*********************************************************************')
	
    def le(self):
        numero=int(raw_input("Entre com o numero de linhas do texto: "))
        k=0
        while k < numero:
	    frase=raw_input('Frase: ')
	    self.lista.append(frase)
	    frase=''
	    k+=1

    def calcula(self):
	n1l=0
	n2l=0
	n3l=0
	n4l=0
	n5l=0
	nxl=0
	contador=0
	x=0
	k=0
	i=0
	tamanho=0
	res=[]
	numero=len(self.lista)
	while k < numero:
	    pal=palavras(self.lista[k])
	    tamanho = pal.conta_char()
            contador=0
	    while i < tamanho:
		if self.lista[k][i] <> ' ':
		    contador+=1
		elif self.lista[k][i] == ' ':
		    if contador == 1:
			n1l+=1
		    elif contador == 2:
			n2l+=1
		    elif contador == 3:
			n3l+=1
		    elif contador == 4:
			n4l+=1
		    elif contador == 5:
			n5l+=1
		    else:
			nxl+=1
		    contador=0
		i+=1
		if i==tamanho:
		    if contador == 1:
			n1l+=1
		    elif contador == 2:
			n2l+=1
		    elif contador == 3:
			n3l+=1
		    elif contador == 4:
			n4l+=1
		    elif contador == 5:
			n5l+=1
		    else:
			nxl+=1
		    contador=0
	    k+=1
	res = [n1l,n2l,n3l,n4l,n5l,nxl]
	return res




4) Programa: Montar frases com as listas dada

import random

class gera:
    def __init__(self):
        self.frases=[]
        self.artigo=["a","o","um","uma","as","os","uns"]
        self.subs=["pedra","papel","tesoura","beijo","mulher","sexo","ovo","programa","agua"]
        self.verbo=["eh","faz","ouve","ronca","dah","dorme","poe","canta","trabalha","acorda","fala"]
        self.prep=["de","ante","ateh","contra","para","contigo","aquem","em","embaixo","sobre","apos"]

	k=0
	n=0
	i=1
	string=''
	nstring=''
	
	while k<20:
	       p1 = random.choice(self.artigo)
	       p2 = random.choice(self.subs)
	       p3 = random.choice(self.verbo)
	       p4 = random.choice(self.prep)
	       p5 = random.choice(self.artigo)
	       p6 = random.choice(self.subs)

	       p1M = p1[0].upper()
	       n=len(p1)
	       nstring=p1M
	       while i < n:
		   nstring=nstring + p1[i]
		   i+=1
	       p1 = nstring

	       string =  p1 + ' ' + p2 + ' ' + p3 + ' ' + p4 + ' ' + p5 + ' ' + p6 + '.'
	       self.frases.append(string)
	       k+=1
	       
					    
