def lista34():
     import random
     import string
     
     tupla1 = ("o", "a","um","uma")
     tupla2 = ("gata", "cao", "cidade", "carro", "bicicleta")
     tupla3 = ("andou", "correu", "pulou","caiu")
     tupla4 = ("de", "sobre", "sob", "embaixo")
    
     n1 = len(tupla1)
     n2 = len(tupla2)
     n3 = len(tupla3)
     n4 = len(tupla4)
     result = ""

     for x in range(1,21):
        g = Random()
        num1 = g.randrange(1,n1)
        nome = string.capitalize(tupla1[num1])
        result += str(nome) + " "
        num2 = g.randrange(1,n2)
        result += str(tupla2[num2]) + " "
        num3 = g.randrange(1,n3)
        result += str(tupla3[num3]) + " "
        num4 = g.randrange(1,n4)
        result += str(tupla4[num4]) + " "
        num5 = g.randrange(1,n1)
        result += str(tupla1[num1]) + " "              
        num6 = g.randrange(1,n2)
        result += str(tupla2[num2]) + "." 

        print result
       
        result = ""
        
        


            
    

       
            
