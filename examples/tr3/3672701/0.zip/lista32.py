class palavra:
	lista = []
	def __init__(self, *palavras):
		for x in palavras:
			self.lista.append(x)
	def conta_char(self):
		for x in self.lista:
			print x
			print len(x)
	def conta_o_char(self, x):
                cont = 0
		for w in self.lista:
			for y in w:
				if y == x:
                                    cont += 1
                        print w
                        print cont
                        cont = 0



                        
