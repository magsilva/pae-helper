class palavra:
	def __init__(self, palavra):
                self.palavra = palavra		
	def conta_char(self):
		return (len(self.palavra))
	def conta_o_char(self, x):
                cont = 0
		for y in self.palavra:
		    if y == x:
                        cont += 1
                print self.palavra 
                print cont
                cont = 0
def lista33():
    lista2 = []
    lista = []
    cont = 0
    quant = 0
    i = 1
    result = ""
    s = raw_input("Digite o texto:  ")
    s += " "
    for x in s:
        if x != " ":
            result += str(x)
        else:
	    lista.append(result)
	    result = ""
    for i in range(1,20):
            for y in lista:
                c = palavra(y)
                if c.conta_char() == i:
                    quant += 1
                if (c.conta_char() == i) & (y not in lista2):
                    if cont == 0:
                        if i == 1:
                            print "Palavra(s) com %d letra: " %i
                            cont = cont + 1
                        else:
                            print "Palavra(s) com %d letras: "%i
                    print c.palavra
                    cont = cont + 1
                    lista2.append(y)
            if quant != 0:
                print "Total = %d" %quant
	    cont = 0
	    quant = 0


