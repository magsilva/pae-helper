#     Eduardo Carui, 3458604

class Palavras:
    def __init__(self, texto=""):
        self.palavra = texto

    def conta_char(self):
        return len(self.palavra)

    def conta_o_char(self, caracter):
        return self.palavra.count(caracter)
