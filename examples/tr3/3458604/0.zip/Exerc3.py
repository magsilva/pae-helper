#   Eduardo Carui, 3458604

tabela = []
linha = raw_input("Digite uma frase: ")
while linha != "":
    for i in range(1, 30):
        tabela.append(0)
    lista = linha.split(" ")
    for p in lista:
        palavra = Palavras(p)
        i = palavra.conta_char()
        tabela[i] += 1

    for i in range(1, 30):
        try:
            if tabela[i] != 0:
                print "Numero de palavras com " + str(i) + " caracteres: " + str(tabela[i])
        except:
            a = 0

    linha = raw_input("Digite uma frase: ")
    tabela = []
