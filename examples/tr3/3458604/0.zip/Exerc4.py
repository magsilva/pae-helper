#   Eduardo Carui, 3458604

class Frases:
    def __init__(self):
        self.artigo = ['o', 'a', 'um', 'uma']
        self.substantivo = ['gata', 'cachorro', 'cidade', 'bicicleta', 'onibus', 'Barrichelo']
        self.verbo = ['andou', 'correu', 'perdeu', 'pulou', 'caiu', 'entrou', 'mordeu', 'dormiu']
        self.preposicao = ['de', 'sobre', 'embaixo de', 'no meio de', 'em']
        self.frases = []
        self.monta_frase()

    def monta_frase(self):
        import random
        for i in range(0, 20):
            frase = ' '
            art1 = random.choice(self.artigo)
            art = art1.capitalize()
            sub1 = random.choice(self.substantivo)
            ver = random.choice(self.verbo)
            prep = random.choice(self.preposicao)
            art2 = random.choice(self.artigo)
            sub2 = random.choice(self.substantivo)
            frase = art + ' ' + sub1 + ' ' + ver + ' ' + prep + ' ' + art2 + ' ' + sub2 + '.'
            self.frases.append(frase)

        for obj in self.frases:
            print obj
        
