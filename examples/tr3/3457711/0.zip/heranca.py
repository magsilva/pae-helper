#!/usr/bin/python
# Aluno: Breno Leitao 3457711

import gc;



class quadrilatero:
	def __init__(self,p1,p2,p3,p4):
		self.x1 = p1[0];
		self.y1 = p1[1];
		self.x2 = p2[0];
		self.y2 = p2[1];
		self.x3 = p3[0];
		self.y3 = p3[1];
		self.x4 = p4[0];
		self.y4 = p4[1];

	def imprime_cordenadas(self):         #obsoleto
		print "(%2.2f,%2.2f) (%2.2f,%2.2f)\n(%2.2f,%2.2f) (%2.2f,%2.2f)"%(self.x1, self.y1, self.x2, self.y2, self.x3, self.y3, self.x4, self.y4); 

	def __str__(self):
		return "(%2.2f,%2.2f) (%2.2f,%2.2f)\n(%2.2f,%2.2f) (%2.2f,%2.2f)\n"%(self.x1, self.y1, self.x2, self.y2, self.x3, self.y3, self.x4, self.y4); 

class trapesio(quadrilatero):
	pass;
class paralelograma(quadrilatero):
	pass;
class retangulo(quadrilatero):
	def __init__(self, canto1,canto2):
		self.x1 = canto1[0];
		self.y1 = canto1[1];
		self.x2 = canto2[0];
		self.y2 = canto2[1];
		self.x3 = canto1[0];
		self.y3 = canto2[1];
		self.x4 = canto2[0];
		self.y4 = canto1[1];

q = quadrilatero([1,2],[3,2],[1,2],[3,10]);
r = quadrilatero([1,2],[3,2],[1,2],[3,10]);
p = paralelograma([1,2],[3,3],[10,11], [3, 3.1415]); 
t = paralelograma([2,2],[2,3],[10.1,1], [2.7182, 3.1415]); 
print q
#print
print r
#print
print p
#print
print t
