#!/usr/bin/python
#Exercicio 2.

import string;
import sys;
if (len(sys.argv) > 2): 
	word = sys.argv[1];
	letra = sys.argv[2];
else: 
	word = "Breno Leitao";
	letra = "o";

class palavra: 
	def __init__(self, word):
		self.palavra = word;
	def qtd_caracter(self):
		return len(self.palavra);
	def ocorrencia(self, char):
		return string.count(self.palavra, char);
		
	
a=palavra(word);
print "A quantidade de ocorrencia da letra '", letra, "' na palavra '", word, " ' eh :" ,  a.ocorrencia(letra);
print "o Total de caracter dessa palavra eh: %d"% a.qtd_caracter();

