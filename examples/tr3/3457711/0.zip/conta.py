#!/usr/bin/python
#Exercicio 2.

import pprint;
import string;
import fileinput
import sys;

array = [0,0,0,0,0,0,0,0,0,0];
def divide(line):
	lista = string.split(line);
	return lista

class palavra: 
	def __init__(self, word):
		self.palavra = word;
	def qtd_caracter(self):
		return len(self.palavra);
	def ocorrencia(self, char):
		return string.count(self.palavra, char);
		
	
print "Digite o texto e aperte ^D^D para terminar"
for line in fileinput.input():
	lista = divide(line);
	for x in lista: 
		tmp = palavra(x);
		qtd = tmp.qtd_caracter();
		if (qtd < 9):
			array[qtd-1] +=1;
		else :
			array[9] += 1;

print "qtd Caracter   |   Ocorrencia"
for i in range(1,10): 
  	print "%6d         |"%i, "%6d"%array[i-1];
	
print "     > 10      |   %4d "% array[9];


