#!/usr/bin/python
#autor: Breno Leitao

import string
from random import Random

artigo = ["o","um","a", "uma"]
substantivo = ["cao", "carro", "bicicleta","gata","cidade"]
verbo = ["andou", "correu", "pulou","caiu"]
preposicao = ["de", "sobre", "sob", "embaixo"]

g =  Random();             # Seed baseado no clock
oracao=[];

rand = g.randrange(0.0, 4.0);
oracao.append(artigo[rand]);


if (rand <2 ):          #Adicionando Concordancia verbal..
	rand  = g.randrange(0.0,2.0);
else: 
	rand = g.randrange(3.0, 5.0);
oracao.append(substantivo[rand]);

rand = g.randrange(0.0, 4.0);
oracao.append(verbo[rand]);

rand = g.randrange(0.0, 4.0);
oracao.append(preposicao[rand]);

rand = g.randrange(0.0, 4.0);
oracao.append(artigo[rand]);

if (rand <2 ):          #Adicionando Concordancia verbal..
	rand  = g.randrange(0.0,2.0);
else: 
	rand = g.randrange(3.0, 5.0);
oracao.append(substantivo[rand]);

string =  string.capitalize(oracao[0]) + " " + oracao[1] + " " + oracao[2] + " " + oracao[3] + " " + oracao[4] + " " +  oracao[5] + "."
print string

