#Marcelo Kenji Hotta 3460142    kenji@grad.icmc.usp.br



#2----------------------------------------------------------------------
class Palavras:
    def __init__(self, frase):
        self.list = []
        while frase.count(" "):
                while frase[0] == " ":
                    frase = frase[1:]
                self.list.append(frase[:frase.index(" ")])
                frase = frase[frase.index(" ") + 1:]
        self.list.append(frase)

    def Conta_char(self):
        result = []
        for x in self.list:
            print x, len(x), "letras"

    def Conta_o_char(self, char):
        print "Ocorrencias da letra", char, "\n"
        for x in self.list:
            cont = 0
            for y in range(len(x)):
                if x[y] == char:
                    cont = cont + 1
            print x,": ", cont

#3---------------------------------------------------------------------------
class Frases:
    def __init__(self):
        self.list = []
        self.Le_frases()

    def Le_frases(self):
        print "Escreva o texto, <ENTER> para terminar"
        linha = raw_input()
        while linha != "":
            self.list.append(linha)
            linha = raw_input()

def E3():  #para executar faca E3()
    Input = Frases()
    total = []
    for f in Input.list:
        tmp = Palavras(f)
        total.extend(tmp.list)
    print total
    
    maxlen = -1
    for p in total:
        if len(p) > maxlen:
            maxlen = len(p)
    
    while maxlen > 0:
        count = 0
        for p in total:
            if len(p) == maxlen:
                count += 1
        if count:
            print count, "palavras de", maxlen, "letras"
        maxlen -= 1
#4-------------------------------------------------------------------------
import random
def E4(): #para executar basta fazer:   E4()
    artigo = ("o", "a", "um", "uma")
    substantivo = ("gata", "cao", "cidade", "carro", "bicicleta")
    verbo = ("andou", "correu", "pulou", "caiu")
    preposicao = ("de", "sobre", "sob", "embaixo")
    
    for n in range(1, 20):
        temp = random.choice(artigo) + " " + random.choice(substantivo) + " " + random.choice(verbo) + " " + random.choice(preposicao) + " " + random.choice(artigo) + " " + random.choice(substantivo) + "."
#temp = artigo[int(random.random()*len(artigo))]    (ex: usando numero randomico)
        temp = temp.capitalize()
        print temp


#5---------------------------------------------------------------------
import copy
class ponto:
    def __init__(self, x, y):
        self.x = x
        self.y = y

class quadrilatero:
    def __init__(self, p1, p2, p3, p4):
        self.p1 = copy.deepcopy(p1)
        self.p2 = copy.deepcopy(p2)
        self.p3 = copy.deepcopy(p3)
        self.p4 = copy.deepcopy(p4)
        self.tipo = "quadrilatero"

class trapezio(quadrilatero):
    def __init__(self):
        self.tipo = "trapezio"

    

class paralelogramo(quadrilatero):
    def __init__(self):
        self.tipo = "paralelogramo"

class retangulo(paralelogramo):
    def __init__(self):
        self.tipo = "retangulo"

class quadrado(retangulo):
    def __init__(self):
        self.tipo = "quadrado"


p1 = ponto(0, 0)
p2 = ponto(2, 0)
p3 = ponto(4, 0)
p4 = ponto(6, 0)

p5 = ponto(0, 2)
p6 = ponto(2, 2)
p7 = ponto(4, 2)

p8 = ponto(4, 4)

#                   o
#
#
#
#   o       o-------o
#        __/         \__
#     __/               \__
#    /                      \
#   o-------o-------o--------o
quad1 = quadrilatero(p1, p4, p6, p7) #trapezio
quad1 = trapezio()

#                   o
#
#
#
#   o-------o-------o
#    \__             \__
#       \__             \__
#          \               \
#   o       o-------o-------o
quad2 = quadrilatero(p2, p4, p5, p7) #paralelogramo
quad2 = paralelogramo()


#                   o
#
#
#
#   o-------o-------o
#   |               |
#   |               |
#   |               |
#   o-------o-------o       o
quad3 = quadrilatero(p1, p3, p5, p7) #retangulo
quad3 = paralelogramo()
quad3 = retangulo()


#                   o
#
#
#
#   o-------o       o
#   |       |
#   |       |
#   |       |
#   o-------o       o       o
quad4 = quadrilatero(p1, p2, p5, p6) #quadrado
quad4 = paralelogramo()
quad4 = retangulo()
quad4 = quadrado()


#                ___o
#           ____/    \
#       ___/          \
#    __/               \
#   o       o       o   \
#   |                    \
#   |                     \
#   |                      \
#   o-------o-------o-------o
quad5 = quadrilatero(p1, p4, p5, p8) #quadrilatero


def E5():  #para executar faca: E5()
    print "figura 1 eh do tipo", quad1.tipo
    print "figura 2 eh do tipo", quad2.tipo
    print "figura 3 eh do tipo", quad3.tipo
    print "figura 4 eh do tipo", quad4.tipo
    print "figura 5 eh do tipo", quad5.tipo


