#exercicio 4

# Alunos :
# Alessndro G. Krempi
# Jonatas Kerr

class sentenca:

    T1 = ['a','o','um','uma']                        #Artigos
    T2 = ['gata','cao','cidade','carro']             #Substantivos
    T3 = ['andou','correu','pulou','caiu']           #Verbo
    T4 = ['de','sobre','sob','embaixo']              #Preposicao

    def gerador(self,seed=0):                        #Gera uma sequencia aleatoria de palavras
        for x in range(20):                          # 20 sentencas
            ind = []                                 #Indices aleatorios
            A = []                                   #Sentenca concatenada
            a = ' '                                  #Juncao
            s = ['','','','','','']                  #Srtrings da sentenca
            from random import Random
            h = Random()                             
	    seed = h.randint(0,1000)                 #Semente Randomica
	    g = Random(seed)
	    for i in range(6):
		  x = g.randint(0,3)                 #Indice randomico
		  g.jumpahead(10)
		  ind.append(x)
	    s = [T1[ind[0]],T2[ind[1]],T3[ind[2]],T4[ind[3]],T1[ind[4]],T2[ind[5]]] #Strings da sentenca
	    A.append(a.join(s))                      #Sentenca concatenada em A
	    print A[0].capitalize() + '.'            #Primeira Maiuscula e ponto final


print 'crie uma instancia da Classe sentenca :'
