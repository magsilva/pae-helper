# exercicio 2  e  3 (juntos)
# Alunos :
# Alessndro G. Krempi
# Jonatas Kerr


class Palavras :
   
  def __init__(self,strg = ''):
     
     print "digite uma palavra ou sentenca :"
     self.strg = raw_input() 
       
  def conta_char(self):             # Conta o numero de caracteres de uma palavra ou instancia
       a = ''                       # Juncao
       c = []                       # todos os caracteres da sentenca exceto espaco em branco
       A = []                       # todas as palavras da sentenca
       M = []                       # todos os tamanhos encontrados
       y = 0
       for i in range(len(self.strg)):
	if self.strg[i]<> ' ' :     # se nao for espaco em branco coloca em c
		c.append(self.strg[i])
	if (self.strg[i]==' ') or  (i ==len(self.strg)-1):# espaco em branco ou fim da sentenca
		A.append(a.join(c)) # forma cada palavra da sentenca
		c = []
       for i in range(len(A)) :
         x = len(A[i])
         M.append(x)                # Tamanhos obtidos 
       while len(M) <> 0:
         y = M[0]
         print "%d Palavra(s) com %d letra(s)" %(M.count(y),y)# imprime numero e qte de palavras
         while y in M :
           M.remove(y)             # remove todos do mesmo tipo
          
  def conta_o_char(self,sub):      #Conta numero de ocorrencias de um caractere
     return self.strg.count(sub)

print "crie uma instancia da Classe Palavras "
