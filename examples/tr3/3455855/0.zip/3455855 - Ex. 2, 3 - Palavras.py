class Palavras:
	"Classe para contar o numero de letras de cada palavra em uma senten�a e\
	o numero de ocorrencias de um caracter em uma palavra"

	def __init__(self, frase):
		#Armazena cada palavra da sente�a com um elemento de uma lista
		self.lista = []
		while frase.count(' '):
			self.lista.append(frase[:frase.index(' ')])
			frase = frase[frase.index(' ') + 1:]
		self.lista.append(frase)

	def Conta_char(self):
		#Conta o numero de caracteres em cada palavra da lista, retornando uma lista como resultado
		resultado = []
		for x in self.lista:
			resultado.append(len(x))
			#print len(resultado)
			resultado[-1] -= self.Conta_o_char(x, '.')
			resultado[-1] -= self.Conta_o_char(x, ',')
			resultado[-1] -= self.Conta_o_char(x, '!')
			resultado[-1] -= self.Conta_o_char(x, '?')
		return resultado

	def Conta_o_char(self, palavra, char):
		#Conta o numero de ocorrencias de um determinado caracter em uma palavra	
		cont = 0
		for x in range(len(palavra)):
			if palavra[x] == char:
				cont = cont + 1
		return cont

#Entrada do texto
texto = raw_input('Digite o texto: ')

#Declara o objeto
ob_pal = Palavras(texto)

#Inicia vetor para contagem dos valores da resposta
resposta = []
for x in range(11):
	resposta.append(0)

#Percorre o resultado obtido e soma os valores no vetor
for x in ob_pal.Conta_char():
	if x > 10:
		resposta[10] += 1
	else:
		resposta[x-1] += 1

#Imprime a resposta
for x in range(10):
	print resposta[x], 'palavras com', x+1, 'letras'
print resposta[10], 'palavras com mais de 10 letras'
		





