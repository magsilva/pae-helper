#Carrega a classe Random
from random import Random

#inicializa as tuplas
art = ('o', 'a', 'um', 'uma')
sub = ('gata', 'cao', 'cidade', 'carro', 'bicicleta')
verbo = ('andou', 'correu', 'pulou', 'caiu')
prep = ('de', 'sobre', 'sob', 'embaixo de')

#declara o objeto para gerar numeros aleatorios
r = Random()

print

#20 repeti��es...
for x in range(20):
    
    #string para a primeira palavra
    ini = art[(int)(r.random() * len(art))]

    #junta todas as strings
    frase = art[(int)(r.random() * len(art))].capitalize() + ' ' +\
            sub[(int)(r.random() * len(sub))] + ' ' +\
            verbo[(int)(r.random() * len(verbo))] + ' ' +\
            prep[(int)(r.random() * len(prep))] + ' ' +\
            art[(int)(r.random() * len(art))] + ' ' +\
            sub[(int)(r.random() * len(sub))] + '.'

    #imprime a frase
    print frase

