#Exercicio 2
#Exemplo de chamadas :
#a = Palavras('qualquerpalavra')
#a.Conta_char()
#a.Conta_o_char('qualquerletra')

class Palavras :
    def __init__(self,word) :
        self.palavra = word

    def Conta_char(self) :
        return len(self.palavra)

    def Conta_o_char(self,char) :
        return self.palavra.count(char)
    
#Exercicio 3
#Nao precisa de chamada.
#Eh soh seguir as instrucoes que aparecerao na tela

texto = raw_input('Digite um texto (linha vazia+<espaco>+<enter>=sair) : ')
letra1 = 0
letra2 = 0
letra3 = 0
letra4 = 0
letra5mais = 0
while texto != ' ' :
    palavras = texto.split(' ')
    for i in palavras :
        obj = Palavras(i)
        count = obj.Conta_char()
        if count == 1 :
            letra1 += 1
        elif count == 2 :
            letra2 += 1
        elif count == 3 :
            letra3 += 1
        elif count == 4 :
            letra4 += 1
        else :
            letra5mais += 1
    texto = raw_input()
print '1 letra - %d palavras' %letra1
print '2 letras - %d palavras' %letra2
print '3 letras - %d palavras' %letra3
print '4 letras - %d palavras' %letra4
print '5 ou mais letras - %d palavras' %letra5mais

