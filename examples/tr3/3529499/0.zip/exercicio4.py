#Exercicio 4
#Nao ha chamada.
#Eh soh "rodar" o script.
import random
artigo = ('o','a','um','uma','uns','umas')
substantivo = ('gata','cao','cidade','carro','biboca','mano','mane','mina')
verbo = ('andou','correu','pulou','caiu','voou','quebraram','zoaram')
preposicao = ('de','sobre','sob','embaixo','em cima')

i = 0
while i < 20 : 
    frase = random.choice(artigo).capitalize()
    frase += ' ' + random.choice(substantivo)
    frase += ' ' + random.choice(verbo)
    frase += ' ' + random.choice(preposicao)
    frase += ' ' + random.choice(artigo)
    frase += ' ' + random.choice(substantivo) + '.'
    i += 1
    print frase
