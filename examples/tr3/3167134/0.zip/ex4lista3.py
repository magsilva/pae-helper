def palavras:
    artigo=["o","a","os","as","um","uma"]
    substantivo=["gata","cao","cidade","carro","bicicleta"]
    verbo=["andou","pulou","correu","caiu","fugiu","lutou"]
    preposicao=["de","sobre","sob","embaixo"]

    indiceart=0
    indicesub=0
    indiceverb=0
    indiceprep=0
    indiceart=0
    indicesub=0

    while(indiceart<6):
        while(indicesub<5):
            while(indiceverb<6):
                while(indiceprep<4):
                    while(indiceart<6):
                        while(indicesub<5):
                            vetorfinal=[[artigo[indiceart]],[substantivo[indicesub]],[verbo[indiceverb]], [preposicao[indiceprep]],[artigo[indiceart]],[subtantivo[indicesub]]]
                            indicesub+=indicesub
                        indiceart+=indiceart
                    indiceprep+=indiceprep
                indiceverb+=indiceverb
            indicesub+=indicesub
        indiceart+=indiceart

        
