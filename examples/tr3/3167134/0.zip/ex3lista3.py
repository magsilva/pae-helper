class Palavras:

    def __init__(self):

        self.string = palavra

    def Conta_char(self):

        return len(self.string)

    def Conta_o_char(self, palavra):

        return self.palavra.count(palavra)


str1=raw_input()

vetorpalavra = []
vetornumero = []
str2=""

tamanho = Palavras.Conta_char(str1)

i = 0

while i<tamanho:

    if str[i]<>" ":
        str2 = str2 + str[i]
    else
        vetorpalavra[i]=str2
        str2=""

    i= i+1

i=0
while vetorpalavra<>"":
    vetornumero[0]
    



    
