class Palavras:

    def __init__(self):

        self.string = palavra

    def Conta_char(self):

        return len(self.string)

    def Conta_o_char(self, palavra):

        return self.palavra.count(palavra)


str1=raw_input()
print str1




    
