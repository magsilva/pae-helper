class palavras :

    def __init__(self, palavra):
        self.palavra=palavra

    def conta_char(self):
        nrochar=len(self.palavra)
        return(nrochar)

    def conta_o_char(self, caracter):
        nrocaracter=self.palavra.count(caracter)
        return nrocaracter
    
quantidade=[]
listaux=""
lista2=[]
i=0
frase=raw_input('Digite uma frase: ')
for caracter in frase:
    if caracter != ' ':
        listaux=str(listaux)+str(caracter)
    elif caracter == ' ':
        lista2.append(palavras(listaux))
        listaux=""
        i+=1
lista2.append(palavras(listaux))

for n in range(0,i+1):
    quantidade.append(lista2[n].conta_char())

for m in range(1,20):
    print "%d palavras com %d caracteres" % (quantidade.count(m),m)




   


    
    
        
    
