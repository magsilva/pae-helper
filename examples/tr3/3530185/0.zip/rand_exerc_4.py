import random
artigo=('o','a','um','uma')
substantivo= ('bicicleta', 'gato', 'cachorro','carro')
verbo=('atropelou','bateu', 'comeu', 'mordeu', 'caiu', 'correu')
preposicao=('de','sobre','sob', 'embaixo')

listasentenca=[]
sentenca=""
frase=""
for n in range(0,20):
    sentenca=""
    auxart1=random.choice(artigo)
    auxsub1=random.choice(substantivo)
    auxverb=random.choice(verbo)
    auxprep=random.choice(preposicao)
    auxart2=random.choice(artigo)
    auxsub2=random.choice(substantivo)
    sentenca=str(auxart1)+" "+str(auxsub1)+" "+str(auxverb)+" "+str(auxprep)+" "+str(auxart2)+" "+str(auxsub2)+"."
    listasentenca.append(sentenca)

for n in range(0,20):
    frase=str(listasentenca[n])
    print "%d) %s" %(n+1, frase.capitalize())
    
 
