from random import *
class Palavra:
    def __init__(self, word=""):
        self.palavra = word

    def Conta_char(self):
        return len(self.palavra)

    def Conta_o_char(self, letra):
        return self.palavra.count(letra)
    
    
class Le_linha:
    def __init__(self, nline= 0):
        i = 0
        self.lista = []
        self.dic = {}
        aux= ''
        while i < nline:
            a= raw_input("Digite Linha ")
            aux = a + '\n'
            self.lista.append(aux)
            i += 1


    def contador(self):
        aux_palavra = 0
        aux_str = ''
        for a in self.lista:
            for b in a:
                if b != ' ' and b != '\n':
                    aux_str += b
                else:
                    palavra = Palavra(aux_str)
                    aux_palavra = palavra.Conta_char()
                    aux_str = ''
                    self.monta_dic(aux_palavra)
        self.print_table()

    def monta_dic(self, indice):
        if indice in self.dic.keys():
            self.dic[indice] += 1
        else:
            self.dic.__setitem__(indice, 1)

    def print_table(self):
        for a in self.dic.keys():
            print ('N�mero de palavras com ' + str(a) + ' letra(s): ' + str(self.dic[a]))





class Sentence:
    def __init__(self):
        self.artigo = ('o','a','um','uma')
        self.substantivo = ('gata','cao','cidade','carro','bicicleta')
        self.verbo = ('andou','correu','pulou','caiu')
        self.preposicao = ('de','sobre','sob', 'embaixo de')

    def monta_sent(self):
        import math
        i = 0
        indice = 0
        frase = ''
        while i < 20:
            indice = randint(0, (len(self.artigo) - 1))
            frase += self.artigo[indice] + ' '
            indice = randint(0, (len(self.substantivo) - 1))
            frase += self.substantivo[indice]+ ' '
            indice = randint(0, (len(self.verbo) - 1))
            frase += self.verbo[indice]+ ' '
            indice = randint(0, (len(self.preposicao) - 1))
            frase += self.preposicao[indice]+ ' '
            indice = randint(0, (len(self.artigo) - 1))
            frase += self.artigo[indice]+ ' '
            indice = randint(0, (len(self.substantivo) - 1))
            frase += self.substantivo[indice]
            frase += '.'
            frase = frase.capitalize()
            print frase
            i += 1
            frase = '';

        
    

        
