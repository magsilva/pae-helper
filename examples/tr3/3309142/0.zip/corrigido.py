From stas@grad.icmc.usp.br Tue Apr  8 17:13:17 2003
Return-Path: <stas@grad.icmc.usp.br>
Received: from mail.grad.icmc.usp.br (lab3-01.grad.icmc.usp.br.231.107.143.in-addr.arpa [143.107.231.9] (may be forged))
	by mail.icmc.usp.br (8.12.9/8.12.9) with ESMTP id h38KF6sp019922;
	Tue, 8 Apr 2003 17:15:06 -0300 (EST)
Received: from mail.grad.icmc.usp.br (localhost [127.0.0.1])
	by mail.grad.icmc.usp.br (8.12.5/8.12.9) with ESMTP id h38KDIoe024569;
	Tue, 8 Apr 2003 17:13:18 -0300 (EST)
Received: (from www@localhost)
	by mail.grad.icmc.usp.br (8.12.5/8.12.9/Submit) id h38KDIJ4024568;
	Tue, 8 Apr 2003 17:13:18 -0300 (EST)
X-Authentication-Warning: mail.grad.icmc.usp.br: www set sender to stas@grad.icmc.usp.br using -f
Received: from 143.107.183.130 ( [143.107.183.130])
	as user stas@mail.grad.icmc.usp.br by mail.grad.icmc.usp.br with HTTP;
	Tue,  8 Apr 2003 17:13:17 -0300
Message-ID: <1049832797.3e932d5d30dd0@mail.grad.icmc.usp.br>
Date: Tue,  8 Apr 2003 17:13:17 -0300
From: stas@grad.icmc.usp.br
To: renata@icmc.usp.br
Cc: magsilva@icmc.usp.br
Subject: 3-a Lista de =?ISO-8859-1?B?RXhlcmPtY2lvcyBQcg==?==?ISO-8859-1?B?4XRpY29zIGRlIFBPTw==?=
MIME-Version: 1.0
Content-Type: text/plain;
  charset=ISO-8859-1
Content-Transfer-Encoding: 8bit
User-Agent: Internet Messaging Program (IMP) 3.1
X-Originating-IP: 143.107.183.130
Status: RO
X-Status: U
X-KMail-EncryptionState:  
X-KMail-SignatureState:  

3-a Lista de Exerc�cios Pr�ticos de POO
=======================================

Alunos:
Stanislaw Y. Pusep, #3309142
Diego Augusto Negrelli Gomes, #3309055


1)
  * Construtor � m�todo especial utilizado para instanciar objetos novos.
    Destrutor remove os objetos da mem�ria operacional. Para criar um
    construtor em Python deve-se definir o m�todo '__init__' na classe
    desejada com par�metro 'self':

	class Teste:
	def __init__(self):
		pass

    O destrutor empregado em Python � autom�tico; quando n�o h�
    refer�ncias para um dado objeto ele � removido pelo pr�prio
    Python.

  * Utilizam-se m�todos especializados para ler e escrever vari�veis
    da classe e ocasionalmente m�todos interntos ao Python como
    __getattr__ e __setattr__
  * Polimorfismo, Heran�a, Encapsulamento, Sobrecarga, Instancia��o
  * Classe � uma forma de instanciar estruturas de dados.
    Objetos s�o inst�ncias de uma classe.
    M�todos de uma classe servem para ler e escrever atributos de objetos
    e classes.
  * A vantagem principal � redu��o do "gap sem�ntico". Outra vantagem
    � que em v�rios problemas a t�cnica de abstrair objetos aumenta a
    flexibilidade e compreensibilidade do c�digo.

2)

import string

class Palavras:
    def __init__(self, str):
        self.string = str

    def Conta_char(self):
        return len(self.string)

    def Conta_o_char(self, chr):
        return string.count(self.string, chr)

3)

import string

class Palavras:
    def __init__(self, str):
        self.string = str

    def Conta_char(self):
        return len(self.string)

    def Conta_o_char(self, chr):
        return string.count(self.string, chr)

conta = {}

while (1):
    linha = raw_input("entre com linha (<ENTER> sai): ")
    if linha == '':
        break
    palavras = string.split(linha)
    for palavra in palavras:
        a = Palavras(palavra)
        n = a.Conta_char()
        if not conta.has_key(n):
            conta[n] = 1
        else:
            conta[n] += 1

for i in conta.keys():
    print i, conta[i]

4)

import random

art = ('o', 'a', 'um', 'uma')
sub = ('gata', 'cao', 'cidade', 'carro', 'bicicleta')
ver = ('andou', 'correu', 'pulou', 'caiu')
prp = ('de', 'sobre', 'sob', 'embaixo')

def rnd(t):
    return random.choice(t)

for i in range(1, 20):
    print rnd(art)+' '+rnd(sub)+' '+rnd(ver)+' '+rnd(prp)+' '+rnd(art)+' '+rnd
(sub)


-------------------------------------------------
This mail sent through IMP: http://horde.org/imp/


