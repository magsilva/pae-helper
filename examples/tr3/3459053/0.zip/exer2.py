class Palavras:
    def __init__(self,palavrasx):
        self.palavra = palavrasx
        
    def Conta_char(self):
        return self.palavra.__len__()
    
    def Conta_o_char(self,chr):
        return self.palavra.count(chr)

print 'Entre com uma palavra:'
pal = raw_input()
print 'Entre com um caracter:'
chr = raw_input()
plv = Palavras(pal)
print 'Numero de caracteres:',plv.Conta_char()
print 'Numero de ocorrencias de %c em %s: %d'%(chr,plv.palavra,plv.Conta_o_char(chr))
