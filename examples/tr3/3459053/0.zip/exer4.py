import random

artigo = ('o','a','um','uma')
substantivo = ('gata','cao','cidade','carro','bicicleta')
verbo = ('andou','correu','pulou','caiu')
preposicao = ('de','sobre','sob','embaixo')

ra = range(len(artigo))
rs = range(len(substantivo))
rv = range(len(verbo))
rp = range(len(preposicao))

for i in range(1,20):
    frase = []
    frase.append(artigo[random.choice(ra)])
    frase.append(' ')
    frase.append(substantivo[random.choice(rs)])    
    frase.append(' ')
    frase.append(verbo[random.choice(rv)])
    frase.append(' ')
    frase.append(preposicao[random.choice(rp)])    
    frase.append(' ')
    frase.append(artigo[random.choice(ra)])    
    frase.append(' ')
    frase.append(substantivo[random.choice(rs)])    
    frase.append('.')
    texto = frase[0][0].upper()
    for j in range(0,12):
        if j == 0:
            texto += frase[0][1:]
        else:
            texto += frase[j]
    print texto

