class Palavras:
    def __init__(self,palavrasx):
        self.palavra = palavrasx
        
    def Conta_char(self):
        return self.palavra.__len__()
    
    def Conta_o_char(self,chr):
        return self.palavra.count(chr)

print 'Entre com o texto:'
texto = raw_input()
pal = texto.split(' ') #lista que contem todas as palavras do texto e que
                       #depois armazenara o tamanho dessas palavras

i = 0    #inicializando indice da lista pal=[]
while i < len(pal):
    plv = Palavras(pal[i]) #instanciando objeto
    pal[i] = plv.Conta_char()
    i+=1
    
i = 1
while i <= max(pal):
    print "Numero de palavras com %d letras e' %d" %(i,pal.count(i))
    i+=1
