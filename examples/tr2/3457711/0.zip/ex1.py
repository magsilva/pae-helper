#!/usr/bin/python
#alunos: Breno Leitao  3457711
#        Jonatas Oliveira 3457774

class inte:
	def __init__(self):
		self.lista = []

	def add(self,x):
		if x not in self.lista:
			self.lista.append(int(x))

	def remove(self, numero):
		if numero in self.lista:
			del self.lista[self.lista.index(numero)]		

	def imprime(self):
		print  "lista: ", self.lista 

	def uniao(self, classe):
		for x in classe.lista: 
			if x not in self.lista:
				self.lista.append(x)

	def interseccao(self, classe):
		for x in self.lista:
			if x not in classe.lista:
				self.remove(x)

	def uniao(self, classe):
		for x in classe.lista:
			if x not in self.lista:
				self.add(x)
			



a = inte()
a.add(2)
a.add(4)
b = inte()
b.add(3)
b.add(4)
#a.interseccao(b)
a.uniao(b)
a.imprime()

