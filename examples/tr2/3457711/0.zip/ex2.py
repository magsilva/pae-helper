#!/usr/bin/python
#alunos: Breno Leitao 3457711 Jonatas Kerr 3457774
import string


def verifica_tag(linha):
	erro = 0
	tags = 0;
	fecha = 0
	for i in range(0,len(linha)):
		if (linha[i] == "<") and (fecha != 1): # <Hello>
			fecha = 1
		if (linha[i] == ">") and (fecha != 1): # <>>
			erro +=1;
			fecha = 0;
		if (linha[i] == ">") and (fecha == 1): #Situacao perfeita
			fecha = 0;
			tags +=1;
		if (linha[i] == "<") and (fecha == 1): # <body<title> 
			erro +=1;
			
			

	return [erro-tags, tags]  #Eis a carta na manga

member = []
file = open("file.tag","r")
i = 0;
while 1: 
	i +=1;
	text = file.readline()
	if text == "":
		break 
	lista_palavras = string.split(text," ") 
 	lista_tags = string.split(text, "<")	
	lista_tags = lista_tags[1:]
	Socatres = verifica_tag(text);
#	if string.count(text, '<') == string.count(text, '>'):
#		print "Tags perfeitas" 
#	else:
#		print "Tags com problemas" 

	print "linha " , i , " com ", len(lista_palavras) , " palavras ", Socatres[1], "tags e", Socatres[0], " erros"  

	verifica_tag(text)

