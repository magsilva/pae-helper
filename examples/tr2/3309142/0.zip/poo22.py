import string
class arquiv:
	def __init__(self):
		self.l=file.readlines(file("entrada.dat","r"))
	def trunca(self):
		self.n = 0
		for i in self.l:
			self.tags = 0
			self.problema = 0
			self.contagem = 0
			for j in string.split(i, ):
				p = string.find(j,"<")
				if p <> -1:
					if string.find(j,">",p) <> -1:
						self.tags += 1
					else:
						self.problema += 1

				self.contagem += 1
			self.n += 1
			self.result(self.n)
	def result(self, a):
		temp=file("saida.dat","a")
		linhaboa = "Linha " + str(a) + " - Numero de palavras: " + str(self.contagem) + " - <TAGS>: " + str(self.tags) + " - Linhas com problema: " + str(self.problema) + "\n"
		file.write(temp,linhaboa)
		file.close(temp)
		#print "Linha ",a," - Numero de palavras: ",self.contagem," - <TAGS>: ",self.tags, " - Linhas com problema: ",self.problema


a = arquiv()
a.trunca()
