import copy
class CInt:
	# construtor de classe
	def __init__(self, l):
		self.lista = []
		tmp = copy.deepcopy(l)
		for i in l:
			count = 0
			for j in tmp:
				if i is j:
					count += 1
			if count > 1:
				print "mais de 1 referencia ao mesmo objeto"
				return
		self.lista = l

	# adi��o
	def __add__(self, e):
		if type(e) == type(1):
			self.lista.append(e)
		else:
			print "tipo invalido"
			return
		count = 0
		for i in self.lista:
			if i is e:
				count += 1
		if count > 1:
			print "objeto ja esta no conjunto"
			return

	# remo��o
	def __sub__(self, e):
		count = 0
		for i in self.lista:
			if i == e:
				count += 1
		if count == 0:
			print "objeto a ser removido nao esta na lista"
			return
		self.lista.remove(e)

	# une com outro conjunto
	def uniao(self, conj):
		tmp = []
		for i in conj.lista:
			if self.lista.count(i) == 0:
				tmp.append(i)
		for j in tmp:
			self.lista.append(j)

	# interseccao
	def inter(self, conj):
		tmp = []
		for i in conj.lista:
			if self.lista.count(i) <> 0:
				tmp.append(i)
		return tmp

	# subtracao
	def subtr(self, conj):
		tmp = []
		for i in self.lista:
			if conj.lista.count(i) == 0:
				tmp.append(i)
		return tmp

	# imprime o conjunto
	def dump(self):
		for i in self.lista:
			print i


a = CInt([1, 2, 3, 4])
b = CInt([3, 4, 5, 6])
