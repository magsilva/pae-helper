class ConjuntoInteiros:

    def adicionar(self, numero):
        if type(numero) is type(0):
            if not numero in self.dados:
                self.dados.append(numero)

    def remover(self, numero):
        if numero in self.dados:
            self.dados.remove(numero)

    def unir(self, conjunto):
        if type(conjunto) is type(self):
            for numero in conjunto.dados:
                if not numero in self.dados:
                    self.dados.append(numero)

    def subtrair (self, conjunto):
        if type(conjunto) is type(self):
            for numero in conjunto.dados:
                if numero in self.dados:
                    self.dados.remove(numero)

    def inter (self, conjunto):
        intersec = []
        if type(conjunto) is type(self):
            for numero in conjunto.dados:
                if numero in self.dados:
                    intersec.append(numero)
        return intersec
    
    def __init__ (self, *numeros):
        self.dados = []
        for numero in numeros:
            if type(numero) is type(0):
                self.adicionar(numero)
            elif type(numero) is type(self):
                self.unir(numero)