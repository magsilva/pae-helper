class Tag:
    def __init__ (self):
        self.tag = ""
        
    def settag(self, incometag):
        self.tag = incometag
 
class Palavra:
    def __init__ (self):
        self.palavra = ""
        
    def setword(self, word):
        self.palavra = word
 
class Frase:
    def __init__ (self):
        self.frase = []
        self.taglist = []
        self.wordcount = 0
        self.tagcount = 0
        self.badtagcount = 0
       
    def addword (self, word):
        self.frase.append(word)
        self.wordcount+= 1
    def addtag (self, tag):
        self.frase.append(tag)
        self.taglist.append(tag)
        self.tagcount+= 1
        self.wordcount+= 1
    def addbadtag (self, badtag):
        self.frase.append(badtag)
        self.badtagcount+= 1
        self.wordcount+= 1
 
    def getwordcount (self):
        return self.wordcount
    def gettagcount (self):
        return self.tagcount
    def getbadtagcount (self):
        return self.badtagcount
 
def readfileout(filename, outputfile):
    fp = open(filename, 'r')
    ofp = open(outputfile, 'w')
 
    linecounter = 1
    lin = fp.readline()
    while (lin != ""):            
        fr = Frase()
        worditself = Palavra()
        atag = Tag()
 
        word = ""
        wordlist = lin.split()
        wn = len(wordlist)
        wcount = wn
        while (wn):
            word = wordlist[wcount - wn]
            if (word[0] == '<') and (word[len(word)-1] == '>'):
                atag.settag(word)
                fr.addtag(word)
            elif (word[0] == '<') and (word[len(word)-1] != '>'):
                worditself.setword(word)
                fr.addbadtag(word)
            else:
                worditself.setword(word)
                fr.addword(word)
            wn -= 1
        ofp.write ("linha %d - " % linecounter)
        ofp.write (" %d palavras - " % fr.getwordcount())
        ofp.write ("%d tags (" % fr.gettagcount())
        
        n = fr.gettagcount()
        while (n):
            ofp.write ("%s" % fr.taglist[fr.gettagcount()-n])
            if (n > 1):
                ofp.write (", ")
            n-= 1
        ofp.write (") - %d tags-problema\n" % fr.getbadtagcount())
 
        linecounter = linecounter + 1
        lin = fp.readline()
 
        del fr
        del worditself
 
    fp.close()
    ofp.close()