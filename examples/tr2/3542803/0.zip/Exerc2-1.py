class ConjuntoInteiros:
    def __init__(self, *initlist):
        self.CIlist = []
        for element in initlist:
            if (type(element) == type(0)):
                self.add(element)
            elif (type(element.CIlist) == type([])):
                for element2 in element.CIlist:
                    self.add(element2)
 
    def add(self, newitem):
        if (type(newitem) == type(0)):
            dontadd = 0
            for element in self.CIlist:
                if (newitem == element):
                    dontadd = 1
            if (dontadd == 0):
                self.CIlist = self.CIlist + [newitem]
        else:
            print 'Erro >> Inteiro esperado'
        
    def rem(self, remitem):
        if (type(remitem) == type(0)):
            self.CIlist.remove(remitem)
 
    def __str__(self):
        return "CI=" + str(self.CIlist)
            
def CIuni(CI1, CI2):
    CIRet = ConjuntoInteiros(CI1, CI2)
    return CIRet
 
def CIsub(CI1, CI2):
    CIRet = ConjuntoInteiros(CI1)
    for element in CI1.CIlist:
        for element2 in CI2.CIlist:
            if (element == element2):
                CIRet.rem(element)
    return CIRet
 
def CIint(CI1, CI2):
    CIRet = ConjuntoInteiros()
    for element in CI1.CIlist:
        for element2 in CI2.CIlist:
            if (element == element2):
                CIRet.add(element)
    return CIRet