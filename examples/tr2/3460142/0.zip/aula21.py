#Marcelo Kenji Hotta 3460142


#2.1
class conj:
    #inicializa
    def __init__ (self, *elem):
        self.lista=[]
        for num in elem:
            self.add(num)

    #adiciona elemento na lista
    def add (self, num):
        if type(num) == int:
            if num in self.lista:
                print "Elemento jah incluido: %i" %num
            else: 
                self.lista.append(num)
                print "Elemento %i incluido" %num
        elif num.__class__ == conj:
            for x in num.lista:
                self.add(x)
        else:
            print "Elemento invalido: %s" %num


    #remove elemento da lista
    def rem (self, num):
        if num in self.lista:
            self.lista.remove(num)
            print "Elemento %s removido" %num
        else:
            print "Elemento %s nao encontrado" %num

    #conj+conj=uniao
    def __add__(self, elem):
        import copy
        uniao=copy.deepcopy(self.lista)
        for num in elem.lista:
            if num not in uniao:
                uniao.append(num)
        return uniao
            
    #conj/conj=interseccao
    def __div__(self, elem):
        inter=[]
        for num in self.lista:
            if num in elem.lista:
                inter.append(num)
        return inter

    #conj-conj=subtracao
    def __sub__(self, elem):
        import copy
        sub=copy.deepcopy(self.lista)
        for num in elem.lista:
            if num in sub:
                sub.remove(num)
        return sub
            
    #imprime os elementos da lista
    def imprime (self):
        print self.lista
        



#----------------------------------------------------
