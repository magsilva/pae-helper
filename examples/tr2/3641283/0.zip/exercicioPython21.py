import copy
class ConjuntoInteiros:
	def __init__(self, l):
		self.lista = []
		tmp = copy.deepcopy(l)
		for i in l:
			count = 0
			for j in tmp:
				if i is j:
					count += 1
			if count > 1:
				print "Objeto com mais de uma referencia"
				return
		self.lista = l
	def __add__(self, e):
		if type(e) == type(1):
			self.lista.append(e)
		else:
			print "Tipo Invalido"
			return
		count = 0
		for i in self.lista:
			if i is e:
				count += 1
		if count > 1:
			print "Objeto Existente"
			return
	def __sub__(self, e):
		count = 0
		for i in self.lista:
			if i == e:
				count += 1
		if count == 0:
			print "Objeto nao existe"
			return
		self.lista.remove(e)
	def uniao(self, conj):
		tmp = []
		for i in conj.lista:
			if self.lista.count(i) == 0:
				tmp.append(i)
		for j in tmp:
			self.lista.append(j)
	def inter(self, conj):
		tmp = []
		for i in conj.lista:
			if self.lista.count(i) <> 0:
				tmp.append(i)
		return tmp
	def subtr(self, conj):
		tmp = []
		for i in self.lista:
			if conj.lista.count(i) == 0:
				tmp.append(i)
		return tmp
	def dump(self):
		for i in self.lista:
			print i


a = ConjuntoInteiros([1, 2, 3, 4])
b = ConjuntoInteiros([3, 4, 5, 6])
