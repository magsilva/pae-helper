#	Exercicio 2.2
#
#		Feito por: Rafael Henrique Manoel
#			   Monica Ribeiro Porto Ferreira
#---------------------------------------------------------------------

import copy
class Texto:

	def __init__(self, nome_arq):
		self.arq = open(nome_arq, "r")
		self.texto = self.arq.read()
		self.lista_frases = []

	def quebra_frases(self):
		texto_buf = self.texto
		inicio = fim = 0
		buf = Frase()
		a = Frase()
		while 1:
			texto_buf = buf.atribui(texto_buf)
			if buf.texto == "":
				break
			a = copy.deepcopy(buf)
			self.lista_frases.append(a)

	def exibe_relatorio(self):
		i = 0
		fim = len(self.lista_frases)
		while i < fim:
			print "Linha %d - "%i,
			self.lista_frases[i].quebra_em_palavras()
			self.lista_frases[i].exibe_resultado()
			i +=1 
	

class Frase:
	def __init__(self):
		self.texto = ""
		self.n_palavras = 0
		self.n_tags = 0
		self.n_tags_defeito = 0
		self.tamanho = 0
		self.lista_tags = []

	def atribui(self, nova_frase):
		fim = nova_frase.find("\n")
		self.tamanho = len(nova_frase)

		if fim==-1:
			self.texto = nova_frase
			return ""
		else:
			self.texto = nova_frase[0:fim]
			return nova_frase[fim+1:len(nova_frase)]

	def quebra_em_palavras(self):
		p = Palavra()
		t = Tag()
		inicio = 0
		fim = 0

		while fim <> -1:
			fim = self.texto.find(" ",inicio)
			if fim == -1:
				result = t.atribui(self.texto[inicio:self.tamanho])
			else:
				result = t.atribui(self.texto[inicio:fim])
			inicio = fim+1		
			#tag certa
			if result > 0:
				#adicionando como str na lista para
				#facilitar na impressao
				self.lista_tags.append(t.texto)
				self.n_tags += 1
			#tag com problema
			elif result < 0:
				self.n_tags_defeito += 1		
			#nao eh tag
			else:
				p.atribui = t.texto

			self.n_palavras += 1

	def exibe_resultado(self):
		print self.n_palavras, "palavras - ", self.n_tags, "(", self.lista_tags, ") - ", self.n_tags_defeito, "tags-problema"
		

	def __len__(self):
		return len(self.texto)

	def imprime(self):
		print self.texto

class Palavra:

	def __init__(self):
		self.texto = ""

	def atribui(self):
		return self.texto

	def __len__(self):
		return len(self.texto)


class Tag(Palavra):

	texto = ""

	def atribui(self, palavra):
		if palavra[0] == '<' and palavra[len(palavra)-1] == '>':
			self.texto = palavra
			#tudo certo
			return 1
		elif palavra[0] == '<' or palavra[len(palavra)-1] == '>':
			self.texto = palavra
			#tag com defeito
			return -1
		else:
			#naum eh tag
			return 0		
		

#fim das definicoes de classe			
			

#altere a localizacao do arquivo
a = Texto("c:/a.txt")
a.quebra_frases()
a.exibe_relatorio()


