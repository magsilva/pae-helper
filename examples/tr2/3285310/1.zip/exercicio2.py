#Exercicio 2.1##########################################
#                                                      #
#   Feito por:                                         #
#               Rafael Henrique Manoel          3285310#
#               Monica Ribeiro Porto Ferreira   3458121#
########################################################

class ConjuntoInteiros:

    #funcao para inicializacao
    def __init__(self, Lista=[]):
        self.elementos = []
        tamanho_lista = len(Lista)
        i = 0
        while i < tamanho_lista:
            self.insere(Lista[i])
            i+=1

    #funcao que insere na classe
    def insere(self, X):
        nX = self.elementos.count(X)
        if nX == 0:
            self.elementos.append(int(X))

    #funcao que remove do conjunto
    def remove(self, X):
        if self.elementos.count(X) > 0:
            self.elementos.remove(X)

    #sobrecarga de funcoes para poder usar o polimorfismo
    def __len__(self):
        return len(self.elementos)

    def __getitem__(self, i):
        return self.elementos[i]
    #fim sobrecarga

    #uniao de conjuntos
    def __add__(self, cjB):
        i = 0
        tamanho_cjB = len(cjB)
        result = ConjuntoInteiros(self)
        while i < tamanho_cjB:
            result.insere(cjB[i])
            i+=1
        return result

    #interseccao
    def __mul__(self, cjB):
        i,j=0,0
        size_self, size_cjB = len(self), len(cjB)
        result = ConjuntoInteiros()
        while i < size_self:
            while j < size_cjB:
                if self[i] == cjB[j]:
                    result.insere(cjB[j])
                j+=1
            j=0
            i+=1 
        return result

    #subtracao
    def __sub__(self, cjB):
        i,j=0,0
        size_self, size_cjB = len(self), len(cjB)
        result = ConjuntoInteiros(self)
        while i < size_self:
            while j < size_cjB:
                if self[i] == cjB[j]:
                    result.remove(cjB[j])
                j+=1
            j=0
            i+=1 
        return result

    def imprime(self):
        print self.elementos
        
#Fim da classe

        
        

L = [1,2,3,4]
a = ConjuntoInteiros(L)
b = ConjuntoInteiros()
b.insere(5)
b.insere(6)
b.insere(7)
b.insere(2)
c = ConjuntoInteiros(a)
c.insere(90)
d = ConjuntoInteiros()
e = ConjuntoInteiros()
d.insere(2)
d.insere(3)

                

    
