class conj:
    def __init__(self,*z):
        #inicializa o objeto com parametros arbitrarios
        self.lista=[]
        for j in z:
            if type(j) ==int:
                self.push(j)
            elif j.__class__ == conj:
                self.lista.extend(j.lista)
                print "Objeto Inserido"
            else:
                print "Parametro Invalido"
            
    def push(self,x):
        #insere elemento x no objeto
        if (type(x)==int):
            if self.lista.count(x) < 1 :
                self.lista.append(x)
                print "Numero %d Inserido"%x
            else:
                print "Numero Repetido"
        else:
            print "Somente Numeros Inteiros"

    def pop(self,x):
        #remove elemento x do objeto
        if x in self.lista:
            self.lista.remove(x)
            print "Elemento removido"
        else:
            print "O elemento nao esta na lista"

    def imprime(self):
        #imprime a lista do objeto
        print self.lista

    def __add__(self,obj2):
        #retorna uniao de dois objetos
        import copy
        laux=copy.deepcopy(self.lista)
        for aux in obj2.lista:
            if aux not in laux:
                laux.append(aux)
        return laux

    def __div__(self,obj2):
        #retorna interseccao de dois obejtos
        laux=[]
        for aux in obj2.lista:
            if aux in self.lista:
                laux.append(aux)
        return laux
    
    def __sub__(self,obj2):
        #retorna subtracao de dois objetos
        laux=self.lista
        for aux in obj2.lista:
            if aux in laux:
                laux.remove(aux)
        return laux

#--------------------------FIM CLASSE CONJ--------------
