class inteiros:

    def __init__(self):
        "inicializando uma nova instancia que sevira de conjunto para os numeros inteiros"

        self_inteiros = []

    def inclui(self,numero):
        "Serve para inserir um numero inteiro qualquer no novo conjunto"
        self.inteiros.append(numero)

    def intvazia(self):
        "inicializa a lista de inteiros vazia"
        inteiros()

    def remove(self,numero):
        " Serve para remover um dado elemneto da lista de inteiros"
        self.inteiros.remove(numero)

    def uniao(self, lista1):
        "insere uma lista1 no final da lista atual"
        self.inteiros.extend(lista1)

    def interseccao(self, lista1, lista2):
        "Realiza a interseccao de duas lista de inteiros passadas como parametro"


    def sub(self, lista1, lista2):
        "Subtrai uma lista da outra"


    def imprime(self, lista1):
        "imprime os elementos da lista que eh passada como parametro para a funcao"
        tamanho = 0
        x = 0
        tamanho = len(self.lista1)
        while x < tamanho:
            print(self.lista1[tamanho])
    
        
    
    
    
