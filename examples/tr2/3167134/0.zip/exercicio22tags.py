class Tags:
    def __init__ (self):
        self.tags = {}
    def reconhece_tags (self, frase):
        i = len (frase)
        j = 0
        ntagst = 0
        while (i>0):
            if (frase[j]!= "<"):
                j = j+1
                i = i-1
            else:
                ntagst = ntagst + 1
                j = j+1
                i = i-1    
        i = len (frase)
        j = 0
        k = 0
        ntagsc = 0
        comecatag = []
        terminatag = []
        while (i>0):
            if (frase[j]!= "<"):
                j = j+1
                i = i-1
            else:
                while (frase[j]!=">"):
                    if (frase[j]=="<"):
                        comecatag[k] = j
                    j = j+1
                    i = i-1
                if (frase[j] == ">"):
                    ntagsc = ntagsc+1
                    terminatag[k] = j
                    k = k+1
        print (ntags)
        print ("tags (")
        i = 0
        while (i<=k):
            while (comecatag[k] < terminatag[k]):
                print (frase [comecatag[k]])
                comecatag [k] = comecatag [k] + 1
            i = i+1
        print (") -")
        ntagsp = ntagst - ntagsc
        print (ntagsp)
        print ("tags-problema")

                
                
