class Frases:
    def __init__ (self):
        self.frase = ""
        f = open ("C:/windows/desktop/arquivo.txt")
    def le_frase (self, frase):
        i = 0
        while f.readline():
            i = i+1
            frase = f.readline()
            print ("linha ")
            print (i)
            print (" -")
            reconhece_palavra (self, frase)
            reconhece_tags (self, frase)
