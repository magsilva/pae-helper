class Palavras:
    def __init__ (self):
        self.npalavras = 0
    def reconhece_palavra (self, frase):
        i = len (frase)
        j = 0
        while (i > 0):
            while (frase[j] != " "):
                j = j+1
                i = i-1
            if (i>0):
                npalavras = npalavras+1
                j = j+1
                i = i-1
        print (npalavras)
        print ("palavras - ")
        

        
            
