#Nomes:
# Cleber Castro Hage ........... No USP: 3560345
# Glauco Becaro ................ No USP: ???????

#Exercicio 2.2

#Este Programa foi escrito baseado no texto do exercicio. Ele foi feito seguindo exatamente o que
#foi pedido.
#Mas a observacao que estava no final nao foi percebida.
#Portanto, nao ha classes para cada classificacao(Palavra, Frase, Tag) e, sim, tudo implementado
#como se fossem atributos.

#OBSERVACAO: para se terminar uma frase deve-se terminar com '.'. E para se terminar palavras deve-
#se usar ' '



import string

class a:
    #Inicializacao. Deve-se passar um Nome de Arquivo como parametro para a instancia da classe
    def __init__(self, File_Name):
        f = open(File_Name, 'r')
	self.Read = str(f.readlines())
	f.close
        i = 0
        j = 0
        self.Word = [] #Palavra
        self.Phrase = [] #Frase
        lim = self.Read.find(' ', i) #lim � a primeira posicao onde se encontra ' '
        while lim != -1:  #quando ainda existe ' '     
            self.Word += ([self.Read[i: lim]]) #une a palavra a uma lista de palavras
            i = lim + 1
            lim = self.Read.find(' ', i) #procurar por outro ' '
            
        i=0 # reinicializar para poder comecar a procurar por "frases"
        lim2 = self.Read.find('.', i)
        while lim2 != -1: #segue do mesmo modo que se fez para palavras
            
            self.Phrase += ([self.Read[i: lim2]])
            i = lim2 + 1
            lim2 = self.Read.find('.', i)
        
        i=0 # reinicializar para poder comecar a procurar por "Tags"
        j=0
        self.Tag = []
        self.NTagsCProb = 0
        lim3 = self.Read.find('<', i)
        lim4 = self.Read.find('>', j)
        lim3a = self.Read.find('<', (lim3+1)) #lim3a para saber se existe algum '<' a mais que
        #o '<' anterior antes de '>'
        lim4a = self.Read.find('<', (lim4+1)) #lim4a para saber se existe algum '>' a mais que
        #o '>' anterior antes de '<'
        while ((lim3) != -1): 
            if (lim3 < lim4) and (lim4 != -1): #Tudo certo para armazenar Tag
                self.Tag += ([self.Read[(lim3+1): lim4]])
                i = lim3 + 1
                j = lim4 + 1
                lim3 = self.Read.find('<', i)
                lim4 = self.Read.find('>', j)
            if (lim3a > lim4) and (lim4 == -1): # Problema: tem '<' a mais antes de '>'
                self.NTagsCProb += 1
                i = lim3 + 1
                lim3 = self.Read.find('<', i)
            if (lim4a < lim3a) and (lim3 != -1): # Problema: tem '>' a mais antes de '<'
                self.NTagsCProb += 1
                j = lim4 + 1
                lim4 = self.Read.find('>', j)
        N=1   # Para numeracao de frases
        k=0   # Para ir de 0 ateh numero de frases
        LWord = len(self.Word)   # Para salvar o numero de palavras
        LPhrase = len(self.Phrase)   # Para salvar o numero de frases
        LTag = len(self.Tag)# Para salvar o numero de tags
        print('Escolha um nome para o arquivo de saida desejado')
        self.File_Name_Out = raw_input()
        Out = open(self.File_Name_Out, 'w')
        while k < LPhrase:
            print >>Out, "frase %d - %d palavras - %d tags (%s) - %d tags-problema)" %(N, LWord, LTag, self.Tag, self.NTagsCProb)
            N += 1
            k += 1
        Out.close()
        
