#Exercicio 2.1

#Nomes:
# Cleber Castro Hage ........... No USP: 3560345
# Glauco Becaro ................ No USP: ???????

#Este programa executa todos os passos do exercicio.

#Classe Conjunto de Inteiros
class Conjunto_Inteiros:
    def __init__(self, *Param):  #Pode-se colocar v�rios parametros , Numeros Inteiros e Objetos do Tipo Classe Conjunto_
		         #Inteiros
        self.List = []   #Guardarei tudo nesta Lista
        for i in Param:    # Verificando se os parametros sao numeros inteiros ou objetos do tipo classe Conjunto_Inteiros
            if type(i) == type(0):
                self.Adicao(i)   # Adicionar o elemento a List
            if type(i) == type(self):
                self.Uniao(i)  # Adicionar o objeto a List
     
#Adicao de elementos numeros inteiros
    def Adicao(self, Read):
        if Read not in self.List:  #Verificando se jah nao existe armazenado
            self.List.append(Read)
            
# Uniao de Listas
    def Uniao(self, Read):
        if Read not in self.List:   # Verificando se jah nao existe
            self.List += Read.List

#Remocao de elementos numeros inteiros ou de objetos do tipo inteiro
    def RemocaoInt(self, Read):
        if Read in self.List:
            self.List.remove(Read)

#Subtracao: List - Subconjunto da List
    def Subtracao(self, Read):
        Lista_Subtracao = self.List
        for i in self.List:
            for j in Read.List:
                if i == j:
                    Lista_Subtracao.remove(j)  
        print(Lista_Subtracao)

#Interseccao de List com uma lista passada como parametro
    def Interseccao(self, Read):
        Lista_Interseccao = []
        for i in self.List:
            for j in Read.List:
                if i == j:
                    Lista_Interseccao.append(j)
        print(Lista_Interseccao)

#Impressao de elementos numeros inteiros ou de objetos do tipo inteiro da List
    def Imprima_Conjunto(self):
        print(self.List)
    
