/*AUTORIA DE: Mamad� Bubacar Da Silva Bald�          N� 3538162
            Alecio Elias                             N� 3309267
            
            
            FUN��O GLOBAL DO PROGRAMA :   

*/
import java.io.*;
import  java.awt.*;
import  java.awt.event.*;
import  javax.swing.*;
class ListDisc{
	BufferedReader inReader = null;
	String StringLine = new String();
	int numLine = 0;
	public ListDisc(String NameOfFile){
		try{
		    inReader = new BufferedReader(new FileReader(NameOfFile));
		    
		  }catch(FileNotFoundException e){
		  	System.err.println(" Nao foi possivel abrir o arquivo");
		  	System.exit(1);
		  }
		  try{
		  	   StringLine = inReader.readLine();
		  	   numLine = Integer.parseInt(StringLine);
		  	   while(numLine > 0){
		  	   	StringLine = inReader.readLine();
		  	   	System.out.println(StringLine);
		  	   	System.out.println("                       ");
		  	   	numLine--;
		  	   }
		  	   inReader.close();
		  }
		  catch(IOException e){
		  	System.out.println(e.getMessage());
		  	
		  }
		
	}
	
	
}
/*****************************************************
*******************************************************/

class ListDiscCursados{
	BufferedReader inReader = null;
	String StringLine = new String();
	int numLine = 0;
	public ListDiscCursados(String NameOfFile){
		try{
		    inReader = new BufferedReader(new FileReader(NameOfFile));
		    
		  }catch(FileNotFoundException e){
		  	System.err.println(" Nao foi possivel abrir o arquivo");
		  	System.exit(1);
		  }
		  try{
		  	   StringLine = inReader.readLine();
		  	   numLine = Integer.parseInt(StringLine);
		  	   while(numLine > 0){
		  	   	StringLine = inReader.readLine();
		  	   	System.out.println(StringLine);
		  	   	System.out.println("                       ");
		  	   	numLine--;
		  	   }
		  	   inReader.close();
		  }
		  catch(IOException e){
		  	System.out.println(e.getMessage());
		  	
		  }
		
	}
	
	
}

/***************************************************
****************************************************
*/

class ListCredHora{
	BufferedReader inReader = null;
	String StringLine = new String();
	int numLine = 0;
	public ListCredHora(String NameOfFile){
		try{
		    inReader = new BufferedReader(new FileReader(NameOfFile));
		    
		  }catch(FileNotFoundException e){
		  	System.err.println(" Nao foi possivel abrir o arquivo");
		  	System.exit(1);
		  }
		  try{
		  	   StringLine = inReader.readLine();
		  	   numLine = Integer.parseInt(StringLine);
		  	   while(numLine > 0){
		  	   	StringLine = inReader.readLine();
		  	   	System.out.println(StringLine);
		  	   	System.out.println("                       ");
		  	   	numLine--;
		  	   }
		  	   inReader.close();
		  }
		  catch(IOException e){
		  	System.out.println(e.getMessage());
		  	
		  }
		
	}
	
	
}
/*********************************************
**********************************************
*/

class ListCredTeo{
	BufferedReader inReader = null;
	String StringLine = new String();
	int numLine = 0;
	public ListCredTeo(String NameOfFile){
		try{
		    inReader = new BufferedReader(new FileReader(NameOfFile));
		    
		  }catch(FileNotFoundException e){
		  	System.err.println(" Nao foi possivel abrir o arquivo");
		  	System.exit(1);
		  }
		  try{
		  	   StringLine = inReader.readLine();
		  	   numLine = Integer.parseInt(StringLine);
		  	   while(numLine > 0){
		  	   	StringLine = inReader.readLine();
		  	   	System.out.println(StringLine);
		  	   	System.out.println("                       ");
		  	   	numLine--;
		  	   }
		  	   inReader.close();
		  }
		  catch(IOException e){
		  	System.out.println(e.getMessage());
		  	
		  }
		
	}
	
	
}

/*****************************
******************************/
class ListCredPrat{
	BufferedReader inReader = null;
	String StringLine = new String();
	int numLine = 0;
	public ListCredPrat(String NameOfFile){
		try{
		    inReader = new BufferedReader(new FileReader(NameOfFile));
		    
		  }catch(FileNotFoundException e){
		  	System.err.println(" Nao foi possivel abrir o arquivo");
		  	System.exit(1);
		  }
		  try{
		  	   StringLine = inReader.readLine();
		  	   numLine = Integer.parseInt(StringLine);
		  	   while(numLine > 0){
		  	   	StringLine = inReader.readLine();
		  	   	System.out.println(StringLine);
		  	   	System.out.println("                       ");
		  	   	numLine--;
		  	   }
		  	   inReader.close();
		  }
		  catch(IOException e){
		  	System.out.println(e.getMessage());
		  	
		  }
		
	}
	
	
}
/*******************************************
*******************************************/

class ListCredLab{
	BufferedReader inReader = null;
	String StringLine = new String();
	int numLine = 0;
	public ListCredLab(String NameOfFile){
		try{
		    inReader = new BufferedReader(new FileReader(NameOfFile));
		    
		  }catch(FileNotFoundException e){
		  	System.err.println(" Nao foi possivel abrir o arquivo");
		  	System.exit(1);
		  }
		  try{
		  	   StringLine = inReader.readLine();
		  	   numLine = Integer.parseInt(StringLine);
		  	   while(numLine > 0){
		  	   	StringLine = inReader.readLine();
		  	   	System.out.println(StringLine);
		  	   	System.out.println("                       ");
		  	   	numLine--;
		  	   }
		  	   inReader.close();
		  }
		  catch(IOException e){
		  	System.out.println(e.getMessage());
		  	
		  }
		
	}
	
	
}



/*******************************************
*******************************************/

class ListMedObrigatoria{
	BufferedReader inReader = null;
	String StringLine = new String();
	int numLine = 0;
	public ListMedObrigatoria(String NameOfFile){
		try{
		    inReader = new BufferedReader(new FileReader(NameOfFile));
		    
		  }catch(FileNotFoundException e){
		  	System.err.println(" Nao foi possivel abrir o arquivo");
		  	System.exit(1);
		  }
		  try{
		  	   StringLine = inReader.readLine();
		  	   numLine = Integer.parseInt(StringLine);
		  	   while(numLine > 0){
		  	   	StringLine = inReader.readLine();
		  	   	System.out.println(StringLine);
		  	   	System.out.println("                       ");
		  	   	numLine--;
		  	   }
		  	   inReader.close();
		  }
		  catch(IOException e){
		  	System.out.println(e.getMessage());
		  	
		  }
		
	}
	
	
}

/*******************************************
*******************************************/

class ListMedOptativa{
	BufferedReader inReader = null;
	String StringLine = new String();
	int numLine = 0;
	public ListMedOptativa(String NameOfFile){
		try{
		    inReader = new BufferedReader(new FileReader(NameOfFile));
		    
		  }catch(FileNotFoundException e){
		  	System.err.println(" Nao foi possivel abrir o arquivo");
		  	System.exit(1);
		  }
		  try{
		  	   StringLine = inReader.readLine();
		  	   numLine = Integer.parseInt(StringLine);
		  	   while(numLine > 0){
		  	   	StringLine = inReader.readLine();
		  	   	System.out.println(StringLine);
		  	   	System.out.println("                       ");
		  	   	numLine--;
		  	   }
		  	   inReader.close();
		  }
		  catch(IOException e){
		  	System.out.println(e.getMessage());
		  	
		  }
		
	}
	
	
}

/*******************************************
*******************************************/

class ListMedSelectiva{
	BufferedReader inReader = null;
	String StringLine = new String();
	int numLine = 0;
	public ListMedSelectiva(String NameOfFile){
		try{
		    inReader = new BufferedReader(new FileReader(NameOfFile));
		    
		  }catch(FileNotFoundException e){
		  	System.err.println(" Nao foi possivel abrir o arquivo");
		  	System.exit(1);
		  }
		  try{
		  	   StringLine = inReader.readLine();
		  	   numLine = Integer.parseInt(StringLine);
		  	   while(numLine > 0){
		  	   	StringLine = inReader.readLine();
		  	   	System.out.println(StringLine);
		  	   	System.out.println("                       ");
		  	   	numLine--;
		  	   }
		  	   inReader.close();
		  }
		  catch(IOException e){
		  	System.out.println(e.getMessage());
		  	
		  }
		
	}
	
	
}




/*****************************************************
*******************************************************/

class  ExamJButtonClick   extends  JFrame {
    JButton  Boton11,Boton1, Boton221, Boton2,Boton222,Boton223,Boton21,Boton22,Boton23;
    JPanel  jp1, jp2, jp3, jp4;
    
    public  static  void  main(String  args[])  {
        ExamJButtonClick  ejbc  =  new  ExamJButtonClick();
        ejbc.addWindowListener(new  WindowAdapter() {
            public  void  windowClosing(WindowEvent  we)  {
                 System.exit(0);
            }
        });
        ejbc.setBounds(20,40,800,300);
        ejbc.setVisible(true);

    }
    ExamJButtonClick()  {
        super("Escolhe uma opcao ");
        Boton1   =   new  JButton("List Disc");
        Boton2   =   new  JButton("Total de Disc Cursados");
        Boton11   =   new  JButton("Total de Credito e Horas.");
        Boton221   =   new  JButton("Total de Credito Teorico");
        Boton222   =   new  JButton("Total de Credito Pratico.");
        Boton223   =   new  JButton("Total de Credito Laboratorio");
        
        Boton21   =   new  JButton("Media ponderada Disc.Obrigatoria..");
        Boton22   =   new  JButton("Media ponderada Disc.Optativa.");
        Boton23   =   new  JButton("Media ponderada Disc. Selectiva.");



     //  create  ActionListener
        ExamActionListener1  eal1   =    new  ExamActionListener1();
     // set  actionListener  to  JButton
        Boton1.addActionListener(eal1);
        Boton2.addActionListener(eal1);
        
        Boton11.addActionListener(eal1);
        Boton221.addActionListener(eal1);
        
        Boton222.addActionListener(eal1);
        Boton223.addActionListener(eal1);
        
        Boton21.addActionListener(eal1);
        Boton22.addActionListener(eal1);
        Boton23.addActionListener(eal1);
        
        

        jp1    =  new JPanel();
        jp1.add(Boton1);
        jp1.add(Boton2);
        
        jp1.add(Boton23);
        getContentPane().add(jp1, BorderLayout.SOUTH);       
        
        jp2    =  new JPanel();
        jp2.add(Boton11);
        jp2.add(Boton221);
        
        getContentPane().add(jp2, BorderLayout.EAST);       
        
        jp3    =  new JPanel();
        jp3.add(Boton222);
        jp3.add(Boton22);
        
        getContentPane().add(jp3, BorderLayout.WEST);       
        
        jp4    =  new JPanel();
        jp4.add(Boton21);
        jp4.add(Boton223);
        getContentPane().add(jp4, BorderLayout.NORTH);       
    }
   

    /*********************************************
    **********************************************
    **********************************************/
    
    class  ExamActionListener1  implements  ActionListener    {
    	
        public   void  actionPerformed(ActionEvent   param1)  {
            if(param1.getSource()  ==  Boton1)  {
                 jp1.setBackground(Color.green);
                 ListDisc  dis = new ListDisc("teste1.txt");
            }
            if(param1.getSource()  ==  Boton2)  {
                 jp1.setBackground(Color.yellow);
                 ListDiscCursados  disCur = new ListDiscCursados("teste2.txt");
            }
            if (param1.getSource() == Boton11){
            	jp1.setBackground(Color.green);
            	 ListCredHora  CredH = new ListCredHora("teste3.txt");
            }
            
            if (param1.getSource() == Boton221){
            	ListCredTeo  CredH = new ListCredTeo("teste4.txt");
            	
            }
            if (param1.getSource() == Boton222){
            	jp1.setBackground(Color.green);
            	ListCredPrat CredH = new ListCredPrat("teste5.txt");
            	
            }
            if (param1.getSource() == Boton223){
            	ListCredLab CredH = new ListCredLab("teste6.txt");
            	
            	
            }
            
            if (param1.getSource() == Boton21){
            	jp1.setBackground(Color.yellow);
            	ListMedObrigatoria Media = new ListMedObrigatoria("teste7.txt");
            	
            	
            }
            if (param1.getSource() == Boton22){
            	jp1.setBackground(Color.yellow);
            	ListMedOptativa Media = new ListMedOptativa("teste8.txt");
            	
            	
            }
            if (param1.getSource() == Boton23){
            	jp1.setBackground(Color.yellow);
            	ListMedSelectiva Media = new ListMedSelectiva("teste8.txt");
            	
            	
            }
        }    
    }
    
   
   
    
    
}
