// Pacote que contem a classe ArrayList
import java.util.*;

// Estrutura curricular default.
class Curriculum {

	// Array (implementado como lista) de objetos disciplinas
	private ArrayList disciplinas;

	// constante que define o total de horas necessario para acabar o curso
	static final int totalHor = 200;
	// constante que define o total de creditos obrigatorios necessarios para acabar o curso
	static final int totalObr = 150;
	// constante que define o total de creditos optativos para acabar o curso
	static final int totalOpt = 15;
	// constante que define o total de creditos eletivos para acabar o curso
	static final int totalEle = 9;

	// Construtor padrao que cria o array com 0 elementos
	Curriculum(){
		this.disciplinas = new ArrayList(0);
	}

	// Sobrecarga do construtor onde o tamanho do array pode ser jah definido
	Curriculum(int tamanho){
		this.disciplinas = new ArrayList(tamanho);
	}

	// Adiciona uma disciplina ao array
	void adicionar(Disciplina disc){
		disciplinas.add(disc);
	}

	// Metodo que avisa que uma disciplina foi cursada, com a respectiva nota
	void cursou(int posicao, float nota){
		if(nota>=0&&nota<=(float)10){
			((Disciplina)disciplinas.get(posicao)).cursada = true;
			((Disciplina)disciplinas.get(posicao)).nota = nota;
		}
	}

	// Metodo que retorna a quantidade de creditos totais restantes
	int restaCredito(){
		return(this.totalObr + this.totalOpt + this.totalEle - this.getCreditos());
	}

	// Metodo que retorna a quantidade de horas restantes
	int restaHora(){
		return(this.totalHor-this.getHoras());
	}

	// Metodo que retorna a media ponderada de acordo com o tipo de disciplina (obrigatoria,optativa,eletiva)
	float media(String tipo){
		float media = 0;
		int creditos = 0;
		// Pega as notas somente das disciplinas cursadas
		for(int i=0;i<disciplinas.size();i++){
			if(((Disciplina)disciplinas.get(i)).getTipo().equals(tipo)&&((Disciplina)disciplinas.get(i)).cursada){
				creditos = creditos + ((Disciplina)disciplinas.get(i)).teorico + ((Disciplina)disciplinas.get(i)).pratico + ((Disciplina)disciplinas.get(i)).laboratorio;
				media = media + ((Disciplina)(disciplinas.get(i))).nota * ((Disciplina)disciplinas.get(i)).teorico + ((Disciplina)disciplinas.get(i)).pratico + ((Disciplina)disciplinas.get(i)).laboratorio;
			}
		}
		if (creditos!=0) return (media/creditos);
		else return 0;
	}

	// Metodo que retorna a quantidade de creditos totais jah cursado
	int getCreditos(){
		int creditos = 0;
		for(int i=0;i<disciplinas.size();i++){
			if(((Disciplina)disciplinas.get(i)).cursada){
				creditos = creditos + ((Disciplina)disciplinas.get(i)).teorico + ((Disciplina)disciplinas.get(i)).pratico + ((Disciplina)disciplinas.get(i)).laboratorio;
			}
		}
		return creditos;
	}

	// Metodo que retorna um array com as disciplinas do curriculum. Serve apenas para listagem das disciplinas
	Disciplina[] getDisciplinas(){
		Disciplina[] d = new Disciplina[disciplinas.size()];
		for(int i=0;i<disciplinas.size();i++) d[i] = (Disciplina)disciplinas.get(i);
		return d;
	}

	// Metodo que retorna a quantidade de horas-aula jah cursadas
	int getHoras(){
		int horas = 0;
		for(int i=0;i<disciplinas.size();i++){
			if(((Disciplina)disciplinas.get(i)).cursada){
				horas = horas + ((Disciplina)disciplinas.get(i)).getHoras();
			}
		}
		return horas;
	}

	// Metodo que retorna um array com as disciplinas sugeridas
	Disciplina[] sugerir(String tipo){
		ArrayList sugestoes = new ArrayList(0);
		for(int i=0;i<disciplinas.size();i++){
			if (((Disciplina)disciplinas.get(i)).getTipo().equals(tipo)&&!((Disciplina)disciplinas.get(i)).cursada&&((((Disciplina)disciplinas.get(i)).teorico + ((Disciplina)disciplinas.get(i)).pratico + ((Disciplina)disciplinas.get(i)).laboratorio)<this.restaCredito())) sugestoes.add(disciplinas.get(i));
		}
		Disciplina[] d = new Disciplina[sugestoes.size()];
		for(int i=0;i<sugestoes.size();i++) d[i] = (Disciplina)sugestoes.get(i);
		return d;
	}

}
