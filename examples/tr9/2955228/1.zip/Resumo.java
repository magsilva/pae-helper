// Pacote que contem as classes para I/O (BufferedReader e FileReader)
import java.io.*;
// Pacote que contem a classe UIManager (para arrumar a aparencia e comportamento do aplicativo)
import javax.swing.UIManager;

// Classe principal
class Resumo{

	// Instancia um objeto Curriculum (que contem as disciplinas)
	Curriculum curriculum = new Curriculum();

	// Construtor padrao
	Resumo(){

		// Metodo que leh as disciplinas do arquivo
		this.inicializa();

		// Deixa a interface grafica a cara do sistema operacional hospedeiro
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception ex){}

		// Chama a interface gr�fica, e passa como parametro essa propria classe (Resumo)
		Janela jan = new Janela(this);
	}

	// Metodo que leh as disciplinas do arquivo
	private void inicializa(){

		try{
			// Stream para leitura do arquivo
			BufferedReader in = new BufferedReader(new FileReader("estrutura.dat"));
			String linha="";

			// Para cada linha lida, a correspondente disciplina eh adicionada ao objeto curriculum
			while((linha = in.readLine())!=null){
				String[] disciplina = linha.split(",");
				Disciplina d = new Disciplina(disciplina[0], disciplina[1], Integer.parseInt(disciplina[2]), Integer.parseInt(disciplina[3]), Integer.parseInt(disciplina[4]), Integer.parseInt(disciplina[5]));
				curriculum.adicionar(d);
			}
			in.close();
		} catch (IOException ex){}

	}

	// Metodo principal
	public static void main(String args[]){

		// Instancia da classe principal (no caso esta)
		Resumo resumo = new Resumo();
	}

}