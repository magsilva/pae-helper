// Classe que representa uma disciplina
class Disciplina {

	// String que armazena o nome da disciplina
	String nome;
	// String que armazena o tipo da disciplina (obrigatoria,optativa,eletiva). Eh privada para permitir o encapsulamento
	private String tipo;
	// Quantidade de creditos teoricos
	int teorico;
	// Quantidade de creditos praticos
	int pratico;
	// Quantidade de creditos de laboratorio
	int laboratorio;
	// Periodo
	int periodo;
	// Quantidade de horas-aula - baseadas nos creditos - por isso privada
	private int horas;
	// Nota da disciplina
	float nota = 0;
	// Variavel que diz se a disciplina foi cursada (true) ou n�o (false)
	boolean cursada = false;

	// Construtor padrao
	Disciplina(){}

	// Sobrecarga do construtor, onde a disciplina jah eh inicializada com os campos citados no enunciado
	Disciplina(String nome, String tipo, int teorico, int pratico, int laboratorio, int periodo){
		this.nome = nome;
		this.setTipo(tipo);
		this.teorico = teorico;
		this.pratico = pratico;
		this.laboratorio = laboratorio;
		this.periodo = periodo;
		this.horas = teorico + 2*laboratorio + (pratico/2);
	}

	// Encapsulamento da atribuicao do atributo "tipo" para evitar valores invalidos
	void setTipo(String tipo){
		if (tipo.equals("obrigatoria")||tipo.equals("optativa")||tipo.equals("eletiva")) this.tipo = tipo;
	}

	// Encapsulamento do retorno do valor do atributo "tipo"
	String getTipo(){
		return this.tipo;
	}

	// Encapsulamento do retorno do valor do atributo "horas"
	int getHoras(){
		return this.horas;
	}

}
