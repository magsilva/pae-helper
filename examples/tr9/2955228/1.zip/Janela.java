// Pacotes que contem as classes necessarias a interface grafica
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
// Pacote com a classe BigDecimal, usada para formatar a nota com duas classes decimais
import java.math.BigDecimal;

// Classe que implementa a interface grafica com o usuario
class Janela extends JFrame {

	// Objeto da classe principal
	Resumo resumo;
	// Array vazio que irah conter as disciplinas lidas e retornadas pelo objeto resumo (serve somente para listagem)
	Disciplina[] disciplinas;

	// Campos de texto que conterao as notas de cada disciplina
	JTextField[] notas;
	// Campo de texto que irah conter o total de creditos jah cursados
	JTextField crd = new JTextField("",3);
	// Campo de texto que irah conter o total de horas jah cursadas
	JTextField hor = new JTextField("",3);
	// Campo de texto que irah conter a media ponderada das disciplinas jah cursadas
	JTextField med = new JTextField("",5);

	// Botao radio que representa o tipo obrigatoria
	JRadioButton obrigatoria = new JRadioButton("o",true);
	// Botao radio que representa o tipo optativa
	JRadioButton optativa = new JRadioButton("p");
	// Botao radio que representa o tipo eletiva
	JRadioButton eletiva = new JRadioButton("e");

	// Rotulo que contem a mensagem do campo status
	JLabel mensagem = new JLabel("Pronto");


	// Construtor da janela, que tem como parametro um objeto do tipo Resumo 
	// (isso eh necessario para a interface e a classe principal conversarem)
	Janela(Resumo resumo){

		// O objeto Resumo lah de cima (da classe Janela) recebe o objeto Resumo passado como parametro
		this.resumo = resumo;
		// O array de disciplinas vazio agora recebe as disciplinas do curriculum
		disciplinas = resumo.curriculum.getDisciplinas();

		// Arruma o titulo da janela
		this.setTitle("SCE 231 - Trabalho 8");

		// Painel que contem todos os outros containers, inicializado com o layout Border
		JPanel principal = new JPanel(new BorderLayout());
		// Painel que contem somente os titulos, identificando os campos das disciplinas
		JPanel titulos = new JPanel();
		// Painel que contem a listagem das disciplinas
		JPanel conteudo = new JPanel();
		// Painel que contem a barra inferior de ferramentas
		JPanel ferramentas = new JPanel();
		// Painel que contem o rotulo de status
		JPanel status = new JPanel();
		// Painel que contem os paineis "ferramentas" e "status"
		JPanel inferior = new JPanel();

		// Arruma o layout dos paineis "conteudo" e "inferior" para Box (para tudo ficar alinhado de cima para baixo)
		conteudo.setLayout(new BoxLayout(conteudo, BoxLayout.Y_AXIS));
		inferior.setLayout(new BoxLayout(inferior, BoxLayout.Y_AXIS));
		// Coloca borda no painel de status para ficar igual das janelas do Windows
    		status.setBorder(BorderFactory.createLoweredBevelBorder());
		// Arruma a borda do painel de conteudo
		conteudo.setBorder(BorderFactory.createEtchedBorder());
		// Painel com scroll, que contem o painel de conteudo das disciplinas
		JScrollPane scroll = new JScrollPane(conteudo);

		// Titulos para informar os campos das disciplinas
		JLabel titulo1 = new JLabel("Disciplina",SwingConstants.CENTER);
		JLabel titulo2 = new JLabel("         Tipo",SwingConstants.CENTER);
		JLabel titulo3 = new JLabel("Per�odo",SwingConstants.CENTER);
		JLabel titulo4 = new JLabel("      Carga hor�ria",SwingConstants.CENTER);
		JLabel titulo5 = new JLabel("Nota",SwingConstants.CENTER);
		JLabel titulo6 = new JLabel("");

		// Botao que irah sugerir as disciplinas, com o respectivo listener
		JButton sugerir = new JButton("sugerir");
		sugerir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        	sugerir_actionPerformed(e);
		      	}
		});

		// Botao que faz todos os calculos pedidos, com o respectivo listener
		JButton calcular = new JButton("calcular");
		calcular.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        	calcular_actionPerformed(e);
		      	}
		});

		// Rotulos informativos (sobre os Creditos/Horas-aula/Media-ponderada das materias cursadas)
		JLabel creditos = new JLabel("Creditos: ",SwingConstants.CENTER);
		JLabel horas = new JLabel("Horas-aula:",SwingConstants.CENTER);
		JLabel media = new JLabel("Media ponderada:",SwingConstants.CENTER);

		// Grupo de botoes, que contem os botoes do tipo radio que identificam o tipo da disciplina
		ButtonGroup grupo = new ButtonGroup();
		grupo.add(obrigatoria);
		grupo.add(optativa);
		grupo.add(eletiva);

		// Rotulos que conterao os nomes das disciplinas
		JLabel[] nomes = new JLabel[disciplinas.length];
		// Rotulos que conterao os tipos das disciplinas
		JLabel[] tipos = new JLabel[disciplinas.length];
		// Rotulos que conterao os periodos das disciplinas
		JLabel[] periodos = new JLabel[disciplinas.length];
		// Rotulos que conterao as horas-aula das disciplinas
		JLabel[] cargas = new JLabel[disciplinas.length];
		// Paineis para armazenar as disciplinas. Um painel para cada disciplina
		JPanel[] linha = new JPanel[disciplinas.length];
		notas = new JTextField[disciplinas.length];

		// Adiciona os rotulos de titulo ao painel titulo
		titulos.add(titulo1);
		titulos.add(titulo2);
		titulos.add(titulo3);
		titulos.add(titulo4);
		titulos.add(titulo5);
		titulos.add(titulo6);

		// Adiciona as ferramentas ao painel de ferramentas
		ferramentas.add(sugerir);
		ferramentas.add(horas);
		ferramentas.add(hor);
		ferramentas.add(creditos);
		ferramentas.add(crd);
		ferramentas.add(media);
		ferramentas.add(med);
		ferramentas.add(obrigatoria);
		ferramentas.add(optativa);
		ferramentas.add(eletiva);
		ferramentas.add(calcular);

		// Adiciona o rotulo de mensagem ao painel de status
		status.add(mensagem);

		// Largura e altura default usadas em alguns rotulos
		int largura = 115;
		int altura = 25;

		// Loop que percorre o array de disciplinas e pega cada campo da disciplina e joga ao elemento grafico correspondente
		for(int i=0;i<disciplinas.length;i++){

			// Cria um painel para conter os campos da disciplina
			linha[i] = new JPanel();
			// Cria e adiciona um rotulo com o nome da disciplina
			linha[i].add(nomes[i] = new JLabel(disciplinas[i].nome));
			// Cria e adiciona um rotulo com o tipo da disciplina
			linha[i].add(tipos[i] = new JLabel(disciplinas[i].getTipo(),SwingConstants.CENTER));
			// Cria e adiciona um rotulo com o periodo da disciplina
			linha[i].add(periodos[i] = new JLabel(String.valueOf(disciplinas[i].periodo),SwingConstants.CENTER));
			// Cria e adiciona um rotulo com o carga-horaria da disciplina
			linha[i].add(cargas[i] = new JLabel(String.valueOf(disciplinas[i].getHoras()),SwingConstants.CENTER));
			// Cria e adiciona um rotulo com o nota da disciplina a ser atribuida por interacao com o usuario
			linha[i].add(notas[i] = new JTextField("",4));

			// Arruma o tamanho dos componentes
			nomes[i].setPreferredSize(new Dimension(150,altura));
			periodos[i].setPreferredSize(new Dimension(50,altura));
			tipos[i].setPreferredSize(new Dimension(largura,altura));
			cargas[i].setPreferredSize(new Dimension(largura,altura));

			// Configura a cor do painel de conteudo para laranja
			linha[i].setBackground(Color.orange);

			// Adiciona o painel da disciplina ao painel de conteudo
			conteudo.add(linha[i]);
		}


		// Arruma o tamanho dos componentes
		titulo1.setPreferredSize(new Dimension(155,altura));
		titulo2.setPreferredSize(new Dimension(largura,altura));
		titulo3.setPreferredSize(new Dimension(50,altura));
		titulo4.setPreferredSize(new Dimension(largura,altura));
		titulo5.setPreferredSize(new Dimension(60,altura));
		titulo6.setPreferredSize(new Dimension(20,altura));
		mensagem.setPreferredSize(new Dimension(largura*(4)+90,10));
		status.setPreferredSize(new Dimension(status.getWidth(),20));

		// Adiciona o painel de ferramentas ao painel inferior
		inferior.add(ferramentas);
		// Adiciona o painel de status ao painel inferior
		inferior.add(status);
		// Adiciona o painel de titulos ao painel principal (na parte superior deste)
		principal.add(titulos, BorderLayout.NORTH);
		// Adiciona o painel de scroll (que contem o painel conteudo) ao painel principal (na parte central deste)
		principal.add(scroll, BorderLayout.CENTER);
		// Adiciona o painel inferior ao painel principal (na parte inferior deste)
		principal.add(inferior, BorderLayout.SOUTH);
		// Adiciona o painel principal a janela
		this.getContentPane().add(principal);
		this.pack();

		// Arruma as dimensoes dos componentes
		this.setSize(titulos.getWidth()+5,550);

		// Torna a janela visivel
		this.setVisible(true);

		// Avisa que quando a janela for fechada a aplicacao serah encerrada
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);

		// Nao deixa o usuario alterar o tamanho da janela
		this.setResizable(false);
	}

	// Metodo que pega qual o tipo de disciplina selecionado (obrigatoria, optativa, eletiva)
	String getTipoSelecionado(){
		if (obrigatoria.isSelected()) return "obrigatoria";
		if (optativa.isSelected()) return "optativa";
		return "eletiva";
	}

	// Metodo listener que faz os calculos pedidos no enunciado (creditos e horas-aula cursados, creditos e horas-aula restantes)
	void calcular_actionPerformed(ActionEvent e) {

		// Loop que percorre o array de disciplinas
		for(int i=0;i<disciplinas.length;i++){
			// Se o campo nota nao estah vazio, entao eh pq o aluno cursou esta disciplina
			if(!notas[i].getText().equals("")){
				// Caso o usuario coloque uma letra no campo de nota, uma excecao do tipo NumberFormatException
				// eh disparada automaticamente. Agora, caso a nota seja maior que 10 ou menor que 0, uma excecao
				// do mesmo tipo eh disparada programaticamente.
				try{
					if((Float.parseFloat(notas[i].getText())>10)||(Float.parseFloat(notas[i].getText())<0)) throw new NumberFormatException();
				} catch(NumberFormatException ex){
					// Exibe a mensagem de erro
					JOptionPane.showMessageDialog(null, "Nota inv�lida. Digite um valor entre 0 e 10", "Erro", JOptionPane.ERROR_MESSAGE);
					// Leva o cursor ateh o campo com a nota invalida
					notas[i].grabFocus();
					notas[i].selectAll();
					// Interrompe os calculos
					return;
				}
				// Caso a nota seja valida, entao pega-se esta
				resumo.curriculum.cursou(i,Float.parseFloat(notas[i].getText()));
			}
		}
		// Pega a media ponderada
		BigDecimal nota = new BigDecimal((double)resumo.curriculum.media(this.getTipoSelecionado()));
		// Arredonda a media para duas casas decimais
		nota = nota.setScale(2,BigDecimal.ROUND_HALF_UP);
		// Mostra a media ponderada no campo de texto apropriado
		med.setText(nota.toString());
		// Mostra as horas-aula cursadas no campo de texto apropriado
		hor.setText(String.valueOf(resumo.curriculum.getHoras()));
		// Mostra os creditos cursados no campo de texto apropriado
		crd.setText(String.valueOf(resumo.curriculum.getCreditos()));
		// Exibe na barra de status os creditos e as horas-aula restantes
		mensagem.setText("Cr�ditos restantes: " + resumo.curriculum.restaCredito() + "      Horas-aula restantes: " + resumo.curriculum.restaHora());
	}

	// Metodo listner que chama a funcao que sugere as disciplinas a serem cursadas, de acordo com o tipo pedido
	void sugerir_actionPerformed(ActionEvent e) {

		// Cria uma nova janela para mostrar o resultado
		JFrame popup = new JFrame("Mat�rias sugeridas");
		// Area de texto com um texto default para o caso de nao conseguir calcular
		JTextArea result = new JTextArea("N�o foi poss�vel sugerir nenhuma mat�ria.");
		// Painel de scroll para conter a area de texto com os resultados
		JScrollPane scroll = new JScrollPane(result);
		// Adiciona o painel de scroll a janela
		popup.getContentPane().add(scroll);
		// Agrupa tudo
		popup.pack();	
		// Arruma o tamanho da janela
		popup.setSize(400,350);
		// Torna a janela visivel
		popup.setVisible(true);
		
		// Pega qual o tipo de disciplina selecionado (obrigatoria,optativa,eletiva)
		Disciplina[] d = resumo.curriculum.sugerir(this.getTipoSelecionado());

		// Se o metodo retornou alguma disciplina, entao mostra elas no campo de texto com os respectivos creditos
		if (d.length>0){
			// String que armazena todo o texto
			String sugestoes = "";
			// Percorre o array com as disciplinas sugeridas e pega o nome e os creditos correspondentes
			for(int i=0;i<d.length;i++) sugestoes = sugestoes + d[i].nome+" - Cr�ditos: "+d[i].teorico+" te�rico, "+d[i].laboratorio+" laborat�rio, "+d[i].pratico+" pr�tico\n";
			// Joga a String no campo de texto
			result.setText(sugestoes);
		}
	}

}
