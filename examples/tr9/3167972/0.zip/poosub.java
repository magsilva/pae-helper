import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;



class CurrBase{
	
	String disc;
	String tipo;
	int Credito_teo;
	int Credito_lab;
	int Credito_prat;
	int periodo;
	
     public CurrBase(String A,String B,int C,int D,int E,int F)
         {
         	this.disc = A;
         	this.tipo = B;
         	this.Credito_teo = C;
         	this.Credito_lab =	D;
         	this.Credito_prat = E;
         	this.periodo = F;
	    }
	 }


class DiscipBase{
	
	String disc;
	String tipo;
	int Credito_teo;
	int Credito_lab;
	int Credito_prat;
	int periodo;
	int nota;
     public DiscipBase(String A,String B,int C,int D,int E,int F,int G)
         {
         	this.disc = A;
         	this.tipo = B;
         	this.Credito_teo = C;
         	this.Credito_lab =	D;
         	this.Credito_prat = E;
         	this.periodo = F;
         	this.nota=G;
	    }
	 public double hora_aula()
         { return ((this.Credito_teo) );
      }
	 
	 
	 
	 
	 
	 }

class Credito_Laboratorio extends DiscipBase{
	 
	int b;
	
	public Credito_Laboratorio(String A,String B,int C,int D,int E,int F,int G){
	
		super(A, B,C, D, E, F,G); 
          }
    
    public double hora_aula()
         { return ((this.Credito_lab) * 2);
      }
	}

class Credito_Pratica extends DiscipBase{
	 
	int b;
	
     public Credito_Pratica(String A,String B,int C,int D,int E,int F,int G){
	 
		super(A,B,C,D,E,F,G); 
          }
    
    public double hora_aula()
         { return ((this.Credito_prat) * 0.5);
      }
	}



class Disciplinas{
	DiscipBase[] Reg = new DiscipBase[100];
	DiscipBase Axu;
	Credito_Pratica Aux1;  
	Credito_Laboratorio Aux2;  
	int c,i,Ct,Cp,Cl,acc,tot;
	double Hc,Ht;
	String Tip;
	static int ca,ct,cp,cl;
	
	public Disciplinas(){
		this.Reg = Reg; 
}

   public void add(String A,String B,int C,int D,int E,int F,int G ){
   	   c = this.Reg.length;
       this.Reg[c].disc = A;
       this.Reg[c].tipo=B;
       this.Reg[c].Credito_teo = C;
       this.Reg[c].Credito_lab =D;
       this.Reg[c].Credito_prat = E;
       this.Reg[c].periodo = F;
       this.Reg[c].nota = G;
       }
       
       
     public void Calc_Credito(){
     	  c=(this.Reg.length - 1);
     	  Ct=0;
     	  for (i=0;i < c;i++){
     	  	Ct += this.Reg[i].Credito_teo;
     	  	Cp += this.Reg[i].Credito_prat;
     	  	Cl += this.Reg[i].Credito_lab;
     	  	 
     	  	}
     	  	  
         poosub.window.texA.append("Cr�dito total cursado:"+ (Ct+Cp+Cl) +"\n");
         poosub.window.texA.append("\n");
         poosub.window.texA.append("Cr�dito que faltam:\n"+ (ca - (Ct+Cp+Cl)+"\n"));
         poosub.window.texA.append("Cr�dito Teoria - "+ (ct - Ct)+"\n");
         poosub.window.texA.append("Cr�dito Laboratorio - "+ (cl - Cl)+"\n");
         poosub.window.texA.append("Cr�dito Pratico - "+ (cp - Cp)+"\n");
         poosub.window.texA.append("*********************************************************************\n");
          
           
	         
          for (i=0;i < c; i++)
          { Ht+= this.Reg[i].hora_aula();     	  	      
             Axu = this.Reg[i];
             Credito_Pratica Aux1 = new Credito_Pratica(this.Reg[i].disc,this.Reg[i].tipo,this.Reg[i].Credito_teo,this.Reg[i].Credito_prat,this.Reg[i].Credito_lab,this.Reg[i].periodo,this.Reg[i].nota);
	        Credito_Laboratorio Aux2 = new Credito_Laboratorio (this.Reg[i].disc,this.Reg[i].tipo,this.Reg[i].Credito_teo,this.Reg[i].Credito_prat,this.Reg[i].Credito_lab,this.Reg[i].periodo,this.Reg[i].nota); 	 
            Ht += Aux1.hora_aula();
            Ht += Aux2.hora_aula();
        }   
           
           Hc = ((double) (ct + (cl * 2) + (cp * 0.5))); 
           
           poosub.window.texA.append("Horas-Aula Total cursado:"+ Ht +"\n" );
           poosub.window.texA.append("Horas-Aulas que faltam cursar:"+ (Hc-Ht)+"\n");
           poosub.window.texA.append("************************************************************************\n");
           
           
           }

     public void MediaP(String Tip){
     	c=(this.Reg.length - 1);
     	    acc=0;
     	    tot=0;
     	    
     	    for (i=0;i < c;i++)
     	    {
     	    	if (this.Reg[i].tipo == Tip){
     	    	acc+=(this.Reg[i].Credito_teo+this.Reg[i].Credito_prat+this.Reg[i].Credito_lab);
                tot+=(this.Reg[i].nota);}
          }
          
          poosub.window.texA.append("Media Ponderada(Disciplinas "+ Tip +"\n");
          poosub.window.texA.append("Media:"+((float) tot/acc) +"\n");
          poosub.window.texA.append("***************************************************************************\n");

}


}




class w extends JFrame implements ActionListener {
/* Definicao da interface da janela da parte 1. */
		TextArea  texA = new TextArea(null, 0, 0, java.awt.TextArea.SCROLLBARS_BOTH);
		
		Label     l1   = new Label("Disciplina:");
		Label     l3   = new Label("Cr�dito teorico:");
		Label     l4   = new Label("Cr�dito pr�tico:");
		Label     l5   = new Label("Cr�dito laboratorio:");
		Label     l6   = new Label("Periodo:");
		Label     l7   = new Label("Nota:");
		Label     l2   = new Label("Tipo:");
		
		TextField t1   = new TextField("",8);
		TextField t2   = new TextField("",8);
		TextField t3   = new TextField("",8);
		TextField t4   = new TextField("",8);
		TextField t5   = new TextField("",8);
		TextField t6   = new TextField("",8);
		TextField t7   = new TextField("",8);
		
		Button    media = new Button("Media ponderada");
		Button    credito = new Button("Cr�ditos");
		Button    ins = new Button("Inserir");
		
	    DiscipBase Aux;;
	
	public w () {
		Container display = getContentPane();
		GridBagLayout layout = new GridBagLayout();
		GridBagConstraints medidas = new GridBagConstraints();
		display.setLayout(layout);
		medidas.fill = GridBagConstraints.BOTH;
		
		JPanel matA = new JPanel();
		matA.setLayout(new BorderLayout());
		matA.setBorder(BorderFactory.createTitledBorder("Dados do Aluno"));
		matA.add("Center",texA);
		medidas.gridx = 0;
		medidas.gridy = 0;
		medidas.gridwidth = 1;
		medidas.gridheight = 1;
		medidas.weightx = 0.3;
		medidas.weighty = 1;
		layout.setConstraints(matA, medidas);
		display.add(matA);
		
		 
		
		JPanel control1 = new JPanel();
		control1.setLayout(new BoxLayout(control1, BoxLayout.X_AXIS));
		control1.setBorder(BorderFactory.createTitledBorder("Entrada dados"));
		control1.add(l1);
		control1.add(t1);
		control1.add(l2);
		control1.add(t2);
		control1.add(l3);
		control1.add(t3);
		control1.add(l4);
		control1.add(t4);
		medidas.gridx = 0;
		medidas.gridy = 1;
		medidas.gridwidth = 3;
		medidas.gridheight = 1;
		medidas.weightx = 1.0;
		medidas.weighty = 0.0;
		layout.setConstraints(control1, medidas);
		display.add(control1);
		
		JPanel control2 = new JPanel();
		control2.setLayout(new BoxLayout(control2, BoxLayout.X_AXIS));
		control2.setBorder(BorderFactory.createTitledBorder(""));
		control2.add(l5);
		control2.add(t5);
		control2.add(l6);
		control2.add(t6);
		control2.add(l7);
		control2.add(t7); 
		medidas.gridx = 0;
		medidas.gridy = 2;
		medidas.gridwidth = 3;
		medidas.gridheight = 1;
		medidas.weightx = 1.0;
		medidas.weighty = 0.0;
		layout.setConstraints(control2, medidas);
		display.add(control2);
		
		JPanel oper = new JPanel();
		oper.setLayout(new BoxLayout(oper, BoxLayout.X_AXIS));
		oper.setBorder(BorderFactory.createTitledBorder("Opera��es"));
		oper.add(ins);
		oper.add(credito);
		oper.add(media);
		medidas.gridx = 0;
		medidas.gridy = 3;
		medidas.gridwidth = 3;
		medidas.gridheight = 1;
		medidas.weightx = 1.0;
		medidas.weighty = 0.0;
		layout.setConstraints(oper, medidas);
		display.add(oper);
		
		 
		
		media.addActionListener(this);
		ins.addActionListener(this);
		
		addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent e) {
				System.exit(0);
			}
		});
	}
     
	public void actionPerformed(ActionEvent e) {
		if (e.getSource() == ins) {
			 //DiscipBase Aux = new DiscipBase( t1.getText() , t2.getText() , Integer.parseInt(t3.getText()) , Integer.parseInt(t4.getText()) , Integer.parseInt(t5.getText()) , Integer.parseInt(t6.getText()) , Integer.parseInt(t7.getText())); 
			 new Disciplinas().add( t1.getText() , t2.getText() , Integer.parseInt(t3.getText()) , Integer.parseInt(t4.getText()) , Integer.parseInt(t5.getText()) , Integer.parseInt(t6.getText()) , Integer.parseInt(t7.getText())); 
		}
		
		
		if (e.getSource() == media) {
						 
			if ((t2.getText()==("obrigatorio")) || (t2.getText()==("optativa")) || (t2.getText()==("elitiva"))){			
			new Disciplinas().MediaP(t2.getText());}
			
			}
	   if (e.getSource() == credito) {
			new Disciplinas().Calc_Credito(); 
		}
	}
}

class poosub {
/* Programa principal. Inicializa e posiciona as janelas do programa. */
	static String disc;
	static String tipo;
	static int Credito_teo;
	static int Credito_lab;
	static int Credito_prat;
	static int periodo;
	static int count,countg;
	static int i;
	static w window;
    static String Aux;
	static char aux;
	static int ct=0,cp=0,cl=0,ca=0;
	static CurrBase[] Curr;
     
 
	
	public static void main(String args[]) throws Exception 
	{
		count=0;
		countg=0;
		Aux=""; 
         
	  	InputStream data = new FileInputStream("data.txt");
	 
        window = new w();
		Insets insets1 = window.getInsets();
		window.setTitle("Testezinho simples.");
		window.setSize(1000 + insets1.left + insets1.right, 600 + insets1.top + insets1.bottom);
		window.setLocation(0,0);
		window.setVisible(true);
       
       
       
       
       
       
       
       
       
       
       
       
       System.out.println("heloow");
        
        
        
        
        
        
        
        
        
        
        
        
        while ( aux != '<') {
        	  while (count<6){
        		do{
        			  
        			aux = ((char) data.read());
	                
		             System.out.println(""+aux+"");
       
	                if (aux != ',')
	                   Aux += aux;
	                 System.out.println(Aux);            
	             }while (aux != ',');
	               
	             if (count==0){ 
	             	disc = Aux;}
	                else{
	                if (count==1){
	             	   tipo = Aux;}
	                   else{
	                   if (count==2){
	                      Credito_teo=Integer.valueOf(Aux).intValue();
	                      ct+=Credito_teo;
	                      ca+=Credito_teo;}
	                      else{
	                      if (count==3){
	                         Credito_prat=Integer.valueOf(Aux).intValue();
	                         cp+=Credito_prat;
	                         ca+=Credito_prat;}
	                         else{
	                         if (count==4){
	                            Credito_lab=Integer.valueOf(Aux).intValue();
	                            cl+=Credito_lab;
	                            ca+=Credito_lab;}
	                            else{
	                            if (count==5){
	                               periodo=Integer.valueOf(Aux).intValue();
	                           }
	                          }
	                        }
	                      }	                      }
	                   }
	             	
	             count++;   
 	             Aux=("");
 	               
 	            }
 	            
 	            CurrBase Hist = new CurrBase(disc,tipo,Credito_teo,Credito_prat,Credito_lab,periodo);
 	            CurrBase[] Curr = new CurrBase[100];
 	            System.out.println(""+aux+""); 
 	            Curr[countg] = Hist;
 	            
 	            countg++;
 	            count=0;
 	          }
		
	   System.out.println("lasichlic");
	   poosub.window.texA.append("Media Ponderada(Discipli");
	   poosub.window.texA.append("Media Ponderada(Disciplinas");
	
		
		
		
		
		
	/*	window = new w();
		Insets insets1 = window.getInsets();
		window.setTitle("Testezinho simples.");
		window.setSize(1000 + insets1.left + insets1.right, 600 + insets1.top + insets1.bottom);
		window.setLocation(0,0);
		window.setVisible(true);*/
        
	     
	
}}