Modo de Usar :
     Coloque o arquivo Bacharelado em Ciencias da Computacao.txt no diretorio 
               C:\Windows\Desktop\

    Execute o programa History.java

     1-  Escolha o curso.
     2- No panel Estrutura curricular padrao voce vera a Grade curricular
     3- Abaixo insira os nomes das disciplinas e as notas, como no exemplo abaixo :
           ex:   Geometria 7
                  ICCII 6
                  Hipermidia 9
     
     Obs.: Nao insira qualquer outro caractere. Tambem nao esque�a de colocar
             nome da disciplina seguido da nota.

     4- Clique no bot�o OK ao lado.
     5- Abaixo selecione um tipo de credito
     6- Clique em Ver resumo...


     Obs.: Para novas consultas sera preciso reiniciar o programa.

     Problemas ??  Comunique:
                        thor@.grad.icmc.usp.br