//Aluno : Alessandro G. Krempi nUsp 3457930

import javax.swing.*;
import javax.swing.text.*;
import java.awt.*;
import java.io.*;
import java.util.StringTokenizer;
import java.awt.event.*;
import javax.swing.event.*;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;



public class History extends JPanel {
	
						   
    private String [] curseNames = {"---------- Escolha Curso ------------",
    							    "Bacharelado em Ciencias da Computa��o",};
						   
    private RandomAccessFile input;
    private JComboBox cursos;
    private JTextArea structDefault;
    private JTextArea disciplinas;
    String str = "", name = "";
    private double nota = 0, credteo = 0,credprat = 0,credlab = 0;
    private int numcredObrTot = 0, numcredOpTot = 0, numcredEleTot = 0;
    private int numcredPrat=0, numcredTeo=0, numcredLab=0;
    private int credAtual=0 ;
    private int rbutton = 0;
    private double somaObr=0,somaOpt=0, somaElet=0;
    
    private double crdTeoTotal = 62;
    private double crdPraTotal = 30; 
	private double crdLabTotal = 6;
	
    private double hrTeoTotal = 62;
    private double hrPraTotal = 15;
	private double hrLabTotal = 12;
	
	private String info="";
	private String infoteo="",infopra ="",infolab="";
	
	private JRadioButton teoria, pratica, laboratorio;
	
	JTextArea informStudent;
	
	public History(){
	 
	setLayout(new BorderLayout());
       	
	//////////////////////////////////////////////////
	cursos     = new JComboBox ( curseNames );
	cursos.setPreferredSize(new Dimension(350,20));
	cursos.addActionListener(   new ActionListener() {
	    public void actionPerformed( ActionEvent e ){
	      
	      name = curseNames[ cursos.getSelectedIndex()  ];
	      if(  openFile(name)  ) {
	
	        try { 
	            str ="";
	            structDefault.setText(str);
	            while (!( str == null ) )      {
	              str =  readFile();
	              structDefault.append( str );
	              structDefault.append("\n");  }
	          
	           }
	          
	
	        catch( IOException ioe ) {
	               JOptionPane.showMessageDialog(null,"Erro De Leitura do Arquivo",
	                                                   "Error",JOptionPane.ERROR_MESSAGE );
	                System.exit( 1 );
	                                           }///catch
	       }//if
	
	     }} );
	
	
	JPanel n1 = new JPanel(new BorderLayout());
	JPanel n0 = new JPanel(new BorderLayout());
	n1.setBorder(new TitledBorder(new EtchedBorder(), "Selecione Curso"));
	n1.add(cursos, BorderLayout.WEST);
	
	
	structDefault  = new JTextArea(7,18);
	JScrollPane scrollstruct = new JScrollPane(structDefault);
	scrollstruct.setBorder(new TitledBorder(new EtchedBorder(), "Estrutura Curricular Padr�o"));
	
	n0.add(n1,BorderLayout.CENTER);
	n0.add(scrollstruct,BorderLayout.SOUTH);
	
	add(n0,BorderLayout.NORTH);
	
	/////////////////////////////////////////////////////////////////      
	JPanel c1 = new JPanel(new FlowLayout());
	c1.setBorder(new TitledBorder(new EtchedBorder(), "Inclua Disciplinas e Notas"));
	JPanel c0 = new JPanel(new BorderLayout());
	c0.setBorder(new TitledBorder(new EtchedBorder(), ""));
	
	
	
	
	disciplinas    = new JTextArea(6,40);
	
    JScrollPane scrolldislist = new JScrollPane(disciplinas);
    //scrolldislist.setBorder(new TitledBorder(new EtchedBorder(), "Disciplinas"));
	 
	
	
	JButton OkButton = new JButton("OK") ;
	OkButton.setPreferredSize(new Dimension(120,20));
	OkButton.addActionListener(   
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {
             String stockPhrase = disciplinas.getText();
             String line =  structDefault.getText();
             String ch = "", ch1 = "";
             String dis1="", dis2= "";
             
             
             StringTokenizer tokenAt = new StringTokenizer(stockPhrase);
      		 
      		 
      		 
      		 
            		while (tokenAt.hasMoreTokens() ){
            			
            			StringTokenizer tokenAq = new StringTokenizer(line);
            			
            			dis1 = tokenAt.nextToken();
            			
            			while( tokenAq.hasMoreTokens()){
            			   			  
            			  dis2 = tokenAq.nextToken();
            			  
            			  			  
            			  if ( dis1.equalsIgnoreCase(dis2) ){//disciplinas
            			  	
            			  	ch = tokenAq.nextToken();//pega tipo
            			  	
            			  	if (ch.equalsIgnoreCase("obrigatoria") ){
            			  		
            			  		ch1 = tokenAt.nextToken();
            			  		nota = Integer.parseInt(ch1);//le nota
            			  		
            			  		
            			  		ch1 = tokenAq.nextToken();
            			  		credteo = Integer.parseInt(ch1);//cred teor
            			  		numcredObrTot += credteo; 
            			  		credAtual += credteo;
            			  		numcredTeo += credteo;
            			  		
            			  		
            			  		ch1 = tokenAq.nextToken();
            			  		credprat = Integer.parseInt(ch1);//cred prat
            			  		numcredObrTot += credprat;
            			  		credAtual += credprat;
            			  		numcredPrat += credprat;
            			  		
            			  		
            			  		ch1 = tokenAq.nextToken();
            			  		credlab = Integer.parseInt(ch1);//cred lab
            			  		numcredObrTot += credlab;
            			  		credAtual += credlab;
            			  		numcredLab += credlab;
            			  		
            			  		
            			  		
            			  		somaObr += nota*credAtual; 
            			  		credAtual =0;
            			  		}//if obr
            			  		
            			  	if (ch.equalsIgnoreCase("optativa") ){
            			  		
            			  		ch1 = tokenAt.nextToken();
            			  		nota = Integer.parseInt(ch1);//le nota
            			  		
            			  		
            			  		ch1 = tokenAq.nextToken();
            			  		credteo = Integer.parseInt(ch1);//cred teor
            			  		numcredOpTot += credteo; 
            			  		credAtual += credteo;
            			  		numcredTeo += credteo;
            			  		
            			  		
            			  		ch1 = tokenAq.nextToken();
            			  		credprat = Integer.parseInt(ch1);//cred prat
            			  		numcredOpTot += credprat;
            			  		credAtual += credprat;
            			  		numcredPrat += credprat;
            			  		
            			  		
            			  		ch1 = tokenAq.nextToken();
            			  		credlab = Integer.parseInt(ch1);//cred lab
            			  		numcredOpTot += credlab;
            			  		credAtual += credlab;
            			  		numcredLab += credlab;
            			  	
            			  		
            			  		somaOpt += nota*credAtual; 
            			  		credAtual =0;
            			  		}//if opt
            			  		
            			  		
            			  	if (ch.equalsIgnoreCase("eletiva") ){
            			  		
            			  		ch1 = tokenAt.nextToken();
            			  		nota = Integer.parseInt(ch1);//le nota
            			  		
            			  		
            			  		ch1 = tokenAq.nextToken();
            			  		credteo = Integer.parseInt(ch1);//cred teor
            			  		numcredEleTot += credteo; 
            			  		credAtual += credteo;
            			  		numcredTeo += credteo;
            			  		
            			  		
            			  		ch1 = tokenAq.nextToken();
            			  		credprat = Integer.parseInt(ch1);//cred prat
            			  		numcredEleTot += credprat;
            			  		credAtual += credprat;
            			  		numcredPrat += credprat;
            			  		
            			  		
            			  		ch1 = tokenAq.nextToken();
            			  		credlab = Integer.parseInt(ch1);//cred lab
            			  		numcredEleTot += credlab;
            			  		credAtual += credlab;
            			  		numcredLab += credlab;
            			  		
            			  		
            			  		somaElet += nota*credAtual; 
            			  		credAtual =0;
            			  		}//if opt
            			  	}//if
            			
            			} }
           } 
         }
      );
	
		
	c0.add(OkButton,BorderLayout.NORTH);
	c1.add(scrolldislist);
	c1.add(c0);

	
	add(c1, BorderLayout.CENTER);
	
	///////////////////////////////////////////////////////////////////////////    
	
	JPanel s0 = new JPanel(new BorderLayout());
	s0.setBorder(new TitledBorder(new EtchedBorder(), "Creditos"));
	JPanel s1 = new JPanel(new BorderLayout());
	JPanel aux = new JPanel(new FlowLayout());
	
	JButton see = new JButton("Ver Resumo ...");
	see.addActionListener(
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {
             
             info +="Numero Total de Creditos Cursados:" + (numcredEleTot+numcredOpTot+numcredObrTot) + "\n";
             info +="Numero Total de Horas-Aula Cursadas:"+ (numcredTeo + numcredPrat*0.5 + numcredLab*2)+"\n";
             info +="Medias das disciplinas Obrigatorias :"+(somaObr/numcredObrTot)+"\n";
             info +="Medias das disciplinas Optativas :"+(somaOpt/numcredOpTot)+"\n";
             info +="Medias das disciplinas Eletivas :"+(somaElet/numcredEleTot)+"\n";
             switch (rbutton){

              case (0): 
                        infoteo += "Creditos Teoricos Restantes :"+(crdTeoTotal - numcredTeo)+"\n";
                        infoteo += "Horas-Aula Teorica Restantes :"+ (hrTeoTotal-numcredTeo)+"\n";
                        informStudent.setText(info);
                        informStudent.append(infoteo);
                        info = "";infoteo = "";
                        break;
 
              case (1): 
              			infopra += "Creditos Praticos Restantes :"+(crdPraTotal - numcredPrat)+"\n";
                        infopra += "Horas-Aula Praticas Restantes :"+(hrPraTotal-numcredPrat*0.5)+"\n";
                        informStudent.setText( info );
                        informStudent.append(infopra);
                        info = "";infopra = "";
                        break;
                          
              case (2): 
              			infolab += "Creditos de Laboratorio Restantes :"+(crdLabTotal - numcredLab)+"\n";
                        infolab += "Horas-Aula de Laboratorio Restantes :"+(hrLabTotal-numcredLab*2)+"\n";
                        informStudent.setText( info );
                        informStudent.append(infolab);
                        info = "";infolab = "";
                         
               }}});
	see.setPreferredSize(new Dimension(120,11));
	teoria  =  new JRadioButton("Credito Teorico",true);
	teoria.setPreferredSize(new Dimension(135,11));
	pratica =  new JRadioButton("Credito Pratico",false);
	pratica.setPreferredSize(new Dimension(135,11));
	laboratorio = new JRadioButton("Credito Laboratorio",false);
	laboratorio.setPreferredSize(new Dimension(135,11));
	
	ButtonGroup  radioGroup;
	
    RadioButtonHandler handler = new RadioButtonHandler();
    
    teoria.addItemListener( handler );
    pratica.addItemListener(handler );
    laboratorio.addItemListener(handler);
    
    aux.add(teoria);
    aux.add(pratica);
    aux.add(laboratorio);
    
    s0.add(aux, BorderLayout.WEST);
    s0.add(see,BorderLayout.EAST);
    
    radioGroup = new ButtonGroup();
      radioGroup.add( teoria );
      radioGroup.add( pratica );
      radioGroup.add( laboratorio );
    
    s1.add(s0,BorderLayout.CENTER);
    
    ////////////////////////////////////////////////////////////////////////
	informStudent  = new JTextArea(7,30);
	JScrollPane scrollinform = new JScrollPane(informStudent);
	scrollinform.setBorder(new TitledBorder(new EtchedBorder(), "Historico Curricular"));
	s1.add(scrollinform,BorderLayout.SOUTH);
    
	add(s1,BorderLayout.SOUTH);
    ////////////////////////////////////////////////////////////////////////////
    
  }//construtor
  
  
////////////////////////////////////////////////////////////////////////////////
private boolean openFile(String str)
   {

   try {
            input = new RandomAccessFile( "C:\\Windows\\Desktop\\"+str+".txt", "r" );
            return true;
        
         }//try
  catch ( IOException e ) {
             JOptionPane.showMessageDialog( this,"Arquivo Inexistente",
                                      "Arquivo Invalido",JOptionPane.ERROR_MESSAGE );
              return false;
                         }//catch

}//openFile
////////////////////////////////////////////////////////////////////////////////
 
 
private String readFile() throws IOException
{
 try{     return input.readLine();    }//try


 catch (EOFException eof)           {
       closeFile();
       return "Erro ao Ler Arquivo";  }//catch

 catch ( IOException e )              {
         JOptionPane.showMessageDialog( this, "Erro ao Ler Arquivo",
                                    "Erro",  JOptionPane.ERROR_MESSAGE );
         System.exit( 1 );
         return "Erro ao Ler Arquivo";}//catch
}//readfile

////////////////////////////////////////////////////////////////////////////////

private void closeFile(){

  try{      input.close();     }
  

  catch (IOException ex)      {
         JOptionPane.showMessageDialog( this, "Erro aoa Fechar Arquivo",
                                            "Erro", JOptionPane.ERROR_MESSAGE );
         System.exit( 1 );    }//catch
}//closefile

////////////////////////////////////////////////////////////////////////////////

    
    
    public static void main(String[] args) {
	
	 History c = new History();
	 JFrame f = new JFrame("");
	 
	 
	 
	 f.addWindowListener(new WindowAdapter() {
	 	public void windowClosing(WindowEvent e) {System.exit(0);}});
	 
	 f.getContentPane().add(c);
     //f.pack();
     f.setSize(605, 575);
     f.setVisible(true);
	}//main
	
////////////////////////////////////////////////////////////////////////////////
private class RadioButtonHandler implements ItemListener {
           public void itemStateChanged( ItemEvent e ) 
            {           
              if ( e.getSource() == teoria)     rbutton = 0;
              else if (e.getSource() == pratica) rbutton = 1;
              else if (e.getSource() == laboratorio) rbutton = 2;
            }
        }
    
}//classe