

EXECU�AO:

	clique no botao abrir_arq e selecione o arquivo "arquivo_dados.txt"(enviado anexo).
Selecione as disciplinas e insere as notas (no text area mais abaixo da janela)correpondentes
� quantidade de disciplinas selecionadas, a cada nota inserida, � necess�rio apertar "ENTER",
sendo que na ultima nota n�o � necess�ria.

EX:

8.0
9.0
6.0


Depois, basta apertar o botao "Executar". Sendo que a cada mudan�a da op��o de disciplinas restantes
('pratica','laboratorio','teorica') � necess�rio pressionar novamente o botao "Executar" para
atualizar a janela da interface.