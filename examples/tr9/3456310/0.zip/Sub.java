// Autores :
//       Chen Xu Sheng    3456310
//       Koji E. Sasaoka  3560665
//

import java.io.*;        // para a leitura dos dados a partir do arquivo
import java.awt.*;       // utilizada pelo swing
import java.awt.event.*; // utilizada pelo swing e nos botoes
import javax.swing.*;    // interface grafica
import javax.swing.filechooser.*;  // dialog box para escolher arquivo

/*-------------------------------------------------------
   classe que implementa a interface grafica com usuario
--------------------------------------------------------*/
public class Sub extends JPanel implements ActionListener 
{
    	private JFileChooser jfc_qual_arq;  // dialog box para a escolha do arquivo

	private int qtas;  

	private float total_horas_teoricas;  // numero total de horas-aula teoricas
	private float total_horas_praticas;  // numero total de horas-aula praticas
	private float total_horas_lab;  // numero total de horas-aula de laboratorio
	private int total_cred_teoricos;  // numero total de creditos teoricos
	private int total_cred_praticos;// numero total de creditos praticos
	private int total_cred_lab;  // numero total de creditos de laboratorio

	private List disc; 

	private JTextArea jta_restantes; // campo texto para creditos restantes
	private JTextArea jta_cursados;  // campo texto para creditos cursados
	private JTextArea jta_notas;  //  campo texto para notas das disciplinas cursadas

	private JTextField jtf_media;  // campo texto para media das disciplinas cursadas
	
	private JRadioButton    jrb_teorica;        // check box para mudanca de genero
	private JRadioButton    jrb_pratica;	// check box para mudanca de numero
	private JRadioButton    jrb_laboratorio;	// check box para mudanca de numero

	private JButton      btn_executar;	// botao para executar as funcionalidades requeridas
	private JButton      btn_arq;	 	// botao para abrir arquivos
	
	private String       nome_arq;		// nome do arquivo escolhido
	private File	     arq_dados;		// variavel do arquivo fisico
		

	private Disciplina[] disciplinas;  // vetor para aloacacao das disciplinas curriculares

	/*========================================================================*/
	/*  Metodo :  (construtor da classe).*/
	/** Construtor da classe Sub.
	 */
	/*========================================================================*/
	public Sub ()
	{
        	super(new BorderLayout());	// utiliza border layout para exibir os componentes

		// inicializa o text area que mostra numero de creditos cursados
        	this.jta_cursados = new JTextArea(5,20);
        	this.jta_cursados.setMargin(new Insets(5,5,5,5));
        	this.jta_cursados.setEditable(false);
        	this.jta_cursados.append ("Creditos e Horas Aula Cursados : \n \n");

		// inicializa o text area que mostra numero de creditos restantes
        	this.jta_restantes = new JTextArea(5,20);
        	this.jta_restantes.setMargin(new Insets(5,5,5,5));
        	this.jta_restantes.setEditable(false);
        	this.jta_restantes.append ("Creditos e Horas Aula Restantes : \n \n");

		// inicializa o text area que mostra notas das disciplinas cursadas
        	this.jta_notas = new JTextArea(5,20);
        	this.jta_notas.setMargin(new Insets(5,5,5,5));
        	this.jta_notas.setEditable(true);

		this.disc = new List(4, true);  // possibilidade de visualizacao de quatro disciplinas na tela, os restantes devem usar barra scroll

		// inicializa text field que mostra a media das notas das disciplinas cursadas 
		this.jtf_media = new JTextField(5);
		this.jtf_media.setEditable(false);
		

		// utilizado para setar a opcao "Teoricas" referente �s disciplinas
		this.jrb_teorica = new JRadioButton ("Teoricas");
		this.jrb_teorica.setSelected(true);

		// utilizado para setar a opcao "Praticas" referente �s disciplinas
		this.jrb_pratica = new JRadioButton ("Praticas");
		this.jrb_pratica.setSelected(false);

		// utilizado para setar a opcao "Lab" referente �s disciplinas
		this.jrb_laboratorio = new JRadioButton ("Lab");
		this.jrb_laboratorio.setSelected(false);
		        
		// utiliza scroll panel nos text area para que estem possam executar scroll
        	JScrollPane jsp_cursados = new JScrollPane(this.jta_cursados);
        	JScrollPane jsp_restantes = new JScrollPane(this.jta_restantes);
  
	      	JScrollPane jsp_notas = new JScrollPane(this.jta_notas);
		
		// para auxiliar o entendimento do usuario
		JLabel jlb_media = new JLabel("Media : ");

		// inicializa os botoes
        	btn_arq = new JButton("Abrir Arq");
        	btn_executar = new JButton("Executar");


        	ButtonGroup btg_grupo = new ButtonGroup();
        	btg_grupo.add(jrb_teorica);
        	btg_grupo.add(jrb_pratica);
        	btg_grupo.add(jrb_laboratorio);

        	this.jrb_teorica.addActionListener(this);
        	this.jrb_pratica.addActionListener(this);
        	this.jrb_laboratorio.addActionListener(this);


		// JPanel auxiliar no meio do jpanel maior
		JPanel jpn_outros = new JPanel (new BorderLayout());
		// dispondo e adicionando os radioButtons no panel
		JPanel jpn_radio = new JPanel (new GridLayout());
        	jpn_radio.add(this.jrb_teorica);
        	jpn_radio.add(this.jrb_pratica);
	       	jpn_radio.add(this.jrb_laboratorio);

		JPanel jpn_fields = new JPanel (new BorderLayout());
			
		// dispondo e adicionando o campo texto "notas", campo de exibicao "media" e label "media" no panel
        	jpn_fields.add(jsp_notas, BorderLayout.PAGE_START);
        	jpn_fields.add(jtf_media, BorderLayout.CENTER);
        	jpn_fields.add(jlb_media, BorderLayout.WEST);
		

		jpn_outros.add(disc, BorderLayout.PAGE_START);
        	jpn_outros.add(jsp_cursados, BorderLayout.WEST);
        	jpn_outros.add(jsp_restantes, BorderLayout.EAST);
		jpn_outros.add(jpn_radio, BorderLayout.CENTER);
		jpn_outros.add(jpn_fields, BorderLayout.PAGE_END);

		
      
		// eventos serao tratados por esta instancia de classe
        	btn_arq.addActionListener(this);
        	btn_executar.addActionListener(this);

		// posiciona os componentes no panel

        	add(btn_arq, BorderLayout.PAGE_START);
        	add(btn_executar, BorderLayout.PAGE_END);

		add(jpn_outros, BorderLayout.CENTER);

		this.disciplinas = new Disciplina[30];
	}
	
	/*========================================================================*/
	/*  Metodo : ActionPerformed.*/
	/** Chamada pelo botao btn_arq e btn_executar em resposta ao evento de clique.
	 */
	/*========================================================================*/
    	public void actionPerformed(ActionEvent e) 
    	{
    		Object fonte = e.getSource(); // verifica qual botao gerou o evento
    		String nome_arq;
    	
    		if (fonte == this.btn_arq)
    		{
        		// inicializa a janela de escolha de arquivo
			if (this.jfc_qual_arq == null) 
        		{
  				this.jfc_qual_arq = new JFileChooser();
	
    	        		this.jfc_qual_arq.setAcceptAllFileFilterUsed(false);
	        	}

			// exibe a janela
	        	int resposta_arq = this.jfc_qual_arq.showDialog(this, "Abrir arquivo");
	
			// se escolheu o arquivo armazena dados e chama metodo para carregar dados
    	    		if (resposta_arq == JFileChooser.APPROVE_OPTION) 
    	    		{
    	        		this.arq_dados = this.jfc_qual_arq.getSelectedFile();
    	        		nome_arq = new String(arq_dados.getPath() + "\\" + arq_dados.getName());
    	        
        			this.Ler_Dados();
        
    	    		} 

        		this.jfc_qual_arq.setSelectedFile(null);

	    		for (int i = 0; i < this.qtas; i++)
			{
				this.disc.add(this.disciplinas[i].getNome());
			}
    		}
	    	else if (fonte == this.btn_executar) // botao de modificar
	    	{	
			this.Executar();
	    	}
	 }

	/*========================================================================*/
	/** Carrega os dados do arquivo
	 */
	/*========================================================================*/
    	private void Ler_Dados() 
    	{
		int i;
		String nome_disciplina;
		String tipo;
		int periodo;

		int credito_pratico;
		int credito_teorico;
		int credito_laboratorio;

		InputStream arq_fis;  // usado para manipulacao de arquivo
      		InputStreamReader arq_logic;  // usado para manipulacao de arquivo
      		BufferedReader arq_buffer;  // usado para manipulacao de arquivo
		String dados;

		this.total_cred_lab = 0;  // total de creditos laboratorio
		this.total_horas_lab = 0;  // total de horas laboratorio

		this.total_cred_teoricos = 0;  // total de creditos teoricos
		this.total_horas_teoricas = 0;  // total de horas laboratorio

		this.total_cred_praticos = 0;  // total de creditos praticos
		this.total_horas_praticas = 0;  // total de horas laboratorio

      		try
      		{	// leitura do arquivo	
        		arq_fis = new FileInputStream(this.arq_dados);
           		arq_logic = new InputStreamReader(arq_fis);
           		arq_buffer = new BufferedReader(arq_logic);
			i = 0;

			while ((dados = arq_buffer.readLine()) != null)
			{
				String[] atributos;
				// associar valor para nome_disciplina
				atributos = dados.split(" ");
				nome_disciplina = atributos[0];
				tipo = atributos[1];
				credito_teorico = Integer.parseInt(atributos[2]); // associar valor para credito_teorico
				credito_pratico = Integer.parseInt(atributos[3]);  // associar valor para credito_pratico
				credito_laboratorio = Integer.parseInt(atributos[4]); // associar valor para credito_laboratorio
				periodo = Integer.parseInt(atributos[5]);  // associar valor periodo

				if (credito_teorico != 0)  // entra quando disciplina eh teorico
				{
					this.disciplinas[i] = new Disc_Teorica(nome_disciplina, tipo, credito_teorico, periodo);
					this.total_cred_teoricos += disciplinas[i].getCreditos();
					this.total_horas_teoricas += disciplinas[i].getHoras_Aula();
				}
				else if (credito_pratico != 0)  // entra quando disciplina eh pratica
				{
					this.disciplinas[i] = new Disc_Pratica(nome_disciplina, tipo, credito_pratico, periodo);
					this.total_cred_praticos += disciplinas[i].getCreditos();
					this.total_horas_praticas += disciplinas[i].getHoras_Aula();
				}
				else if (credito_laboratorio != 0)  //  entra quando disciplina eh de laboratorio
				{
					this.disciplinas[i] = new Disc_Lab(nome_disciplina, tipo, credito_laboratorio, periodo);
					this.total_cred_lab += disciplinas[i].getCreditos();
					this.total_horas_lab += disciplinas[i].getHoras_Aula();
				}


				i++;  // faz leitura de todas linha s
			}

			this.qtas = i;


	       		arq_fis.close();

      		}   	
		catch(IOException e) {};
 	}
	
	

	/*========================================================================*/
	/** metodo para execucao das funcionalidades da interface
	 */
	/*========================================================================*/
    	private void Executar() 
    	{
		String nome_radio;
		String txt_notas;
		String[] notas;
		int creditos;
		float nota;
		float total_nota = 0;

		int cred_curs_teoricos = 0;
		float horas_aula_curs_teoricas = 0;

		int cred_curs_praticos = 0;
		float horas_aula_curs_praticas = 0;

		int cred_curs_lab = 0;
		float horas_aula_curs_lab = 0;

		int creditos_restantes = 0;
		float horas_aula_restantes = 0;

		txt_notas = this.jta_notas.getText();  // pega as notas entradas pelo usuario
		if (txt_notas != "")
		{
			notas = txt_notas.split("\n");

			int[] selecionadas = this.disc.getSelectedIndexes();  // as disciplinas selecionadas pelo usuario como cursadas
			if (notas.length == selecionadas.length)
			{
				for (int cont = 0; cont < selecionadas.length; cont ++)
				{
					if (this.disciplinas[selecionadas[cont]].getTipo().compareTo("teorica") == 0)  // vai armazenando os creditos e as horas das disciplinas teoricas
					{
						nota = Float.parseFloat(notas[cont]);
						creditos = this.disciplinas[selecionadas[cont]].getCreditos();
						total_nota += (nota * creditos);				
	
						cred_curs_teoricos += creditos;
						horas_aula_curs_teoricas += this.disciplinas[selecionadas[cont]].getHoras_Aula();
					}
					else if (this.disciplinas[selecionadas[cont]].getTipo().compareTo("pratica") == 0)  // vai armazenando os creditos e as horas das disciplinas praticas
					{
						nota = Float.parseFloat(notas[cont]);
						creditos = this.disciplinas[selecionadas[cont]].getCreditos();
						total_nota += (nota * creditos);				

						cred_curs_praticos += creditos;
						horas_aula_curs_praticas += this.disciplinas[selecionadas[cont]].getHoras_Aula();
					}
					else if (this.disciplinas[selecionadas[cont]].getTipo().compareTo("laboratorio") == 0)  // vai armazenando os creditos e as horas das disciplinas de laboratorio
					{
						nota = Float.parseFloat(notas[cont]);
						creditos = this.disciplinas[selecionadas[cont]].getCreditos();
						total_nota += (nota * creditos);				
	
						cred_curs_lab += creditos;
						horas_aula_curs_lab += this.disciplinas[selecionadas[cont]].getHoras_Aula();
					}
				}
	

			}
			else
			{
				System.out.println("Numero de Notas digitadas incorreto.");
			}
		}
		else
		{
			System.out.println ("Notas nao Digitadas");
		}

		// auxiliar o entendimento do usuario		
		this.jta_cursados.setText("Creditos e Horas Aula Cursados : \n \n");
   		// saida dos creditos teoricos cursados pelo usuario
		this.jta_cursados.append("Creditos Teoricos Cursados : " + cred_curs_teoricos + "\n");
   		// saida das horas-aula teoricas cursadas pelo usuario
		this.jta_cursados.append("Horas Aula Teoricas Cursadas : " + horas_aula_curs_teoricas + "\n\n");

   		// saida dos creditos praticos cursados pelo usuario
		this.jta_cursados.append("Creditos Praticos Cursados : " + cred_curs_praticos + "\n");
   		// saida das horas-aula praticas cursadas pelo usuario
		this.jta_cursados.append("Horas Aula Praticas Cursadas : " + horas_aula_curs_praticas + "\n\n");

   		// saida dos creditos de laboratorio cursados pelo usuario
		this.jta_cursados.append("Creditos Lab Cursados : " + cred_curs_lab + "\n");
   		// saida das horas-aula de laboratorio cursadas pelo usuario
		this.jta_cursados.append("Horas Aula Lab Cursadas : " + horas_aula_curs_lab + "\n");

		if (this.jrb_teorica.isSelected() == true)  // saida dos creditos e horas-aula teoricos restantes para formatura do usuario
		{
			nome_radio = " Teor. ";
			creditos_restantes = this.total_cred_teoricos - cred_curs_teoricos;
			horas_aula_restantes = this.total_horas_teoricas - horas_aula_curs_teoricas;
		}
		else if (this.jrb_pratica.isSelected() == true)  // saida dos creditos e horas-aula praticos restantes para formatura do usuario
		{
			nome_radio = " Prat. ";
			creditos_restantes = this.total_cred_praticos - cred_curs_praticos;
			horas_aula_restantes = this.total_horas_praticas - horas_aula_curs_praticas;
		}
		else  // saida dos creditos e horas-aula de laboratorio restantes para formatura do usuario
		{
			nome_radio = " Lab. ";
			creditos_restantes = this.total_cred_lab - cred_curs_lab;
			horas_aula_restantes = this.total_horas_lab - horas_aula_curs_lab;
		}


		this.jta_restantes.setText("Creditos e Horas Aula Restantes : \n \n");
		this.jta_restantes.append("Creditos Restantes " + nome_radio + " : " + creditos_restantes + "\n");
		this.jta_restantes.append("Horas Aula Restantes " + nome_radio + " : " + horas_aula_restantes + "\n");
	
		nota = total_nota/(cred_curs_teoricos + cred_curs_praticos + cred_curs_lab);
		
		this.jtf_media.setText(Float.toString(nota));

	}
	
	    		
	/*========================================================================*/
	/** Programa Principal.	 */
	/*========================================================================*/
	public static void main (String args[])
	{

        	JFrame jf_principal = new JFrame("Exercio SUB de Java");
        	jf_principal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        	JComponent teste = new Sub();
	      	teste.setOpaque(true);
        	jf_principal.setContentPane(teste);

		// exibe a janela
        	jf_principal.pack();
        	jf_principal.setVisible(true);

	}
}

	
	
	

