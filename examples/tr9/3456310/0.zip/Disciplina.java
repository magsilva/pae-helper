
abstract class Disciplina
{
	protected String nome_disciplina;  // indica nome da disciplina
	protected String tipo;  // indica tipo da disciplina
	protected int periodo;  // indica periodo da disciplina
	protected int creditos;  // indica numero creditos da disciplina
	protected float nota;  // indica nota da disciplina
	protected boolean cursou;  


	/*========================================================================*/
	/*/  Construtor da classe para inicializacao das variaveis
	/*========================================================================*/
	public Disciplina(String nome, String tipo, int creditos, int periodo)
	{
		this.nome_disciplina = new String(nome);
		this.tipo = tipo;
		this.periodo = periodo;
		this.creditos = creditos;	

		this.nota = 0;
		this.cursou = false;
	}

	/*========================================================================*/
	/*/  assinatura do metodo para definicao na classe derivada
	/*========================================================================*/
	public abstract float getHoras_Aula ();




	/*========================================================================*/
	/*/  
	/*========================================================================*/
	public float getNota()
	{
		return this.nota;
	}


	/*========================================================================*/
	/*/  metodo que retorna o nome da disciplina
	/*========================================================================*/
	public String getNome()
	{
		return this.nome_disciplina;
	}

	/*========================================================================*/
	/*/  metodo que retorna o tipo da disciplina
	/*========================================================================*/
	public String getTipo()
	{
		return this.tipo;
	}



	/*========================================================================*/
	/*/  indica se aluno jah cursou a disciplina
	/*========================================================================*/
	public void setCursou(boolean cursou)
	{
		this.cursou = cursou;
	}


	/*========================================================================*/
	/*/  retorna numero creditos
	/*========================================================================*/
	public int getCreditos()
	{
		return this.creditos;
	}


}



/*========================================================================================*/
/*  classe derivada da classe abstrata Disciplina para sobreescrita do metodo getHoras_Aula
/*========================================================================================*/
class Disc_Teorica extends Disciplina
{
	public Disc_Teorica(String nome, String tipo, int periodo, int creditos)
	{
		super(nome, tipo, periodo, creditos);
	}
	
	public float getHoras_Aula ()  // metodo para retorno das horas-aula das disciplinas teoricas
	{
		return this.creditos;
	}
}



/*=========================================================================================*/
/*/  classe derivada da classe abstrata Disciplina para sobreescrita do metodo getHoras_Aula
/*=========================================================================================*/
class Disc_Pratica extends Disciplina
{
	
	public Disc_Pratica(String nome, String tipo, int periodo, int creditos)
	{
		super(nome, tipo, periodo, creditos);
	}

	public float getHoras_Aula ()  // metodo para retorno das horas-aula das disciplinas praticas
	{
		return ((float)this.creditos/2);
	}
}





/*=========================================================================================*/
/*/  classe derivada da classe abstrata Disciplina para sobreescrita do metodo getHoras_Aula
/*=========================================================================================*/
class Disc_Lab extends Disciplina
{
	
	public Disc_Lab(String nome, String tipo, int periodo, int creditos)
	{
		super(nome, tipo, periodo, creditos);
	}


	public float getHoras_Aula ()  // metodo para retorno das horas-aula das disciplinas de laboratorio
	{
		return (2 * this.creditos);
	}
}