From rael@grad.icmc.usp.br Tue Mar 18 23:52:08 2003
Return-Path: <rael@grad.icmc.usp.br>
Received: from mail.grad.icmc.usp.br (lab3-01.grad.icmc.usp.br.231.107.143.in-addr.arpa [143.107.231.9] (may be forged))
	by mail.icmc.usp.br (8.12.3/8.12.3) with ESMTP id h2J2rXmE026762;
	Tue, 18 Mar 2003 23:53:33 -0300 (EST)
Received: from mail.grad.icmc.usp.br (localhost [127.0.0.1])
	by mail.grad.icmc.usp.br (8.12.5/8.12.5) with ESMTP id h2J2q9bl011932;
	Tue, 18 Mar 2003 23:52:09 -0300 (EST)
Received: (from www@localhost)
	by mail.grad.icmc.usp.br (8.12.5/8.12.5/Submit) id h2J2q8o1011931;
	Tue, 18 Mar 2003 23:52:08 -0300 (EST)
X-Authentication-Warning: mail.grad.icmc.usp.br: www set sender to rael@grad.icmc.usp.br using -f
Received: from 200.206.141.133 ( [200.206.141.133])
	as user rael@mail.grad.icmc.usp.br by mail.grad.icmc.usp.br with HTTP;
	Tue, 18 Mar 2003 23:52:08 -0300
Message-ID: <1048042328.3e77db581fc4c@mail.grad.icmc.usp.br>
Date: Tue, 18 Mar 2003 23:52:08 -0300
From: rael@grad.icmc.usp.br
To: renata@icmc.usp.br,
 magsilva@icmc.usp.br
Subject: =?ISO-8859-1?B?RXhlcmPtY2lvcyBQTw==?=O (primeira parte)
MIME-Version: 1.0
Content-Type: text/plain;
  charset=ISO-8859-1
Content-Transfer-Encoding: 8bit
User-Agent: Internet Messaging Program (IMP) 3.1
X-Originating-IP: 200.206.141.133
Status: RO
X-Status: O


  Alunos: Rael G. Cunha, Glauco A. Becaro


1.1

def compara(x,y):
    if (x>y): return 1
    if (x==y): return 0
    if (x<y): return -1


1.2

import math
def distancia():
    x1 = input("x1:")
    y1 = input("y1:")
    x2 = input("x2:")
    y2 = input("y2:")
    dx = x2 - x1
    dy = y2 - y1
    dsquared = dx**2 + dy**2
    result = math.sqrt(dsquared)
    print result

1.3

def isBetween(x, y, z):
    if (y<=x)and(x<=z): return 1
    else: return 0

1.4

def fibonacci(n):
    if (n==0) or (n==1) : return 1
    else:
        print "fibonacci",(n-1),"+ fibonacci",(n-2)
        return fibonacci(n-1)+ fibonacci(n-2)

1.5

def reverso(texto):
    tamanho = len(texto)
    while(tamanho>0):
        print texto[tamanho-1]
        tamanho = tamanho - 1

1.6

def ocorrencia(texto,c):
    tamanho = 0
    contador = 0
    while(tamanho<len(texto)):
        if (texto[tamanho]==c): contador = contador + 1
        tamanho = tamanho + 1
    return contador

1.7

def conta_palavras(frase,palavra):
    return string.count(frase, palavra)




-------------------------------------------------
This mail sent through IMP: http://horde.org/imp/


