def reversew(str):
    list(str)
#    print str[2]
    i=len(str)-1
    for g in str:
        print str[i]
        i-=1

a="Socorram me subi no onibus em marrocoS"
reversew(a)
