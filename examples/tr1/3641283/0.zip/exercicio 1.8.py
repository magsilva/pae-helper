import math

def div(x):
    dx1=x % 100
    dx2=x /100
    if math.sqrt(x)==(dx1+dx2):
        print x

def allnum():
    x=1000
    while x<=9999:
        div(x)
        x+=1


allnum()
