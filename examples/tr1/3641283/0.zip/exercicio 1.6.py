def acha(str,x):
    return str.count(x)


print acha("abacate","a")
