def compare(x,y):
    if x > y:
      return 1
    elif x == y:
      return 0
    else :
      return -1

a=5
b=5
print compare(a,b)
