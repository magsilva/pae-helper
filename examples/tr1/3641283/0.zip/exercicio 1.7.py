def acha(str,s):
    i=0
    nro=0
    for m in str:
        nro+=str.startswith(s,i)
        i+=1
    print nro

acha('banana','ana')
