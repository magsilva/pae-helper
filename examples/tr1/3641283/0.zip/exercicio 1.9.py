def acha(str,s):
    i=0
    nro=0
    for m in str:
        nro+=str.startswith(s,i)
        i+=1
    print nro

def achanum(p,q):
    r=str(p)
    s=str(q)
    if len(r)<=len(s):
        acha(s,r)




p=23
q=25342343423
achanum(p,q)
