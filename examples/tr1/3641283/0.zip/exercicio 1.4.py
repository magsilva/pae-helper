
def fibonacci(n):
    if n==0 or n==1:
        return 1
    else:        
        x=fibonacci(n-1)+fibonacci(n-2)
        return x
    
#obrigado monica !
def fibo(n):
    x=0
    while(x<n):
        print fibonacci(x)
        x+=1


a=input("n:")
fibo(a)
