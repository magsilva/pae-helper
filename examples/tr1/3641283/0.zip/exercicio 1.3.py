

def isbetween(x,y,z):
    if y<=x:
        if x<=z:
            return 1
        else :
            return 0


a=input("x:")
b=input("y:")
c=input("z:")

print isbetween(a,b,c)
