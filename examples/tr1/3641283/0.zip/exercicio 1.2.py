import math

def distancia():
    x1=input("Digite x1:")
    x2=input("Digite x2:")
    y1=input("Digite y1:")
    y2=input("Digite y2:")
    dx=x2-x1
    dy=y2-y1
    dsquared=dx**2+dy**2
    print math.sqrt(dsquared)


distancia()
