def compara(palavra,letra):
    palavra1 = palavra
    letra1 = letra
    tamanho = len(palavra)
    cont = 0
    x = 0
    print (tamanho)
    while(x<tamanho):
        if(palavra1[x]==letra1):
            cont = cont +1
        x= x+1
    print cont

palavra =" "
letra =" "
print"Digite qualquer palavra:"
raw_input(palavra)
print"Digite qualquer letra:"
raw_input(letra)

compara(palavra,letra)





