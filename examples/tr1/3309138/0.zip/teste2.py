import math
     
def distancia(x1,y1,x2,y2):
    dx=x2-x1
    dy=y2-y1
    dsquared=dx**2+dy**2
    result=math.sqrt(dsquared)
    return result

x1 = 3
y1 = 4
x2 = 7
y2 = 9
print ("Entre com o valor de x1: ")
int (raw_input(x1))
print ("Entre com o valor de y1: ")
int (raw_input(y1))
print ("Entre com o valor de x2: ")
int (raw_input(x2))
print ("Entre com o valor de y2: ")
int (raw_input(y2))
print (distancia (x1, y1, x2, y2))
