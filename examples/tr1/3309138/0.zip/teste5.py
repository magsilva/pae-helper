def letras(name):
    tamanho = 0
    tamanho = len(name)
    while tamanho<>0:
        print (name[tamanho])
        tamanho = tamanho -1



name ="  "
print("Digite uma string qualquer:")
raw_input(name)
letras(name)
        
