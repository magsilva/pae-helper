def isbetween(x,y,z):
    if(y<=x) and (x<=z):
        print 1
    else:
        print 0

    
