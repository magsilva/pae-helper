def igual():
    tamanho1=10
    tamanho2=0
    tamanho3=0
    tamanho4=0
    for(tamanho1<99):
        for(tamanho2<99):
            tamanho3 = tamanho1 + tamanho2
            tamanho4 = tamanho3*tamanho3
            if tamanho4>1000 and tamanho4<9999:
                print tamanho4
            tamanho2 = tamanho2 +1
        tamanho1 = tamanho1 +1


        
            
        
