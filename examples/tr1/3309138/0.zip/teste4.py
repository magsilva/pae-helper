def fibonacci(n):
    fib0 = 1
    fib1 = 1
    x = n
    if n==0:
        print fib0
    elif n==1:
        print fib0
        print fib1
    else:
        if n>=2:
            print fib0
            print fib1
            while(x>1):
                aux = fib0
                fib0 = fib1
                fib1 = aux + fib0
                x = x-1
                print fib1


            
            
            
    
    
    
