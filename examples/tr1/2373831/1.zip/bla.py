x = 10
if x < 100:
    print 'Negative changed to zero'
    x = 0
    print x
