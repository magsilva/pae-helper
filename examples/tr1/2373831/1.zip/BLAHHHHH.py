{\rtf1\ansi\ansicpg1252\deff0\deflang1046{\fonttbl{\f0\fswiss\fcharset0 Courier New;}{\f1\fswiss\fcharset0 Arial;}}
{\*\generator Msftedit 5.41.15.1503;}\viewkind4\uc1\pard\tx0\tx959\tx1918\tx2877\tx3836\tx4795\tx5754\tx6713\tx7672\tx8631\f0\fs20  x = int(raw_input("Please enter an integer: "))\par
 if x < 0:\par
      x = 0\par
      print 'Negative changed to zero'\par
 elif x == 0:\par
      print 'Zero'\par
 elif x == 1:\par
      print 'Single'\par
 else:\par
      print 'More'\par
\par
\pard\f1\par
}
 