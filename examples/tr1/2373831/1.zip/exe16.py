def contaST(x,y):
    cont = 0
    for a in range(len(x)):
        if x[a]== y:
            cont = cont+1
    return cont




b = raw_input("entre com uma frase:")

c = raw_input("entre com uma letra:")

print contaST(b,c)
