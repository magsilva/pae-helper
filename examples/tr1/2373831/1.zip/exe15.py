def inverte(x):
    for a in range(len(x),0,-1):
        print x[a-1]



        
b = raw_input("entre com uma frase:")

inverte(b)

b = raw_input("acabou")
    
