def compare(x,y):
    if x > y:
        print 1
    elif x == y:
        print 0
    elif x < y:
        print -1
    
compare(3,4)
