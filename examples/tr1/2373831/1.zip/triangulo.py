c = [10,20,30]
if c[0]== (c[1]**2)+(c[2]**2):
    print 'forma triangulo retangulo'
else:
    print 'nao forma triangulo retangulo'
