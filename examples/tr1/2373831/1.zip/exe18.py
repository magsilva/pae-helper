import math

def milhar():
    
    for a in range(1000,10000,1):
        dez1=int(a/100)
        dez2=int(a%100)
        if math.sqrt(a) == dez1+dez2:
            print a
        

milhar()
