def fibonacci (n):
    if n == 0 or n == 1:
        return 1
       
    else:
        a=(fibonacci(n-1) + fibonacci(n-2))
        print a
        return a


fibonacci (5)


a = raw_input("acabou")

