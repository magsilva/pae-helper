import math

def isBetween(x,y,z):
    if y <= x and x <= z:
        result = 1
    else:
        result = 0
    return result



x = int(raw_input("entre com o valor de x:"))
y = int(raw_input("entre com o valor de y:"))
z = int(raw_input("entre com o valor de z:"))






print isBetween(x,y,z)


a = raw_input("acabou")
