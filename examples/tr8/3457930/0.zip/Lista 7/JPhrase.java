////  Alunos : Alessandro G. Krempi , nUsp 3457930  
/////          Breno H. Leitao      , nUsp 3457711
//////......

/// Utilizada pela classe NewLook2 : efetua as alteracoes nos textos.
////....

import java.util.StringTokenizer;

public class JPhrase
{ 

	private  String [] Masc = {"Um" ,"Uns" ,"um" ,"uns" ,"o"   ,"os"  ,"O" ,"Os"};
	private  String [] Fem  = {"Uma","Umas","uma","umas","a"   ,"as"  ,"A" ,"As"};
	private  String [] Sing = {"Um" ,"um"  ,"O"  ,"o"   ,"Uma" ,"uma" ,"A" ,"a" };
	private  String [] Pl   = {"Ums","uns" ,"Os" ,"os"  ,"Umas","umas","As","as"};


////////////////////////////////////////////////////////////////////////////////////////////////////
	public String gen( String s){


		String stockPhrase ,slaveString;
		String output= "";
		int cont = 0;
              
        stockPhrase = s ;

		StringTokenizer tokens = new StringTokenizer(stockPhrase);//quebra

		while ( tokens.hasMoreTokens() ){
             	
		  slaveString = tokens.nextToken();
		  cont ++;

		  if (cont == 3)  output += " " + slaveString;
		
		  else {
  
		        for (int i = 0; i< 8; i++) {
		            if ( slaveString.endsWith(Masc[i]) ) {
		                output += " " + slaveString.substring(0,slaveString.lastIndexOf(Masc[i])) + Fem[i];
		                break;}
		
		             else if ( slaveString.endsWith(Fem[i])){
		                output += " " + slaveString.substring(0,slaveString.lastIndexOf(Fem[i])) + Masc[i];  
		                break;}

		         }//for  
                
		       if (cont == 5) {   output += "\n"; cont = 0; }
                            	        
		       } //else 
        }//while 
	    return output;   

	}//gen

/////////////////////////////////////////////////////////////////////////////////////////////////////

	public String num(String s){
	
	String stockPhrase ,slaveString;
	String output= "";
	int cont = 0;
	              
	stockPhrase = s;
	
	StringTokenizer tokens = new StringTokenizer(stockPhrase);//quebra
	
	while ( tokens.hasMoreTokens() ){
             	
	  slaveString = tokens.nextToken();
	  cont ++;

	  if (cont == 3 ){
	    if  (!slaveString.endsWith("m") ) output += " " + slaveString + "m" ;
	    else output += " " + slaveString.substring(0,slaveString.lastIndexOf("m"));}

     else {

	      for (int i = 0; i< 8; i++) {
	         if ( slaveString.endsWith(Sing[i]) ) {
	            output += " " + slaveString.substring(0,slaveString.lastIndexOf(Sing[i])) + Pl[i];
	            break;}
	
	         else if ( slaveString.endsWith(Pl[i])){
	            output += " " + slaveString.substring(0,slaveString.lastIndexOf(Pl[i])) + Sing[i];  
	            break;}
	       }//for
       
        if (cont == 5) {   output += "\n"; cont = 0; }
     }//else
    } return output;//while
  }//numero
 }//classe