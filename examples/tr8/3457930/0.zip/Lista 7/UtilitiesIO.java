////  Alunos : Alessandro G. Krempi , nUsp 3457930  
/////          Breno H. Leitao      , nUsp 3457711
//////......

/// Utilizada pela classe NewLook2 : efetua as operacoes com arquivos.
////....


import java.io.*;
import javax.swing.*;

public class UtilitiesIO

{ 

	private RandomAccessFile input        , ouput         ;
	private File             fileNameInput, fileNameOutput;

/////////////////////////////////////////////////////////////////////////////////////////////////////
	public RandomAccessFile openFile()
	   {
	
	         JFileChooser fileChooser = new JFileChooser("");
	         
	
	         fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY );
	         int result = fileChooser.showOpenDialog( null );
	
	         if ( result == JFileChooser.CANCEL_OPTION ) return null;
	
	         fileNameInput = fileChooser.getSelectedFile();
	      
	
	      if ( fileNameInput == null ||  fileNameInput.getName().equals( "" )){
	         JOptionPane.showMessageDialog( null,"Arquivo Invalido","Arquivo Invalido", JOptionPane.ERROR_MESSAGE );
	         return null;
	      }
	      else {
	         // 
	         try {
	                  
	            input = new RandomAccessFile( fileNameInput, "r" );
	            return input;
	            
	         }
	         catch ( IOException e ) {
	            JOptionPane.showMessageDialog( null,"Arquivo Inexistente","Arquivo Invalido",JOptionPane.ERROR_MESSAGE );
	            return null;
	         }      
	      }
	   }//openfile
   
/////////////////////////////////////////////////////////////////////////////////////////////////////
	public String readFile() throws IOException
	{
	 try{
	     return input.readLine();
	    }
	
	 catch (EOFException eof){
	    closeFile(input);
	    return "erro";
	 }
	 catch ( IOException e ) {
	         JOptionPane.showMessageDialog( null,"Erro de Leitura do Arquivo ","Erro",JOptionPane.ERROR_MESSAGE );
	         System.exit( 1 );
	         return "erro";
	      }
	} //readfile

/////////////////////////////////////////////////////////////////////////////////////////////////////

	private void closeFile(RandomAccessFile fileWork){
	
	  try{
	      fileWork.close();
	     }
	  catch (IOException ex){
	
	         JOptionPane.showMessageDialog( null,"Erro ao Fechar Arquivo", "Error", JOptionPane.ERROR_MESSAGE );
	         System.exit( 1 );
	      }
	  }//closefile

/////////////////////////////////////////////////////////////////////////////////////////////////////

	public void saveFile(String texto)
	 {   	
	      //RandomAccessFile arq;
	      //File fileNa;
	      
	      JFileChooser fileChooser = new JFileChooser();
	
	      fileChooser.setFileSelectionMode( JFileChooser.FILES_ONLY );
	      int result = fileChooser.showSaveDialog( null);
	     
	      if ( result == JFileChooser.CANCEL_OPTION ) return;
	
	      fileNameOutput = fileChooser.getSelectedFile();
	
	      if ( fileNameOutput == null ||  fileNameOutput.getName().equals( "" ) )
	         JOptionPane.showMessageDialog( null,"Arquivo Invalido","Arquivo Invalido",JOptionPane.ERROR_MESSAGE );
	      else {
	         
	         try {
	            ouput = new RandomAccessFile( fileNameOutput, "rw" );
	            ouput.seek(ouput.length());
	            ouput.writeBytes(texto);
	            
	         }
	         catch ( IOException e ) {
	            JOptionPane.showMessageDialog( null,"Arquivo Inexistente","Arquivo Invalido",JOptionPane.ERROR_MESSAGE );
	         }      
	      }
	   }
/////////////////////////////////////////////////////////////////////////////////////////////////////	   
}//classe