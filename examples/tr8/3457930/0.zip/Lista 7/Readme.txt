Instrucoes :

     Compilar Classes :  UtilitiesIO;
                         NewWindow  ;
                         JPhrase    ;
                         NewLook2   ;

     Executar Classe :   NewLook2   ;


