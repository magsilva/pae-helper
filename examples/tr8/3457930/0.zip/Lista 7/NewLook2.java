////  Alunos : Alessandro G. Krempi , nUsp 3457930  
/////          Breno H. Leitao      , nUsp 3457711
//////......


/// NewLooK2 Prov� interface ao usuario
//// Utiliza as classes auxiliares :
///// UtilitiesIO;NewWindow;JPhrase; 
//////...

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.border.Border;
import javax.swing.border.TitledBorder;
import javax.swing.*;

public class NewLook2 extends JFrame 
 {
  
  JTextArea areaTexto  =   new JTextArea(9, 25);
  JTextArea areaSaida  =   new JTextArea(9, 25);
  
  int   rbutton = 0;
  String str, var = "";
  
       
  private JRadioButton Genero, Numero,GenNum ;
  private ButtonGroup radioGroup;


public NewLook2 () {
        
        super(" Genero & Numero ");
        
        /////////////////Bordas
        Border raisedbevel   =  BorderFactory.createRaisedBevelBorder();
        Border loweredbevel  =  BorderFactory.createLoweredBevelBorder();
        Border compound      =  BorderFactory.createCompoundBorder(raisedbevel, loweredbevel);
        
        TitledBorder title1 = BorderFactory.createTitledBorder("Texto Original");
        title1.setTitleJustification(TitledBorder.LEFT);
        
        TitledBorder title2 = BorderFactory.createTitledBorder("Texto Alterado");
        title2.setTitleJustification(TitledBorder.LEFT);
        
        TitledBorder title3 = BorderFactory.createTitledBorder("Menu");
        title3.setTitleJustification(TitledBorder.CENTER);
        
        
        ///Botoes
        JButton compor   =  new JButton( "Compor " )    ;
        JButton abrir    =  new JButton( "Abrir  " )    ;
        JButton desfazer =  new JButton( "Desfazer")    ;
        JButton sair     =  new JButton( "Sair   " )    ;
        JButton alterar  =  new JButton( "  Alterar  " );
        JButton resetar  =  new JButton( "   Reset   ") ;
        
        
//////////////////////////////////////////////////////////////////////////////////////////////////
        JPanel leftUp    =   new JPanel() ;
          areaTexto.setBorder(compound)   ;
          areaTexto.setEditable(false)    ;        
          leftUp.setBorder(title1)        ;
          leftUp.add(areaTexto)           ;
        
///////////////////////////////////////////////////////////////////////////////////////////////////
        JPanel centerUp  = new JPanel(new GridLayout(5,1));
        JPanel upPanel   = new JPanel()                   ;
        
        /////Compoe um novo Texto para Teste
        compor.addActionListener( 
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {
              NewWindow f = new NewWindow();
               f.pack();
               f.setVisible(true);
               }});
        
        /////Abre Arquivo Para Teste
        abrir.addActionListener(
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {
               UtilitiesIO f = new UtilitiesIO();
            	
               if(f.openFile()!= null) 
                  {
                  	try{
                  		str = "";
                  		areaTexto.setText(str);
                  		areaSaida.setText(str);
                  		while (!(str == null)){
                    	   str =  f.readFile();
                  	       areaTexto.append(str);
                  	       areaTexto.append("\n");
                  	      }
                  	   }
                  	       
                    catch( IOException ioe ) {
                       JOptionPane.showMessageDialog(null,"Erro de Leitura","Erro",JOptionPane.ERROR_MESSAGE );
                        System.exit( 1 ); }//catch

                  }
             }//actionPerformed
         } );
        
        /////Termina Execuc�o do Programa
        sair.addActionListener(
          new ActionListener() {
             public void actionPerformed( ActionEvent e )
             {
               System.exit(0);
 
              } } );//actionPerformed
        
        centerUp.add(compor);centerUp.add(abrir);
        centerUp.add(desfazer);centerUp.add(sair);   
        centerUp.setBorder(title3);
        upPanel.setBorder(raisedbevel);
        upPanel.add(centerUp);
         
/////////////////////////////////////////////////////////////////////////////////////////////////
        JPanel mainUpPanel = new JPanel(new FlowLayout());
          mainUpPanel.add(leftUp) ;
          mainUpPanel.add(upPanel);
     
        
/////////////////////////////////////////////////////////////////////////////////////////////////
        JPanel leftMiddle = new JPanel() ;
          areaSaida.setBorder(compound)  ;
          areaSaida.setEditable(true)    ;     
          leftMiddle.setBorder(title2)   ;
          leftMiddle.add(areaSaida)      ;
/////////////////////////////////////////////////////////////////////////////////////////////////
        JPanel centerMiddle = new JPanel(new GridLayout(5,1));
        JPanel middlePanel  = new JPanel();
        
         Genero = new JRadioButton( " Genero  ", true  ) ;
         Numero = new JRadioButton( " Numero  ", false ) ;
         GenNum = new JRadioButton( " Gen\\Num ",false ) ;
        
        /////Executa Alteracoes
        alterar.addActionListener(
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {   
             JPhrase f = new JPhrase();
            
             switch (rbutton){

              case (0): areaSaida.setText( f.gen(areaTexto.getText()) );
                        break;
 
              case (1): var = areaTexto.getText();
                        areaSaida.setText( f.num(var) );
                        break;
                          
              case (2): var = f.gen(areaTexto.getText());
                        areaSaida.setText( f.num(var));}
               }});

        /////Limpa Area de Texto
        resetar.addActionListener(
          new ActionListener() {
             public void actionPerformed( ActionEvent e )
             {
               areaSaida.setText("");  } } );
        
        centerMiddle.add(Genero);centerMiddle.add(Numero);centerMiddle.add(GenNum);
        
        
        /// Relacao Logica entre Botoes
        RadioButtonHandler handler = new RadioButtonHandler();
        Genero.addItemListener( handler );
        Numero.addItemListener( handler );
        GenNum.addItemListener( handler );
        
        centerMiddle.add(alterar);centerMiddle.add(resetar);
        
        TitledBorder title4 = BorderFactory.createTitledBorder("Altera��es");
        title4.setTitleJustification(TitledBorder.CENTER);
        centerMiddle.setBorder(title4);

        middlePanel.setBorder(raisedbevel);
        middlePanel.add(centerMiddle);
     

/////////////////////////////////////////////////////////////////////////////////////////////////
        JPanel mainMiddlePanel = new JPanel(new FlowLayout());
          mainMiddlePanel.add(leftMiddle) ;
          mainMiddlePanel.add(middlePanel);

/////////////////////////////////////////////////////////////////////////////////////////////////
       JPanel mainPanel = new JPanel(new GridLayout(2,1));
         mainPanel.add(mainUpPanel)       ;
         mainPanel.add(mainMiddlePanel)   ;
         mainPanel.setBorder(loweredbevel);
         setContentPane(mainPanel)        ;


/////////////////////////////////////////////////////////////////////////////////////////////////
 
        // cria relacao logica entre Radio Buttons
        radioGroup = new ButtonGroup();
        radioGroup.add( Genero );
        radioGroup.add( Numero );
        radioGroup.add( GenNum );

       
}

/////////////////////////////////////////////////////////////////////////////////////////////////
public static void main(String[] args) {
        final NewLook2 frame = new NewLook2();
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);}   });

        frame.pack();
        frame.setVisible(true);
    }
    
/////////////////////////////////////////////////////////////////////////////////////////////////

private class RadioButtonHandler implements ItemListener {
           public void itemStateChanged( ItemEvent e ) 
            {           
              if ( e.getSource() == Genero)     rbutton = 0;
              else if (e.getSource() == Numero) rbutton = 1;
              else if (e.getSource() == GenNum) rbutton = 2;
            }}

} //classe NewLook2