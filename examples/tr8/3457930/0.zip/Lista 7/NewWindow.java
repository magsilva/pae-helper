////  Alunos : Alessandro G. Krempi , nUsp 3457930  
/////          Breno H. Leitao      , nUsp 3457711
//////......

/// Utilizada pela classe NewLook2 : cria nova area de trabalho.
////....

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class NewWindow extends JFrame
{

  private UtilitiesIO utilitie = new UtilitiesIO();
    
  public NewWindow(){

  super("Salvar ...")  ;

  JPanel  mainNewPanel = new JPanel(new BorderLayout( ));
  JPanel  textPanel = new JPanel();
  JPanel  north,south;
  JPanel  buttonPanel = new JPanel(new GridLayout(1,2));
  final  JTextArea newText = new JTextArea(10,40);
  JButton save = new JButton("Salvar");
  JButton cancel = new JButton("Cancelar");

  textPanel.add(newText);
  north = new JPanel ();
  north.add(textPanel);
 
  buttonPanel.add(save);
  buttonPanel.add(cancel);
  south = new JPanel();
  south.add(buttonPanel);
  
  mainNewPanel.add(north,BorderLayout.NORTH);
  mainNewPanel.add(south,BorderLayout.SOUTH);
  setContentPane(mainNewPanel);

  save.addActionListener( 
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {
             utilitie.saveFile(newText.getText());          
             setVisible(false);
            }});


  cancel.addActionListener( 
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {
              setVisible(false);
                       
            }} );
  } //construtor
}//classe