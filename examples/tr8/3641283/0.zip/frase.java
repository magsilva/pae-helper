import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.*;

public class frase extends JFrame implements ActionListener{
	
	private JButton BtExit = new JButton("Exit");
	private JButton BtNumero = new JButton("Numero");
	private JButton BtGenero = new JButton("Genero");
	private JLabel Label1 = new JLabel("Frase Original");
	private JLabel Label2 = new JLabel("Frase Modificada");
	private JTextField Tf = new JTextField(30);
	private JTextField Tf2 = new JTextField(30);	
	
	public frase(){  
		Container c = this.getContentPane();
		c.setLayout(new FlowLayout());    

		 
		c.add(Label1);
		c.add(Tf);
		c.add(BtNumero);
		c.add(BtGenero);
		c.add(Label2);
		c.add(Tf2);
		c.add(BtExit); 
		
		BtNumero.addActionListener(this);
		BtGenero.addActionListener(this);
		BtExit.addActionListener(this);
		Tf.addActionListener(this);
		Tf2.addActionListener(this);

		
		this.setSize(350, 200);
		this.show();
	}
	
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource() == BtExit){//executa quando clica no exit
			System.exit(0);
		}

		else if(e.getSource()== BtNumero){//executa quando clica no botao numero		
			JFileChooser filechooser = new JFileChooser();
			if(filechooser.showOpenDialog(this.getContentPane()) != JFileChooser.CANCEL_OPTION){
				try{
					File file = filechooser.getSelectedFile();
					byte buffer[] = new byte[(int)file.length()];
					FileInputStream input = new FileInputStream(file);
					input.read(buffer);
					String data = new String(buffer);
					Tf.setText(data);
					String str = data.replaceAll(" ","s ");
					char temp[] = str.toCharArray();
					
					int aux=0;
					int cont=0;
					
					for (int i=0 ; i < temp.length ; i++){
						while (cont < 3){
							if (temp[i] == ' '){
								aux = i;
								cont+=1;
							}
							i++;
						}
						
						temp[aux-1]='m';
						str = "";
						for (i=0 ; i < temp.length ; i++){
							str += temp[i];	
						}
						
						Tf2.setText(str+"s");
					}			
				}
				
				catch(IllegalArgumentException ex){}
				catch(IOException exe){}
				
			}	
		}
		
		
		
		else if(e.getSource()== BtGenero){//FUNCAO NAO FUNCIONA .......executa quando clica no botao genero		
			JFileChooser filechooser = new JFileChooser();
			if(filechooser.showOpenDialog(this.getContentPane()) != JFileChooser.CANCEL_OPTION){
				try{
					File file = filechooser.getSelectedFile();
					byte buffer[] = new byte[(int)file.length()];
					FileInputStream input = new FileInputStream(file);
					input.read(buffer);
					String data = new String(buffer);
					Tf.setText(data);
					String str= data;
					
					str = str.replaceAll("O ","A ");
					str = str.replaceAll("o ","a ");
					str.replaceAll("os ","as ");
					
					
					Tf2.setText(str);
					
				}
				
				catch(IllegalArgumentException ex){}
				catch(IOException exe){}
				
			}	
		}
		
		
		
	}
	
	
	
	
	public static void main(String args[]){
		frase _frase = new frase(); 
	}
	
}
