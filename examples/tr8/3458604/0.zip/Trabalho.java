import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.text.DecimalFormat;
import java.io.*;
import Pacote.*;

public class Trabalho extends JFrame implements ActionListener
{
   // Objetos de interface grafica
   private JLabel lblOriginal, lblModificada;
   private JTextArea txtOriginal, txtModificada;
   private JButton btnAlterar, btnAbrir;
   private JCheckBox chkNumero, chkGenero;
   
   // Vetor de strings que guarda as frases
   String Linhas[] = new String[50];
   int num_linhas;

   // Arquivo
   File arquivo;

   // Construtor
   public Trabalho()
   {
      super( "Trabalho de Java" );
      Container container = getContentPane();
      container.setLayout( new FlowLayout() );

      // Criacao dos componentes da tela
      btnAbrir = new JButton( "Abrir arquivo" );
      btnAbrir.addActionListener( this );
      container.add( btnAbrir );

      lblOriginal = new JLabel( "Frase original" );
      txtOriginal = new JTextArea( 5, 30 );
      txtOriginal.setEditable( false );
      container.add( lblOriginal );
      container.add( txtOriginal );
      
      lblModificada = new JLabel( "Frase modificada" );
      txtModificada = new JTextArea( 5, 30 );
      txtModificada.setEditable(false);
      container.add( lblModificada );
      container.add( txtModificada );

      chkNumero = new JCheckBox( "Alterar n�mero" );
      chkGenero = new JCheckBox( "Alterar g�nero" );
      container.add( chkNumero );
      container.add( chkGenero );
      
      btnAlterar = new JButton( "Alterar" );
      btnAlterar.addActionListener( this );
      container.add( btnAlterar );
     

      setSize(350,300);
      setVisible( true );
   }

   // Procedimento que verifica qual evento ocorreu
   public void actionPerformed( ActionEvent actionEvent )
   {
      // btnAbrir
      if ( actionEvent.getSource() == btnAbrir )
         AbreArquivo();

	  // btnAlterar 
      else if ( actionEvent.getSource() == btnAlterar )
         Alterar();
      
   }

   // Programa Principal
   public static void main( String args[] )
   {
      Trabalho application = new Trabalho();
      application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
   }

   // Procedimento que abre o arquivo
   protected void AbreArquivo()
   {
      JFileChooser fchArquivo = new JFileChooser();
      int returnValue = fchArquivo.showOpenDialog( this );
      
      int i = 0;

      if ( returnValue == JFileChooser.APPROVE_OPTION )
      {
         // Abertura do arquivo

         arquivo = fchArquivo.getSelectedFile();

         try
         {
            BufferedReader reader = new BufferedReader( new InputStreamReader( new FileInputStream( arquivo ) ) );
            String linha = reader.readLine();
            while ( linha != null )
            {
               txtOriginal.append( linha + "\n" );
               if ( linha != null )
                 Linhas[i] = linha;
               linha = reader.readLine();
               i++;
            }
            num_linhas = i;   
         }

         catch ( FileNotFoundException e ) {} // arquivo nao encontrado
         catch ( EOFException e ) {} // fim do arquivo
         catch ( IOException e ) {} // outro erro de entrada/saida

      }
   }

   // Procedimento que realiza as alteracoes
   protected void Alterar()
   {
   	  String new_genero, new_numero;
   	  Frase frase;
   	  int i = 0;
   	  
   	  for ( i = 0; i <= num_linhas; i++)
   	  {
   	     frase = new Frase( Linhas[i] );
   	     new_genero = frase.genero;
   	     new_numero = frase.numero;	
         
         if ( chkNumero.isSelected() )
            txtModificada.setText( new_numero );
         if ( chkGenero.isSelected() )
            txtModificada.setText( new_genero );
            
         i++;
      }
   } 
      	 
}      