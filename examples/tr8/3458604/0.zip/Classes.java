package Pacote;

// Classes utilizadas no programa

import java.lang.*;

// Frase
class Frase
{
	public String genero, numero;
	
    Frase( String linha )
    {
    	String[] palavras;
    	Artigo_Definido artdef; 
    	Substantivo sub1, sub2;
    	Verbo verbo;
    	Artigo_Indefinido artindef;
    	String sub_aux, genero, numero;
        
	    // Separa cada palavra da frase
        palavras = linha.split(" ");
        artdef = new Artigo_Definido(palavras[0]);
    	sub1 = new Substantivo(palavras[1]);
	    verbo = new Verbo(palavras[2]);
        artindef = new Artigo_Indefinido(palavras[3]);
        sub_aux = palavras[4].concat("\\n");
    	sub2 = new Substantivo(sub_aux);

	    // Altera numero e genero
	    genero = altera_genero(artdef, sub1, verbo, artindef, sub2);
        numero = altera_numero(artdef, sub1, verbo, artindef, sub2);
	}

    protected String altera_numero(Artigo_Definido artdef, Substantivo sub1, Verbo verbo, Artigo_Indefinido artindef, Substantivo sub2)
    {
    	String new_artdef, new_sub1, new_verbo, new_artindef, new_sub2, new_frase;

        // Altera cada elemento em sua respectiva classe

        new_artdef = artdef.altera_numero();
        new_sub1 = sub1.altera_numero();
        new_verbo = verbo.altera_numero();
        new_artindef = artindef.altera_numero();
        new_sub2 = sub2.altera_numero();

        new_frase = new_artdef + " " + new_sub1 + " " + new_verbo + " " + new_artindef + " " + new_sub2 + ".";

		return new_frase;
	}
          
    protected String altera_genero(Artigo_Definido artdef, Substantivo sub1, Verbo verbo, Artigo_Indefinido artindef, Substantivo sub2)
    {
    	String new_artdef, new_sub1, new_verbo, new_artindef, new_sub2, new_frase;

        // Altera cada elemento em sua respectiva classe

        new_artdef = artdef.altera_genero();
        new_sub1 = sub1.altera_genero();
        new_verbo = verbo.word;
        new_artindef = artindef.altera_genero();
        new_sub2 = sub2.altera_genero();

        new_frase = new_artdef + " " + new_sub1 + " " + new_verbo + " " + new_artindef + " " + new_sub2 + ".";
        
        return new_frase;
	}
}

// Palavra
class Palavra
{   
	public String word;
	     
    Palavra( String param )
    {
        word = param;
	}

/*    protected String altera_genero()
    {
        String new_word = Frase.altera_genero();
        return new_word;
    }

    protected String altera_numero()
    {
        String new_word = Frase.altera_numero();
        return new_word;
    }*/
}

// Substantivo
class Substantivo extends Palavra
{
	public String word, numero, genero;
	
    Substantivo(String param)
    {
        super( param );
        numero = get_numero();
        genero = get_genero();
	}

    protected String get_numero()
    {
    	String numero;
        int tamanho = word.length();
        String ultima_letra = word.substring(tamanho - 1);
        if (ultima_letra == "S")
            numero = "plural";
        else
            numero = "singular";

        return numero;
	}

    protected String get_genero()
    {
    	String ultima_letra;
        int tamanho = word.length();
        if (numero == "singular")
            ultima_letra = word.substring(tamanho - 1);
        else
            ultima_letra = word.substring(tamanho - 2);

        if (ultima_letra == "O")
            genero = "masculino";
        else
            genero = "feminino";

        return genero;
	}

    protected String altera_numero()
    {
    	String new_word;
    	int tamanho = word.length();
        if (numero == "singular")
            new_word = word + "s";
        else
            new_word = word.substring(0, tamanho - 2);

        return new_word;
	}

    protected String altera_genero()
    {
    	String new_word, new_word2;
        new_word = word;
        int tamanho = word.length();

        if (genero == "masculino")
            if (numero == "singular")
            {
                new_word2 = word.substring(0, tamanho - 2);
                new_word = new_word2 + "a";
        	}
            else
            {
                new_word2 = word.substring(0, tamanho - 3);
                new_word = new_word2 + "as";
            }
        else
            if (numero == "singular")
            {
                new_word2 = word.substring(0, tamanho - 2);
                new_word = new_word2 + "o";
            }
            else
            {
                new_word2 = word.substring(0, tamanho - 3);
                new_word = new_word2 + "os";
            }

        return new_word;
    }
}

// Artigo Definido
class Artigo_Definido extends Substantivo
{
    Artigo_Definido(String param)
    {
        super( param );
    }
}

// Artigo Indefinido
class Artigo_Indefinido extends Palavra
{
	public String word, numero, genero;
	
    Artigo_Indefinido(String param)
    {
        super( param );
        numero = get_numero();
        genero = get_genero();
    }

    protected String get_numero()
    {
    	String ultima_letra;
        int tamanho = word.length();
        
        ultima_letra = word.substring(tamanho - 1);

        if (ultima_letra ==  "S")
            numero = "plural";
        else
            numero = "singular";

        return numero;
    }

    protected String get_genero()
    {
    	String ultima_letra;
        int tamanho = word.length();
        
        if (numero == "singular")
            ultima_letra = word.substring(tamanho - 1);
        else
            ultima_letra = word.substring(tamanho - 2);
            
        if (ultima_letra == "A")
            genero = "feminino";
        else
            genero = "masculino";

        return genero;
    }

    protected String altera_numero()
    {
    	String new_word, new_word2;
    	int tamanho = word.length();
    	
        if (numero == "singular")
            if (genero == "feminino")
                new_word = word + "s";
            else
            {
                new_word2 = word.substring(0, tamanho - 2);
                new_word = new_word2 + "ns";
            }
        else
            if (genero == "feminino")
                new_word = word.substring(0, tamanho - 2);
            else
            {
                new_word2 = word.substring(0, tamanho - 3);
                new_word = new_word2 + "m";
            }

        return new_word;
    }

    protected String altera_genero()
    {
    	String new_word, new_word2;
    	int tamanho = word.length();
    	
        if (genero == "feminino")
            if (numero == "singular")
                new_word = word.substring(0, tamanho - 2);
            else
            {
                new_word2 = word.substring(0, tamanho - 4);
                new_word = new_word2 + "ns";
            }
        else
            if (numero == "singular")
                new_word = word + "a";
            else
            {
                new_word2 = word.substring(0, tamanho - 3);
                new_word = new_word2 + "mas";
            }

        return new_word;
    }
}

// Verbo
class Verbo extends Palavra
{
	public String word, numero;
	
    Verbo(String param)
    {
        super( param );
        numero = get_numero();
    }

    protected String get_numero()
    {
    	String ultima_letra;
        int tamanho = word.length();

        ultima_letra = word.substring(tamanho - 1);

        if (ultima_letra == "M")
            numero = "plural";
        else
            numero = "singular";

        return numero;
    }

    protected String altera_numero()
    {
    	String new_word;
    	int tamanho = word.length();

        if (numero == "singular")
            new_word = word + "m";
        else
            new_word = word.substring(0, tamanho - 2);

        return new_word;
    }
}

