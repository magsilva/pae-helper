package carol;

import java.util.Vector;

class Frase {
	
	private Palavra[] originais;
	
	public Frase (String frase){
		
		String[] f = frase.split(" ");
		
		originais = new Palavra[5];

		if (("A".compareTo(f[0].toUpperCase()) == 0)||("O".compareTo(f[0].toUpperCase()) == 0)) {
			originais[0] = new ArtigoDefinido(f[0]);
		} else {
			originais[0] = new ArtigoIndefinido(f[0]);
		} 
		
	
		originais[1] = new Substantivo(f[1]);
		
		if ('a' == f[2].charAt(f[2].length() - 1)){
			originais[2] = new Primeira(f[2]);
		} else {
			originais[2] = new SegundaTerceira(f[2]);
		} 
		

		if (("a".compareTo(f[3]) == 0)||("o".compareTo(f[3]) == 0)) {
			originais[3] = new ArtigoDefinido(f[3]);
		} else {
			originais[3] = new ArtigoIndefinido(f[3]);
		} 
		
		originais[4] = new Substantivo(f[4]);
		
	}
	
	public String MudaGenero () {
		String ret = "";
		
		for (int i = 0; i < originais.length; i++){
			ret += " " + originais[i].MudaGenero();
		}
		
		return ret;
	}
	
	public String MudaNumero () {
		String ret = "";
		
		for (int i = 0; i < originais.length; i++){
			ret += " " + originais[i].MudaNumero();
		}
		
		return ret;
	}
	
	public String imprime() {
		
		String ret = "";
		
		for (int i = 0; i < originais.length; i++){
			ret += " " + originais[i].imprime();
		}
		
		return ret;
	}
}

interface Palavra {
	public abstract String imprime();
	public abstract String MudaGenero();
	public abstract String MudaNumero();
}

abstract class Verbo implements Palavra{
	public abstract String imprime();
	public abstract String MudaGenero();
	public abstract String MudaNumero();
}

class Primeira extends Verbo {
	
	private String verbo;
	
	public Primeira(String verb) {
		this.SetVerbo(verb);
	}
	
	private void SetVerbo (String v) {
		this.verbo = v;
	}
	
	private String GetVerbo () {
		return this.verbo;
	}
	
	public String imprime(){
		return this.GetVerbo();
	}

	public String MudaGenero(){
		return this.GetVerbo();
	}

	public String MudaNumero(){
		return this.GetVerbo() + "m";
	}
}

class SegundaTerceira extends Verbo {
	
	private String verbo;
	
	public SegundaTerceira (String verb) {
		this.SetVerbo(verb);
	}
	
	private void SetVerbo (String v) {
		this.verbo = v;
	}
	
	private String GetVerbo () {
		return this.verbo;
	}
	
	public String imprime(){
		return this.GetVerbo();
	}

	public String MudaGenero(){
		return this.GetVerbo();
	}

	public String MudaNumero(){
		return this.GetVerbo() + "m";
	}
}

class Substantivo implements Palavra {
	private String substantivo;
	
	public Substantivo (String subs){
		this.SetSubs(subs);
	}
	
	private void SetSubs(String s){
		this.substantivo = s;
	}
	
	private String getSubs() {
		return this.substantivo;
	}
	
	public String imprime() {
		return this.getSubs();
	}
	
	public String MudaGenero(){
		return (this.getSubs().substring(0,this.getSubs().length() - 1) + 
		((this.getSubs().lastIndexOf("a") == this.getSubs().length() - 1)?"o":"a"));
	}
	
	public String MudaNumero(){
		return (this.getSubs() + "s");
	}
}

abstract class Artigo implements Palavra{
	public abstract String imprime();
	public abstract String MudaGenero();
	public abstract String MudaNumero();
}

class ArtigoDefinido extends Artigo {
	private String artigo;
	
	public ArtigoDefinido(String art) {
		this.SetArt(art);
	}
	
	private void SetArt(String a) {
		this.artigo = a;
	}
	
	private String GetArt(){
		return this.artigo;
	}
	
	public String imprime() {
		return this.GetArt();
	}
	
	public String MudaGenero() {
		
		
		if ("A".compareTo(this.GetArt()) == 0) {
			 return "O";
		} else 
		
		if ("O".compareTo(this.GetArt()) == 0) {
			return "A";
		} else
		
		if ("a".compareTo(this.GetArt()) == 0) {
			return "o";
		} else
		
		if ("o".compareTo(this.GetArt()) == 0) {
			return "a";
		} else {
			return "";
		}
		
	}
	
	public String MudaNumero() {
		return (this.GetArt() + "s");
	}
}


class ArtigoIndefinido extends Artigo {
	private String artigo;
	
	public ArtigoIndefinido(String art) {
		this.SetArt(art);
	}
	
	private void SetArt(String a) {
		this.artigo = a;
	}
	
	private String GetArt(){
		return this.artigo;
	}
	
	public String imprime() {
		return this.GetArt();
	}
	
	public String MudaGenero() {
		
		if ("Uma".compareTo(this.GetArt()) == 0) {
			return ("Um");
		} else
		
		if ("Um".compareTo(this.GetArt()) == 0) {
			return ("Uma");
		} else
		
		if ("uma".compareTo(this.GetArt()) == 0) {
			return ("um");
		} else
		
		if ("um".compareTo(this.GetArt()) == 0) {
			return ("uma");
		} else {
			return "";
		}
		
	}
	
	public String MudaNumero() {
		if (this.GetArt().lastIndexOf("a") != -1) {
			return (this.GetArt() + "s");
		} else {
			return ("Um".compareTo(this.GetArt())==0)?"Uns":"uns";
		}
	}
}


