package carol;

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class gui extends JFrame {
   private BufferedReader input;
   private JButton nextRecord, open;
   private JTextField t;
   private JRadioButton original, genero, numero;
   private ButtonGroup radioGroup;
   
   private Frase frase;
   
   public static void main(String args[]){
 		gui t = new gui();
   }

   // Constructor -- initialize the Frame 
   public gui()
   {
      super( "Carolina Ferraz 3344524 - Frases" );

      getContentPane().setLayout( new BorderLayout() );
      
      nextRecord = new JButton();

      nextRecord.setText( "Proxima Frase" );
      nextRecord.setEnabled( false );  
 
      nextRecord.addActionListener(
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {               
				readRecord();
            }
         }
      );
 
      addWindowListener(
         new WindowAdapter() {
            public void windowClosing( WindowEvent e )
            {
               if ( input != null )
                  closeFile();

               System.exit( 0 );
            }
         }
      ); 
      
      
      open = new JButton();


      open.setText( "Abrir Arquivo" );
      open.addActionListener(
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            {
               openFile();
            }
         }
      );
      
      getContentPane().add( open,BorderLayout.NORTH );
      getContentPane().add( nextRecord,BorderLayout.SOUTH );
      
      JPanel c = new JPanel ();
      
      c.setLayout( new FlowLayout());
      
      t = new JTextField( "", 25 );

      t.setEditable(false);
      c.add( t ); 

      // Create radio buttons
      original = new JRadioButton( "Original", true );
      c.add( original );
      genero = new JRadioButton( "Mudar Gen�ro", false);
      c.add( genero );
      numero = new JRadioButton( "Mudar N�mero", false );
      c.add( numero );

      // register events
      RadioButtonHandler handler = new RadioButtonHandler();
      original.addItemListener( handler );
      genero.addItemListener( handler );
      numero.addItemListener( handler );

      // create logical relationship between JRadioButtons
      radioGroup = new ButtonGroup();
      radioGroup.add( original );
      radioGroup.add( genero );
      radioGroup.add( numero );
      
      original.setEnabled(false);
      genero.setEnabled(false);
      numero.setEnabled(false);

      getContentPane().add( c,BorderLayout.CENTER );
      
      
      pack();
      setSize( 300, 200 );
      setResizable(false);
      show();
   }
   
   private void openFile()
   {
      JFileChooser fileChooser = new JFileChooser();

      fileChooser.setFileSelectionMode(
         JFileChooser.FILES_ONLY );
      int result = fileChooser.showOpenDialog( this );
 
      // user clicked Cancel button on dialog
      if ( result == JFileChooser.CANCEL_OPTION )
         return;

      File fileName = fileChooser.getSelectedFile();
 
      if ( fileName == null ||
           fileName.getName().equals( "" ) )
         JOptionPane.showMessageDialog( this,
            "Invalid File Name",
            "Invalid File Name",
            JOptionPane.ERROR_MESSAGE );
      else {
         // Open the file
         try {
            input = new BufferedReader( new FileReader (fileName) );
            open.setEnabled( false );
            nextRecord.setEnabled( true );

      		original.setEnabled(true);
      		genero.setEnabled(true);
      		numero.setEnabled(true);
      		
      		this.readRecord();
         }
         catch ( IOException e ) {
            JOptionPane.showMessageDialog( this,
               "Error Opening File", "Error",
               JOptionPane.ERROR_MESSAGE );
         }      
      }
   }

   public void readRecord()
   {
      String record;

      // input the values from the file
      try {
      	record = input.readLine();
      	if (record != null) {
      		t.setText(record);
      		frase = new Frase(record);
      	} else {
      		throw new EOFException();
      	}
      }
      catch ( EOFException eofex ) {
         nextRecord.setEnabled( false );
	      original.setEnabled(false);
    	  genero.setEnabled(false);
	      numero.setEnabled(false);
    	  	open.setEnabled(true);
    	  	t.setText("");
         JOptionPane.showMessageDialog( this,
            "Nao ha mais frases no arquivo",
            "Fim de Arquivo", JOptionPane.ERROR_MESSAGE );
      }
      catch ( IOException ioex ) {
         JOptionPane.showMessageDialog( this,
            "Erro durante a leitura do arquivo",
            "Erro de leitura", JOptionPane.ERROR_MESSAGE );
      }
   }

   private void closeFile()
   {
      try {
         input.close();
         System.exit( 0 );
      }
      catch ( IOException e ) {
         JOptionPane.showMessageDialog( this,
            "Error closing file",
            "Error", JOptionPane.ERROR_MESSAGE );
         System.exit( 1 );
      }
   }
   
   private class RadioButtonHandler implements ItemListener {
      public void itemStateChanged( ItemEvent e )
      {
         if ( e.getSource() == original ) 
            t.setText(frase.imprime() );
         else if ( e.getSource() == genero ) 
            t.setText(frase.MudaGenero());
         else if ( e.getSource() == numero ) 
            t.setText(frase.MudaNumero());

         t.repaint();
      }
   }

}