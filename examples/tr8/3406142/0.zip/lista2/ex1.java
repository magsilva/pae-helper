/*Marcelo Kenji Hotta
 *3460142
 *kenji@grad.icmc.usp.br*/


import java.io.*;

/*Classe Ex1
 *Esta classe contem o main. Instancia as outras classes e imprime o resultado*/
class Ex1 {
    public static void main(String[] args) {
		
		//Setando o arquivo a ser lido
		String nomearquivo = "";
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in)); 
		
		System.out.println("==============Inicializado!==============");
		System.out.print("Digite o nome do arquivo a ser lido \n(ENTER para usar texto.txt): ");
		
		try{
			nomearquivo = in.readLine();
			if(nomearquivo.length() == 0){
				nomearquivo = "texto.txt";
			}
		}
		catch(IOException erro){
			System.out.println("nome invalido");
		}
		
		Arquivo A = new Arquivo(nomearquivo);
		//Setado o arquivo a ser lido
		
		Texto T = new Texto(A);
		for(int i=0; i<4; i++) System.out.println(T.frase[i].p3.Get());
		
		System.out.println("\n\nTodas:\n" + T.Get());
		
		System.out.println("\nGenero:");
		for(int i=0; i<T.N(); i++){
			System.out.println(T.Genero(i));
		}
		
		System.out.println("\nNumero:");
		for(int i=0; i<T.N(); i++){
			System.out.println(T.Numero(i));
		}
		
	}
}//end class





/*Classe Arquivo
 *Instancia objetos que contem um array de frases contidas no arquivo de input*/	
class Arquivo {
	String[] linha;

	public Arquivo(String InFilename) {
		try{
			String tmp, total="";
			BufferedReader arquivo = new BufferedReader(new FileReader(InFilename));
			
			tmp = arquivo.readLine();
			
			while(tmp != null){
				total = total + "\n" + tmp;
				tmp = arquivo.readLine();
			};
			
			linha = total.substring(1).split("\n");
		}
		catch(IOException erro){
			System.out.println("Arquivo nao encontrado!");
		}
	}
	
	public int N(){
		return linha.length;
	}
	
	public String Get(int x){
		return linha[x];
	}
	
}//end class


/*Classe Texto
 **/
class Texto {
	Frase[] frase;
	
	public Texto(Arquivo arquivo){
		frase = new Frase[arquivo.N()];
		
		for(int i=0; i<arquivo.N(); i++){
			frase[i] = new Frase(arquivo.Get(i));
		}
	}
	
	public String Get(){
 		String resultado="";
 		for(int i=0; i<frase.length; i++){
 			resultado = resultado + "\n" + frase[i].Get();
 		}
 		return(resultado.substring(1));
 	}
	
	public String Get(int x){
		return(frase[x].Get());
	}
	
	public String Genero(int x){
		return(frase[x].Genero());
	}
	
	public String Numero(int x){
		return(frase[x].Numero());
	}
	
	public int N(){
		return(frase.length);
	}
	
}//end class


/*Classe Frase
 **/
class Frase {
 	Palavra p0;
 	Palavra p1;
 	Palavra p2;
 	Palavra p3;
 	Palavra p4;
 	
 	public Frase(String InFrase){
		String[] pals = InFrase.split(" ");
 		
 		
 		//Artigo
 		if(pals[0].charAt(0) == 'o' || pals[0].charAt(0) == 'a'){
 			p0 = new ArtigoD(pals[0]);
 		}
 		else p0 = new ArtigoI(pals[0]);
 		
 		
 		//Substantivo
 		p1 = new Substantivo(pals[1]);
 		
 		
 		//Verbo
 		p2 = new Verbo(pals[2]);
 		
 		
 		//Artigo
 		if((pals[3].charAt(0) == 'o') || (pals[3].charAt(0) == 'a')){
 			p3 = new Artigo(pals[3]);
 		}
 		else p3 = new ArtigoI(pals[3]);
 		
 		
 		//Substantivo
 		p4 = new Substantivo(pals[4]);
 	}
 	
 	public String Get(){
 		String resultado = "";
 		
 		resultado = p0.Get() + " " + p1.Get() + " " + p2.Get() + " " + p3.Get() + " " + p4.Get();
 		return(resultado);
 	}
 	
 	public String Genero(){
 		String resultado = "";
 		
 		resultado = p0.Genero() + " " + p1.Genero() + " " + p2.Genero() + " " + p3.Genero() + " " + p4.Genero();
 		return(resultado);
 	}
 	
 	public String Numero(){
 		String resultado = "";
 		
 		resultado = p0.Numero() + " " + p1.Numero() + " " + p2.Numero() + " " + p3.Numero() + " " + p4.Numero();
 		return(resultado);
 	}
}//end class
 
 
/*Classe Palavra
 **/
class Palavra {
 	String palavra;
 	
 	public Palavra(String InPalavra){
 		palavra = InPalavra;
 	}
 	
  	public String Get(){
  		return(palavra);
  	}
  	
	public String Genero(){
		return(palavra);
	}
	
	public String Numero(){
		return(palavra);
	}
}


/*Classe Substantivo
 **/
class Substantivo extends Palavra {
	public Substantivo(String InPalavra){
		super(InPalavra);
	}
	
	public String Genero(){
		int N = palavra.length()-1;
		String pl = "", gen = "a";
		
		if(palavra.charAt(N) == 's'){
			pl = "s";
			N -= 1;
		}
		
		if(palavra.charAt(N) == 'a'){
			gen = "o";
		}
				
		return(palavra.substring(0, N) + gen + pl);
	}
	
	public String Numero(){
		int N = palavra.length()-1;
		String pl = "s";
		
		if(palavra.charAt(N) == 's'){
			pl = "";
		}
		else N += 1;
		
		return(palavra.substring(0, N) + pl);
	}	
}


/*Classe ArtigoD
 **/
class ArtigoD extends Palavra {
	public ArtigoD(String InPalavra){
		super(InPalavra);
	}
	
	public String Genero(){
		String resultado = "";
		
		if(palavra.matches("o")) resultado = "a";
		if(palavra.matches("os")) resultado = "as";
		if(palavra.matches("a")) resultado = "o";
		if(palavra.matches("as")) resultado = "os";

		return(resultado);
	}
	
	public String Numero(){
		String resultado = "";
		
		if(palavra.matches("o")) resultado = "os";
		if(palavra.matches("os")) resultado = "o";
		if(palavra.matches("a")) resultado = "as";
		if(palavra.matches("as")) resultado = "a";
		
		
		resultado = "AD - N";
		return(resultado);
	}
}


/*Classe ArtigoI
 **/
class ArtigoI extends Palavra {
	public ArtigoI(String InPalavra){
		super(InPalavra);
	}
	
	public String Genero(){
		String resultado = "";
		
		if(palavra.matches("um")) resultado = "uma";
		if(palavra.matches("uns")) resultado = "umas";
		if(palavra.matches("uma")) resultado = "um";
		if(palavra.matches("umas")) resultado = "uns";

		return(resultado);
	}
	
	public String Numero(){
		String resultado = "";
		
		if(palavra.matches("um")) resultado = "uns";
		if(palavra.matches("uns")) resultado = "um";
		if(palavra.matches("uma")) resultado = "umas";
		if(palavra.matches("umas")) resultado = "uma";
		
		resultado = "AI - N";
		return(resultado);
	}
}


/*Classe Verbo
 *Nao eh necessario criar subclasses para as conjugacoes
 *pois os sulfixos sao iguais no presente do indicativo*/
class Verbo extends Palavra {
	public Verbo(String InPalavra){
		super(InPalavra);
	}
	
	public String Numero(){
		int N = palavra.length()-1;
		String pl = "m";
		
		if(palavra.charAt(N) == 'm'){
			pl = "";
		}
		else N += 1;
		
		return(palavra.substring(0, N) + pl);
	}	
}