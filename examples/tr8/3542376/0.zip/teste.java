// Sergio Pavanello Rossi NUSP 3530035
// Luiz Carlos Genoves Junior NUSP 3542376

import java.awt.event.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.*;

class Frase
{
  private Artigo a1, a2;
  private Substantivo s1,s2;
  private Verbo v1;
  
  Frase () {
  }
  
  Frase (String s)
  {
  	String[] wlist = new String[5];
  	wlist = CortaPalavras (s);
    
    a1 = new Artigo(wlist[0]);
    s1 = new Substantivo (wlist[1]);
    v1 = new Verbo (wlist[2]);
    a2 = new Artigo (wlist[3]);
    s2 = new Substantivo (wlist[4]);
    
  }

  private String[] CortaPalavras(String sword)
  {
    String wlist[] = new String[5];
    CharSequence word = new String(sword);
    int i, j = 0, k = 0;
    for (i = 0; i < word.length(); i++)
      if ( ( word.charAt(i) == ' ' ) && ( i != j ) ) {
        wlist[k] = (word.subSequence(j, i)).toString();
	    j = i+1;
	    k++;
      }
    wlist[k] = (word.subSequence(j, i)).toString();
    return wlist;
  }

  public void AlterGen()
  {
    this.a1.AlterGen();   
    this.s1.AlterGen();
    this.v1.AlterGen();
    this.a2.AlterGen();
    this.s2.AlterGen();
  }
        
  public void AlterNum()
  {
    this.a1.AlterNum();
    this.s1.AlterNum();
    this.v1.AlterNum();
    this.a2.AlterNum();
    this.s2.AlterNum();
  }
  
  
  private String fraseCompleta() {
  	String s = new String();
  	s = this.a1.printo() + this.s1.printo() + this.v1.printo() + this.a2.printo() + this.s2.printo();
  	return (s.substring(0,1).toUpperCase() +  s.substring(1, s.length()-1));
  }
  
  public String printo() 
  {
    String s;
    s = fraseCompleta();
    System.out.println(s);
    return s;
  }
}

class Palavra
{
  //Algo definido como palavra
  private String word;
  public boolean genero, numero;
  
  Palavra() {
  }
  
  Palavra(String s){
    this.word = s;
    this.numero = this.detnumero();
    this.genero = this.detgenero();
  }

  public String printo()
  {
    //System.out.println(this.word + "\n");
    return (this.word + " ");
    
  }
  
  private boolean detnumero()
  {
  	CharSequence word = new String(this.word);
    if ( word.charAt( word.length() - 1 ) == 's' )
      return true;  //plural
    else
      return false;  //singular
  }

  private boolean detgenero()
  {
  	CharSequence word = new String(this.word);
  	int i = (this.numero) ? 2 : 1;
  	char aux = word.charAt( word.length() - i );
    if ( ( aux == 'a') || (aux == 'A') )
      return true;   //feminino
    else
      return false; //masculino
  }
      
  public void AlterGen()
  {
  	
    if ( this.genero )
      this.Masc();
    else
      this.Fem();
    this.genero = !(this.genero);
  }
  
  public void AlterNum ()
  {
    if ( this.numero )
      this.Singular();
    else
      this.Plural();
    this.numero = !(this.numero);
  }
  
  public String getword () {
    return this.word;
  }
  
  public void setword (String s) {
    this.word = s;
  }
  
  public String ult_letra( int i ) 
  {
  	if ( i > this.word.length() )
  	  return "";
    return this.word.substring( this.word.length() - i, this.word.length());
  }
  
  public void rm_add (int i, String s)
  { 
    String aux;
    aux = (this.getword()).substring(0, this.word.length() - i) + s;
	setword(aux);
  }

  public void Masc()
  {
    if ( this.ult_letra(1).equalsIgnoreCase("s") )
      this.rm_add(2, "os");
    else
      this.rm_add(1, "o");
  }


  public void Fem()
  {
  	if ( this.ult_letra(1).equalsIgnoreCase("s") )
      this.rm_add(2, "as");
    else
      this.rm_add(1, "a");
  }

      
  private void Plural() 
  {
    if ( this.ult_letra(1).equalsIgnoreCase("m") )
      this.rm_add(1, "ns");
    else {
      if ( this.ult_letra(1) == "l")
        this.rm_add(1, "is");
       else 
        this.rm_add(0, "s");
    }
  }
	
  private void Singular() 
  {
    if ( this.ult_letra(2).equalsIgnoreCase("ns") )
      this.rm_add(2, "m");
    else
      if ( this.ult_letra(3).equalsIgnoreCase("eis") )
        this.rm_add(3, "el");
      else 
        this.rm_add(1, "");
   }
}

class Artigo extends Palavra {
  Artigo(){}
  Artigo (String s) {
  	super(s);
  }
  
}   
  
class ArtigoDef extends Artigo {
}
  
class ArtigoIndef extends Artigo {
}  
  

class Substantivo extends Palavra {
  
  Substantivo(String s) 
  {
  	super(s);
  }
}
 
class Verbo extends Palavra {
   
   private boolean detnumero()
  {
    if ( this.ult_letra(1).equalsIgnoreCase("m") )
      return true;  //plural
    else
      return false;  //singular
  }
   
  Verbo () {
  }
  
  Verbo (String s) {
  	super(s);
  	this.numero = this.detnumero();
  }
  	

  
  private void detgenero() {
  }

  public void AlterNum ()
  {
    if ( this.numero )
      this.Singular();
    else
      this.Plural();
    this.numero = !(this.numero);
  }

  private void Plural() {
    //Altera o genero do verbo para concordar com o plural
    this.rm_add(0, "m");
  }
 
  private void Singular() {
    //Altera o genero do verbo para concordar com o singular
    this.rm_add(1, "");
  }
  
  public void AlterGen() {
  }
}
    
class Conj1 extends Verbo {
}
class Conj2 extends Verbo {
}
class Conj3 extends Verbo {
}

/***********************************************************************************/

class heranc extends JDialog implements ActionListener{
  
  String [] opcoes = {"O gato roe o rato", "O cachorro esconde a gata"};
  JButton b1 = new JButton("Alterar Genero:");
  JButton b2 = new JButton("Alterar N�mero:");
  JLabel texto = new JLabel("Digite ou selecione a frase");
  JPanel p = new JPanel();
  JPanel p2 = new JPanel();
  JTextField tf = new JTextField(20);
  JMenuBar bar = new JMenuBar();
  JMenu m1 = new JMenu("Arquivo");
  JMenuItem im11 = new JMenuItem("Abrir");
  JList lista = new JList(opcoes);
  JScrollPane jp = new JScrollPane(lista);
    
  heranc()
  {	
    java.awt.Container painel = getContentPane();
	b1.addActionListener(this);
	b2.addActionListener(this);
	im11.addActionListener(this);
	lista.addMouseListener(mouseListener);
	tf.setToolTipText("Digite aqui sua frase");
	lista.setToolTipText("Duplo click para selecionar!!");
   	bar.add(m1);
	m1.add(im11);
    getContentPane().add(bar, BorderLayout.NORTH);
	p.add(b1, BorderLayout.NORTH);
	p.add(b2, BorderLayout.SOUTH);
	p.add(jp);//, BorderLayout.WEST);
	getContentPane().add(p , BorderLayout.WEST);
	p2.add(texto);
	p2.add(tf);
	getContentPane().add(p2, BorderLayout.AFTER_LAST_LINE);
    Frase a = new Frase("O rato esconde a rata");
  	a.printo();
  	a.AlterGen();
  	a.printo();
  	a.AlterNum();
  	a.printo();
  	a.AlterGen();
  	a.printo();
  	a.AlterNum();
    a.printo();
  }
   
  
  
  public static void main (String args[])
  {
  	JDialog frame = new heranc();
	WindowListener l = new WindowAdapter () {
  		public void windowClosing(WindowEvent e) {
  			System.exit(0);
  		}
  	};
    frame.addWindowListener(l);
    frame.pack();
    frame.setVisible(true);
  }  
  
  public String [] AbreArq(File s) throws IOException {
  	String [] aux = {"","","","",""} ;
	File inputFile = s;
	int i = 0;
    FileReader in = new FileReader(inputFile);
    BufferedReader br = new BufferedReader(in); 
    String c = null;
    
    while ( (c = br.readLine() ) != null) {
        System.out.println(c);
        aux[i] = new String(c);
        System.out.println(aux[i]);
        i++;
        if (i > 3)
          break;
    }
    in.close();
    return aux;
  }

MouseListener mouseListener = new MouseAdapter() {
     public void mouseClicked(MouseEvent e) {
         if (e.getClickCount() == 2) {
             int index = lista.locationToIndex(e.getPoint());
             tf.setText(lista.getSelectedValue().toString());
          }
     }
 };
 
  public void actionPerformed (ActionEvent evt) 
  {
  	Frase a;
  	Object source = evt.getSource();
    if (source == b1) {
      a = new Frase(tf.getText());
  	  a.AlterGen();
  	  tf.setText(a.printo());
    }
  	if (source == b2) {
  	  a = new Frase(tf.getText());
  	  a.AlterNum();
  	  tf.setText(a.printo());
    }
  	if (source == im11) {
  	  JFileChooser fc = new JFileChooser();
  	  int op = fc.showOpenDialog(this);
  	  if (op == JFileChooser.APPROVE_OPTION) {
  	  	System.out.println("PAu na Bunda!! " + fc.getSelectedFile());
  	  	String [] opcao = {"pai, mae"};
  	  	
  	  	try {
  	  	  lista.setListData( AbreArq(fc.getSelectedFile()) );
  	    }
  	    catch (IOException e) {
  	      System.err.println(e);
  	    }
  	  }
    }
  	repaint();
  }
 
}
