package Lista;

/*========================================================================*/
/*  Classe Frase.*/
/** Armazena uma frase do texto e a separa em 2 substantivos, 2 artigos e 1 verbo.
*/
/*========================================================================*/
public class Frase extends Palavra
{
	private Substantivo sub1;
	private Substantivo sub2;
	private Palavra     art1;  // primeiro artigo
	private Palavra     art2;  // segundo artigo
	private Palavra     verbo; // verbo da frase(pode ser de 1a., 2a. ou 3a. conj
	
	public Frase (String texto_frase)
	{
		super (texto_frase);
		
		String[] palavras = this.texto.split(" "); // separa as palavras.
		
		this.sub1 = new Substantivo(palavras[1]); // segunda e quinta palavras devem ser substantivos
		this.sub2 = new Substantivo(palavras[4]);

		// primeiro artigo				
		if (palavras[0].charAt(0) == 'U')
			this.art1 = new Art_Indefinido(palavras[0]);
		else 
			this.art1 = new Art_Definido(palavras[0]);

		// segundo artigo
		if (palavras[3].charAt(0) == 'U')
			this.art2 = new Art_Indefinido(palavras[3]);
		else 
			this.art2 = new Art_Definido(palavras[3]);

		// verbo (verifica a conjugacao)
		if (palavras[2].charAt(palavras[2].length()- 1) == 'A')
			this.verbo = new Pri_Conj(palavras[2]);
		else if (palavras[2].charAt(palavras[2].length() - 1) == 'E')
			this.verbo = new Seg_Conj(palavras[2]);
		else
			this.verbo = new Terc_Conj(palavras[2]);
	}	
	
	public void Genero()
	{
		// modifica o genero das palavras, verbo nao e modificado
		this.sub1.Genero();		
		this.sub2.Genero();		
		this.art1.Genero();		
		this.art2.Genero();		
	}
	
	public void Numero()
	{
		// modifica o numero das palavras
		this.sub1.Numero();		
		this.sub2.Numero();		
		this.art1.Numero();		
		this.art2.Numero();		
		this.verbo.Numero();		
	}
	
	public String toString()
	{	// para impressao
		String resultado = new String(this.art1 + " " + 
			this.sub1 + " " + this.verbo + " " + this.art2 + " " + this.sub2 + ".\n");

		return resultado;
	}
}


/*========================================================================*/
/*  Classe Palavra.*/
/** Classe base que armazena o texto de uma palavra.
*/
/*========================================================================*/
abstract class Palavra 
{
	protected String texto;
	
	public Palavra (String texto)
	{
		this.texto = new String(texto);
	}
	
	public String toString() // para a impressao
	{
		return this.texto;
	}

	
	public abstract void Genero(); 
	
	public abstract void Numero();
	
}



/*========================================================================*/
/*  Classe Pri_Conj.*/
/** Armazena verbos da primeira conjugacao.
*/
/*========================================================================*/
class Pri_Conj extends Palavra
{
	public Pri_Conj (String texto)
	{
		super (texto);
	}
	
	public void Genero()
	{
		// verbos nao possuem mudanca de genero		
	}
	
	public void Numero()
	{
		// para a primeira conjugacao, basta acrescentar ou retirar um M no final
		if (this.texto.endsWith("A"))
			this.texto += "M";
		else if (this.texto.endsWith("M"))
		{
			this.texto = this.texto.substring (0, this.texto.length() - 2);
			this.texto += "A";
		}
	}
}

/*========================================================================*/
/*  Classe Seg_Conj.*/
/** Armazena verbos da segunda conjugacao.
*/
/*========================================================================*/
class Seg_Conj extends Palavra
{
	public Seg_Conj (String texto)
	{
		super (texto);
	}
	
	public void Genero()
	{
		// verbos nao possuem mudanca de genero		
	}
	
	public void Numero()
	{
		// para a segunda conjugacao, basta acrescentar ou retirar um M no final
		if (this.texto.endsWith("E"))
		{
			this.texto += "M";
		}
		else if (this.texto.endsWith("M"))
		{
			this.texto = this.texto.substring (0, this.texto.length() - 2);
			this.texto += "E";
		}
	}
}


/*========================================================================*/
/*  Classe Terc_Conj.*/
/** Armazena verbos da terceira conjugacao.
*/
/*========================================================================*/
class Terc_Conj extends Palavra
{
	public Terc_Conj (String texto)
	{
		super (texto);
	}
	
	public void Genero()
	{
		// verbos nao possuem mudanca de genero		
		
	}
	
	public void Numero()
	{
		if (this.texto.endsWith("I"))
		{
			this.texto = this.texto.substring (0, this.texto.length() - 1);
			this.texto += "EM";
		}
		else if (this.texto.endsWith("M"))
		{
			this.texto = this.texto.substring (0, this.texto.length() - 2);
			this.texto += "I";
		}
	}
}


/*========================================================================*/
/*  Classe Substantivo.*/
/** Armazena uma palavra, sendo esta do tipo substantivo.
*/
/*========================================================================*/
class Substantivo extends Palavra
{
	public Substantivo (String texto)
	{
		super (texto);
	}
	
	// trabalha apenas com substativos simples, terminados em "A" e "O", e
  	// apenas troca um pelo outro
	public void Genero ()
	{
		if (this.texto.endsWith("A"))
		{
			this.texto = this.texto.substring (0, this.texto.length() - 1);
			this.texto += "O";
		}
		else if (this.texto.endsWith("O"))
		{
			this.texto = this.texto.substring (0, this.texto.length() - 1);
			this.texto += "A";
		}
		else if (this.texto.endsWith("AS"))
		{
			this.texto = this.texto.substring (0, this.texto.length() - 2);
			this.texto += "OS";
		}
		else if (this.texto.endsWith("OS"))
		{
			this.texto = this.texto.substring (0, this.texto.length() - 2);
			this.texto += "AS";
		}
		
	}
	
	// acrescenta ou retira um s do final do texto
	public void Numero ()
	{
		if (this.texto.endsWith ("AS") || this.texto.endsWith("OS"))
		{
			this.texto = this.texto.substring (0, this.texto.length() - 1);
		}
		else
			this.texto += "S";
	}
}


/*========================================================================*/
/*  Classe Art_Indefinido.*/
/** Armazena uma palavra do tipo artigo indefinido.
*/
/*========================================================================*/

class Art_Indefinido extends Palavra
{
	public Art_Indefinido (String texto)
	{
		super (texto);
	}

	// como os artigos indefinidos pertencem a um conjunto fixo
        // apenas realiza a troca de palavras	
	public void Genero ()
	{
		if (this.texto.compareTo("UM") == 0)
			this.texto = "UMA";
		else if (this.texto.compareTo("UMA") == 0)
			this.texto = "UM";
		else if (this.texto.compareTo("UNS") == 0)
			this.texto = "UMAS";
		else if (this.texto.compareTo("UMAS") == 0)
			this.texto = "UNS";
	}
	
	// como os artigos indefinidos pertencem a um conjunto fixo
        // apenas realiza a troca de palavras	
	public void Numero ()
	{
		if (this.texto.compareTo("UM") == 0)
			this.texto = "UNS";
		else if (this.texto.compareTo("UMA") == 0)
			this.texto = "UMAS";
		else if (this.texto.compareTo("UNS") == 0)
			this.texto = "UM";
		else if (this.texto.compareTo("UMAS") == 0)
			this.texto = "UMA";
	}

}

/*========================================================================*/
/*  Classe Art_Definido.*/
/** Armazena uma palavra do tipo artigo definido.
*/
/*========================================================================*/
class Art_Definido extends Palavra
{
	public Art_Definido (String texto)
	{
		super (texto);
	}
	
	// como os artigos definidos pertencem a um conjunto fixo
        // apenas realiza a troca de palavras	
	public void Genero ()
	{
		if (this.texto.compareTo("O") == 0)
			this.texto = "A";
		else if (this.texto.compareTo("A") == 0)
			this.texto = "O";
		else if (this.texto.compareTo("OS") == 0)
			this.texto = "AS";
		else if (this.texto.compareTo("AS") == 0)
			this.texto = "OS";
	}
	
	// como os artigos definidos pertencem a um conjunto fixo
        // apenas realiza a troca de palavras	
	public void Numero ()
	{
		if (this.texto.compareTo("O") == 0)
			this.texto = "OS";
		else if (this.texto.compareTo("A") == 0)
			this.texto = "AS";
		else if (this.texto.compareTo("AS") == 0)
			this.texto = "A";
		else if (this.texto.compareTo("OS") == 0)
			this.texto = "O";
	}

}