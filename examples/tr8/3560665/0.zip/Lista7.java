// Autores :
//       Chen Xu Sheng    3456310
//       Koji E. Sasaoka  3560665
//

import java.io.*;        // para a leitura dos dados a partir do arquivo
import java.awt.*;       // utilizada pelo swing
import java.awt.event.*; // utilizada pelo swing e nos botoes
import javax.swing.*;    // interface grafica
import javax.swing.filechooser.*;  // dialog box para escolher arquivo
import Lista.Frase;                // package do exercicio

public class Lista7 extends JPanel implements ActionListener 
{
    	private JFileChooser jfc_qual_arq;  // dialog box para a escolha do arquivo
	
    	private JTextArea    jta_log;       // escreve o nome do arquivo
    	private JTextArea    jta_texto_original; // exibe o texto original
    	private JTextArea    jta_texto_modif;    // exibe o texto modificado

	private JCheckBox    jcb_genero;        // check box para mudanca de genero
	private JCheckBox    jcb_numero;	// check box para mudanca de numero
	
	private JButton      btn_modificar;	// botao para modificar o genero/numero
	private JButton      btn_arq;	 	// botao para abrir arquivos
	
	private int          qtas_frases;       // numero de frases lidas do arquivo
	private String       nome_arq;		// nome do arquivo escolhido
	private File	     arq_dados;		// variavel do arquivo fisico
		
	Frase[]              frases;		// vetor de frases lidas
	
	/*========================================================================*/
	/*  Metodo :  Lista7 (construtor da classe).*/
	/** Construtor da classe Lista7.
	 */
	/*========================================================================*/
	public Lista7 ()
	{
        	super(new BorderLayout());	// utiliza border layout para exibir os componentes

		this.qtas_frases = 0;

		this.frases = new Frase[30];	// aloca no maximo trinta frases	
		
		// inicializa o text area que mostra o nome do arquivo
        	this.jta_log = new JTextArea(5,5);
        	this.jta_log.setMargin(new Insets(5,5,5,5));
        	this.jta_log.setEditable(false);
        	this.jta_log.append("Arquivo : \n \n");

		// inicializa o text area que mostra o texto original
        	this.jta_texto_original = new JTextArea(5,20);
        	this.jta_texto_original.setMargin(new Insets(5,5,5,5));
        	this.jta_texto_original.setEditable(false);
        	this.jta_texto_original.append ("Texto Original : \n \n");

		// inicializa o text area que mostra o texto modificado
        	this.jta_texto_modif = new JTextArea(5,20);
        	this.jta_texto_modif.setMargin(new Insets(5,5,5,5));
        	this.jta_texto_modif.setEditable(false);
		this.Limpar_Texto();
		
		// inicializa o check box de mudanca de genero
		this.jcb_genero = new JCheckBox ("Genero ");
		this.jcb_genero.setSelected(false);

		// inicializa o check box de mudanca de numero
		this.jcb_numero = new JCheckBox ("Numero ");
		this.jcb_numero.setSelected(false);
		        
		// utiliza scroll panel nos text area para que estem possam executar scroll
        	JScrollPane jsp_log_scroll = new JScrollPane(this.jta_log);
        	JScrollPane jsp_original_scroll = new JScrollPane(this.jta_texto_original);
        	JScrollPane jsp_modif_scroll = new JScrollPane(this.jta_texto_modif);

		// inicializa os botoes
        	btn_arq = new JButton("Abrir Arq");
        	btn_modificar = new JButton("Modificar");

		// JPanel auxiliar no meio do jpanel maior
		JPanel jpn_outros = new JPanel (new BorderLayout());
		
        	jpn_outros.add(jsp_log_scroll, BorderLayout.PAGE_START);
        	jpn_outros.add(jcb_genero, BorderLayout.WEST);
        	jpn_outros.add(jcb_numero, BorderLayout.EAST);
        
		// eventos serao tratados por esta instancia de classe
        	btn_arq.addActionListener(this);
        	btn_modificar.addActionListener(this);

		// posiciona os componentes no panel
        	add(btn_arq, BorderLayout.PAGE_START);
        	add(btn_modificar, BorderLayout.PAGE_END);

        	add(jsp_original_scroll, BorderLayout.WEST);
        	add(jsp_modif_scroll, BorderLayout.EAST);

		add(jpn_outros, BorderLayout.CENTER);

	}
	
	
	/*========================================================================*/
	/*  Metodo : Limpar_Texto. */
	/** Limpa o texto do componente de texto modificado .
	 */
	/*========================================================================*/
	protected void Limpar_Texto ()
	{
		// limpa o texto do text area de texto modificado
        	this.jta_texto_modif.setText("Texto Modificado : \n \n");	
	}
	
	
	/*========================================================================*/
	/*  Metodo : ActionPerformed.*/
	/** Chamada pelo botao btn_arq e btn_modificar em resposta ao evento de clique.
	 */
	/*========================================================================*/
    	public void actionPerformed(ActionEvent e) 
    	{
    		Object fonte = e.getSource(); // verifica qual botao gerou o evento
    		String nome_arq;
    	
    		if (fonte == this.btn_arq)
    		{
        		// inicializa a janela de escolha de arquivo
			if (this.jfc_qual_arq == null) 
        		{
  				this.jfc_qual_arq = new JFileChooser();
	
    	        		this.jfc_qual_arq.setAcceptAllFileFilterUsed(false);
	        	}

			// exibe a janela
	        	int resposta_arq = this.jfc_qual_arq.showDialog(this, "Abrir arquivo");
	
			// se escolheu o arquivo armazena dados e chama metodo para carregar dados
    	    		if (resposta_arq == JFileChooser.APPROVE_OPTION) 
    	    		{
    	        		this.arq_dados = this.jfc_qual_arq.getSelectedFile();
    	        		nome_arq = new String(arq_dados.getPath() + "\\" + arq_dados.getName());
    	        		this.jta_log.append("Incluindo arq : " + nome_arq + ".\n");
    	        
        			this.Carregar();
        
    	    		} 
    	    		else 
    	    		{ 	// exibe que a janela foi cancelada
        	    		this.jta_log.append("Cancelado.\n");
        		}

        		this.jfc_qual_arq.setSelectedFile(null);
    		}
	    	else if (fonte == this.btn_modificar) // botao de modificar
	    	{	// modificar o genero
	    		if (this.jcb_genero.isSelected() == true)
	    		{
		    		for (int cont = 0; cont < this.qtas_frases; cont++)
		    		{
		    			this.frases[cont].Genero();
		    		}
	    		}

	    		// modificar o numero
	    		if (this.jcb_numero.isSelected() == true)
	    		{
		    		for (int cont = 0; cont < this.qtas_frases; cont++)
		    		{
		    			this.frases[cont].Numero();
		    		}
	    		
	    		}
			// atualiza o texto modificado
	    		this.Atualizar();
	    	
	    	}
	 }


	/*========================================================================*/
	/** Atualiza o texto da janela de texto modificado.
	 */
	/*========================================================================*/
	private void Atualizar()
	{
		this.Limpar_Texto();
		
    		for (int cont = 0; cont < this.qtas_frases; cont++)
    		{
    			this.jta_texto_modif.append(this.frases[cont].toString());
    		}
	
	}
	
	/*========================================================================*/
	/** Carrega as frases do arquivo.
	 */
	/*========================================================================*/
    	private void Carregar() 
    	{
		InputStream arq_fis;
      		InputStreamReader arq_logic;
      		BufferedReader arq_buffer;
		String dados;

      		try
      		{
        		arq_fis = new FileInputStream(this.arq_dados);
           		arq_logic = new InputStreamReader(arq_fis);
           		arq_buffer = new BufferedReader(arq_logic);

			while ((dados = arq_buffer.readLine()) != null)
			{
				this.frases[qtas_frases++] = new Frase(dados); // aloca uma nova frase
				
				this.jta_texto_original.append(dados + "\n");
			}
			
        		arq_fis.close();
        	
      		}   	
		catch(IOException e) {};
 	}
		    		
	/*========================================================================*/
	/** Programa Principal.	 */
	/*========================================================================*/
	public static void main (String args[])
	{
		   	JFrame.setDefaultLookAndFeelDecorated(true);
        	JDialog.setDefaultLookAndFeelDecorated(true);

        	JFrame jf_principal = new JFrame("Exercios de Java - Lista 7");
        	jf_principal.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);


        	JComponent teste = new Lista7();
	      	teste.setOpaque(true);
        	jf_principal.setContentPane(teste);

		// exibe a janela
        	jf_principal.pack();
        	jf_principal.setVisible(true);

	}
}

	
	
	

