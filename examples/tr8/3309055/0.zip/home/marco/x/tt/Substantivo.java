package com.usp.poo;



public class Substantivo extends Palavra 
{
private String substantivo;


	public Substantivo(String palavra)
	{
		super(palavra);
		this.substantivo = palavra;
	}




	public String alteraGenero()//String substantivo)//terminados em o=os,a=as 
	{
		if(substantivo.endsWith("o"))
		{	substantivo = substantivo.substring(0,substantivo.lastIndexOf('o'));
			return substantivo.concat("a");
		}
		else if (substantivo.endsWith("a"))
		{
			substantivo = substantivo.substring(0,substantivo.lastIndexOf('a'));
			return substantivo.concat("o");
		}
		else if (substantivo.endsWith("os"))
		{
			substantivo = substantivo.substring(0,substantivo.lastIndexOf("os"));
			return substantivo.concat("as");
		}
		else if ( substantivo.endsWith("as") )
		{
			substantivo = substantivo.substring(0,substantivo.lastIndexOf("as"));
			return substantivo.concat("os");
		}
		
		return "Internal Error";
		
	}
	
	public String alteraNumero()//String substantivo)
	{
		if(substantivo.endsWith("o") || substantivo.endsWith("a"))
		{
			return substantivo.concat("s");
		}
		else if(substantivo.endsWith("s"))
		{
			substantivo = substantivo.substring(0,substantivo.lastIndexOf('s'));
			return substantivo;
		}
/*		
substantivo = substantivo.substring(0,substantivo.length()-1);
System.out.println("Plural?!?"+substantivo);
		
		if(substantivo.endsWith("o") || substantivo.endsWith("a"))
		{
			return substantivo.concat("s");
		}
		else if(substantivo.endsWith("s"))
		{
			substantivo = substantivo.substring(substantivo.lastIndexOf('s'));
		}
	*/			
		return "ERRO?!?! em alteraNum de Substantivo?";
	}
}