package com.usp.poo;



public class ArtigoDefinido extends Artigo
{
		
private String artigo_def;
	public ArtigoDefinido(String palavra)
	{
		super(palavra);
		artigo_def = palavra;
	}
	
	
	//o,a,os,as
	public String alteraGenero()
	{
		String artigo_def = this.palavra;
		
		if(artigo_def.startsWith("a"))
		{
			return artigo_def.replace('a','o');
		}
		else if(artigo_def.startsWith("o"))
		{
			return artigo_def.replace('o','a');
		}
		else if(artigo_def.startsWith("A"))
		{
			return artigo_def.replace('A','O');
		}
		else if(artigo_def.startsWith("O"))
		{
			return artigo_def.replace('O','A');
		}
		
		
		
		return "AChou um erro em artigo def.java altgenero.";
	}
	
	public String alteraNumero()
	{
		if(artigo_def.matches("a") || artigo_def.matches("o") )
		{	
			return artigo_def.concat("s");
		}
		else if( (artigo_def.startsWith("a") || artigo_def.startsWith("o")) && artigo_def.endsWith("s") )
		{
			artigo_def = artigo_def.substring(0,artigo_def.lastIndexOf('s'));
			return artigo_def;
		}
		else if(artigo_def.matches("A") || artigo_def.matches("O") )
		{
			return artigo_def.concat("s");
		}
		else if( (artigo_def.startsWith("A") || artigo_def.startsWith("O")) && artigo_def.endsWith("s") )
		{
			artigo_def = artigo_def.substring(0, artigo_def.lastIndexOf('s'));
			return artigo_def;
		}
		
return "Ei achou um erro.hehehehe";

	}
	
}