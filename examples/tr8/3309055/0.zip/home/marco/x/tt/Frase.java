package com.usp.poo;

public class Frase
{
	private Palavra frase[] = new Palavra[5];
	protected static int NUMERO_DE_PALAVRAS = 0;
	
	public Frase()
	{
			
	}
	
	public void alterarGenero(Palavra palavra)	
	{
		
	}
	
	public void alterarNumero(Palavra palavra)
	{
		
	}
	
	public void addPalavra(Palavra p)
	{
		frase[NUMERO_DE_PALAVRAS] = p;
		NUMERO_DE_PALAVRAS++;
	}
	
	public Palavra[] getPalavra()
	{
		return frase;
	}
	
	public Palavra getPalavra(int i)
	{
		return frase[i];
	}
	
}