package com.usp.poo;


public abstract class Verbo extends Palavra
{
	private String verbo;
	
	public Verbo(String palavra)
	{
		super(palavra);
	}
	
	
	public static boolean isPrimeiraConj(String verbo)
	{
		if(verbo.endsWith("a") || verbo.endsWith("am"))
			return true;
		else return false;
	}
	
	public static boolean isSegundaConj(String verbo)
	{
		if(verbo.endsWith("e") || verbo.endsWith("em"))
			return true;
		else return false;
	}
	
	public String alteraGenero(String verbo)
	{
		return verbo;
	}
	
	public String alteraNumero(String verbo)
	{
		if(isPrimeiraConj(palavra))
			return ((PrimeiraConj)verbo).alteraNumero();
		else if(isSegundaConj(palavra))
			return ((SegundaConj)verbo).alteraNumero();
		else 
			return ((TerceiraConj)verbo).alteraNumero();
	}
	
	
}