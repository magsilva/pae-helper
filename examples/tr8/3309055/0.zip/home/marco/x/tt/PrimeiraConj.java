package com.usp.poo;

public class PrimeiraConj extends Verbo
{
	
	private String verbo = palavra;
	
	
	public PrimeiraConj(String palavra)
	{
		super(palavra);
	}
	
	
	public String alteraGenero(String verbo)
	{
		return verbo;
	}
	
	public String alteraNumero()//String verbo)
	{
		if(verbo.endsWith("a"))
		{
			verbo = verbo.concat("m");
		}
		else if(verbo.endsWith("m"))
		{
			verbo = verbo.substring(0,verbo.lastIndexOf('m'));
		}
		
		return verbo;
	}
}