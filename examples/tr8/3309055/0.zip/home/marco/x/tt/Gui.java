package com.usp.poo;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.applet.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import java.io.*;
import java.lang.*;

public class Gui
{
	private JTextArea textLeftArea, textRightArea;
	private JTextArea textDown;
	private JButton buttonGender, buttonNumber;
	private JFrame f;
	
	public Gui()
	{
		textLeftArea  = new JTextArea(15,30);
		textLeftArea.setText("ANALISADA...");
		textRightArea = new JTextArea(15,30);
		textRightArea.setText("ORIGINAL...");
		textDown	  = new JTextArea(3,60);
		textDown.setText("Instru��es:\nD� new antes de qualquer opera��o.Escreva sua frase NESTE espa�o.\nPor se tratar se um analizador sint�tico n�o esque�a o ponto final ap�s cada senten�a.");
		buttonGender  = new JButton("G�nero");
		buttonNumber  = new JButton("N�mero");
	}
	
	
	public void launchFrame()
	{
		/*JFrame*/f = new JFrame("Java Syntactic Analyzer");
		f.getContentPane().setLayout(new BorderLayout());//GridLayout(2,2,3,3));
		Box box = Box.createVerticalBox();
		Box box2= Box.createVerticalBox();
		Box box3= Box.createHorizontalBox();
		//Box box4= Box.createVerticalBox();
		box.add(new JScrollPane(textLeftArea, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED));
		box2.add(new JScrollPane(textRightArea,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED));
		box3.add(new JScrollPane(textDown,JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED));
		buttonGender.addMouseListener(new MeuMouseListener());
		buttonNumber.addMouseListener(new MeuMouseListener());
		f.getContentPane().add(box,BorderLayout.WEST);
		f.getContentPane().add(box2,BorderLayout.CENTER);
		f.getContentPane().add(box3,BorderLayout.SOUTH);
		JPanel p = new JPanel();
		p.setLayout(new GridLayout(2,1,40,60));
	//	buttonGender.addMouseListener(new MeuMouseListener());
	//	buttonNumber.addMouseListener(new MeuMouseListener());
		p.add(buttonGender);;
		p.add(buttonNumber);
		//f.getContentPane().add(p);
/**/	f.setJMenuBar(buildMenu());
		f.setVisible(true);
		f.pack();
	}
	
	
	class MeuMouseListener extends MouseAdapter
	{
		public void mousePressed(MouseEvent e) 
		{
			if(e.getSource() == buttonGender)
			{
			}
			else if(e.getSource() == buttonNumber)
			{
			}
		}
		
	}
	
	
	public JMenuBar buildMenu() 
	{
		JMenuBar menuBar = new JMenuBar();
		JMenu menuFile 	 = new JMenu("File");
		JMenu menuAnalyse= new JMenu("Analyse");
		JMenu menuHelp   = new JMenu("Help");
		menuBar.add(menuFile);
		menuBar.add(menuAnalyse);
		menuBar.add(menuHelp);
		
		
		// Item NEW do menu FILE
	   	JMenuItem menuNew = new JMenuItem("New");
	   	menuFile.add(menuNew);
	   	menuNew.addActionListener 
	   	(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent e)
				{	
					textLeftArea.setText("");
					textRightArea.setText("");
					/**/textDown.setText("");
				}
			}
		);
		
		
		// Item OPEN do menu FILE
	   	JMenuItem menuOpen = new JMenuItem ("Open");
	   	menuFile.add(menuOpen);
	   	menuOpen.addActionListener
	   	(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent e)
				{
					openFile();	
	         	}
      		}
			
		);
		
		
		// Item EXIT do menu FILE 
		JMenuItem menuExit = new JMenuItem("Exit");
	   	menuFile.add(menuExit);
	   	menuExit.addActionListener 
	   	(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent e)
				{	
					System.exit(0);				
				}
			}
		);
		
		//Item NUMBER do menu ANALYSE
		JMenuItem menuNumber	= new JMenuItem("Number");
		menuAnalyse.add(menuNumber);
		menuNumber.addActionListener
		(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					String texto = textDown.getText();
					Vector volta = trataNumero(texto);
					textLeftArea.setText(textLeftArea.getText()+"\n"+volta.elementAt(0)+".");
					textRightArea.setText(textRightArea.getText()+"\n"+volta.elementAt(1)+".");
					textDown.setText(" ");
				}
			}
		);
		
		//Item GENDER do menu ANALYSE
		JMenuItem menuGender	= new JMenuItem("Gender");
		menuAnalyse.add(menuGender);
		menuGender.addActionListener
		(
			new ActionListener()
			{
				public void actionPerformed(ActionEvent e)
				{
					String texto = textDown.getText();
					Vector volta = trataGenero(texto);
					textLeftArea.setText(textLeftArea.getText()+"\n"+volta.elementAt(0)+".");
					textRightArea.setText(textRightArea.getText()+"\n"+volta.elementAt(1)+".");
					textDown.setText(" ");
				}
			}
		);
		
		// Item HELP CONTENTS do menu HELP
		JMenuItem menuContents = new JMenuItem("Contents");
	   	menuHelp.add(menuContents);
	   	menuContents.addActionListener 
	   	(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent e)
				{	
					textDown.setText("");
					textDown.setText("\nPlay first, ask later.");				
					try{
					Thread.sleep(5000);
					}catch(InterruptedException ie){}
					textDown.setText("");
				}
			}
		);
		
		// Item ABOUT do menu HELP
		JMenuItem menuAbout = new JMenuItem("About");
	   	menuHelp.add(menuAbout);
	   	menuAbout.addActionListener 
	   	(
			new ActionListener() 
			{
				public void actionPerformed(ActionEvent e)
				{	
					textDown.append("Programa��o orientada a objetos\nTrabalho sobre an�lise sint�tica\nDiego Augusto Negrelli\nVers�o 1.0");
				}
			}
		);
		
		
		return menuBar;
		
	}
	
	
	
	
	
	
	/*--------------------------------------------------------*/
	// Fun��o para a abertura de arquivo
    private void openFile()
    {	
    	JFileChooser filechooser = new JFileChooser(new File("."));
    	filechooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		filechooser.setFileFilter
		(
			new javax.swing.filechooser.FileFilter() 
		  	{
				public String getDescription() 
				{ 
					return("Text Files"); 
				}
		   				
	  			public boolean accept(File f) 
	  			{
					return(f.getName().toLowerCase().endsWith(".txt"));
		    	}
		    }
	    );
	    
	    int returnVal = filechooser.showOpenDialog(f);
		if (returnVal == JFileChooser.APPROVE_OPTION) 
		{
	      	textDown/*txt_input*/.setText(getInputFile(filechooser.getSelectedFile()));
	      	//setText("File Loaded.");
	    } 	
	}
	
	
	// Fun��o que retorna o conte�do lido de um arquivo
	private String getInputFile(File file)
  	{  		
    	String text = new String();
    	
    	try
    	{
      		BufferedReader reader = new BufferedReader(new FileReader(file));
    		String str;
      		while((str = reader.readLine()) != null)
        		text += str + "\n";
      		text = text.trim();
    	}
    	catch(Exception e)
    	{
      		e.printStackTrace();
    	}
    	
    	return(text);
  	}
  	
  	
  	/*---------------------------------------------------------*/
	/*---------------------------------------------------------*/
	//Faz a an�lise sint�tica.
	public Vector trataNumero(String texto)
	{
		int indice = texto.indexOf(".");
		String line = texto.substring(0,indice);
		StringTokenizer linha = new StringTokenizer(texto.substring(0,indice)," ");
		
		Frase frase = new Frase();
		Palavra p;
		frase = formarFrase(linha);
		Vector saida = new Vector(2);
		String resposta = new String ();
		String alterado = null;
		for (int i =0; i<frase.NUMERO_DE_PALAVRAS; i++)
		{
			p = frase.getPalavra(i);

			if(i==0)
			{
				alterado = ((Artigo)p).alteraNumero();
			}
			else if(i==1)
			{
				alterado = ((Substantivo)p).alteraNumero();
			}
			else if(i==2)
				alterado = ((Verbo)p).alteraNumero();
			else if(i==3)
				alterado = ((Artigo)p).alteraNumero();
			else if(i==4)
				alterado = ((Substantivo)p).alteraNumero();
			
			
	
			resposta+=alterado+" ";
		}
		
		saida.add(resposta);
		saida.add(line);
		return saida;	
	}
	
	
	public Frase formarFrase(StringTokenizer linha)
	{
		Frase f = new Frase();
		while(linha.hasMoreElements())
		{
			String token = linha.nextToken();
			Palavra p;

			if(Artigo.isArtigo(token) && Artigo.isArtigoDefinido(token))
			{ 
				 p = new ArtigoDefinido(token);
			}
			else 
				 p = new ArtigoIndefinido(token);
		    if(linha.countTokens() == 2 )
		    {
			    if(Verbo.isPrimeiraConj(token))//depois que passou o verbo pro token sobram 2 outros tokens
			    	p = new PrimeiraConj(token);
			    else if(Verbo.isSegundaConj(token))
			    	p = new SegundaConj(token);
			    else 
			    	p = new TerceiraConj(token);
			}
			else if(!Artigo.isArtigo(token) && linha.countTokens() != 2)
			{
				p = new Substantivo(token);
			}
				
			f.addPalavra(p);
		}
		return f;
	}
	
	
	public Vector trataGenero(String texto)
	{
		int indice = texto.indexOf(".");
		String line = texto.substring(0,indice);
		StringTokenizer linha = new StringTokenizer(texto.substring(0,indice)," ");
		
		Frase frase = new Frase();
		Palavra p;
		frase = formarFrase(linha);
		Vector saida = new Vector(2);
		String resposta = new String ();
		String alterado = null;
		for (int i =0; i<frase.NUMERO_DE_PALAVRAS; i++)
		{
			p = frase.getPalavra(i);

			if(i==0)
			{
				alterado = ((Artigo)p).alteraGenero();
			}
			else if(i==1)
			{
				alterado = ((Substantivo)p).alteraGenero();
			}
			else if(i==2)
				alterado = ((Verbo)p).alteraGenero();
			else if(i==3)
				alterado = ((Artigo)p).alteraGenero();
			else if(i==4)
				alterado = ((Substantivo)p).alteraGenero();
			
			
	
			resposta+=alterado+" ";
		}
		
		saida.add(resposta);
		saida.add(line);
		return saida;	
	}
	
	/*---------------------------------------------------------*/
	
	public static void main (String args[])
	{
		Gui g = new Gui();
		g.launchFrame();
	}
	
}