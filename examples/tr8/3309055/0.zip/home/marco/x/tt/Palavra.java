package com.usp.poo;



public class Palavra
{

String palavra;
	
	public Palavra(String palavra)
	{
		this.palavra = palavra;
	}

/*
	public boolean isVerbo(String verbo)
	{//Como ar,er,ir que seria o certo n�o se encaixa...
		
	}
	
	public boolean isArtigo(String artigo)
	{
		
	}
	
	public boolean isSubstantivo(String subst)
	{
		
	}
*/	
	public String alteraGenero()
	{
		return palavra;
	}
	
	public String alteraNumero()
	{
		System.out.println("Entrou em palavra alteranumero");
		return palavra;
	}
}