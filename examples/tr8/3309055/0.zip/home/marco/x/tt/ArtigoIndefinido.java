package com.usp.poo;




public class ArtigoIndefinido extends Artigo
{
private String artigo_in;//String artigo_in;
	
	
	
	public ArtigoIndefinido(String palavra)
	{
		super(palavra);
		this.artigo_in = palavra;
	}
	
	
	public String alteraGenero()//String artigo_in)
	{
		if(artigo_in.length() == 2)//pq � um.
		{
			return artigo_in.concat("a");
		}
		else if(artigo_in.startsWith("u") && artigo_in.endsWith("as"))
		{
			return artigo_in = "uns";
		}
		else if(artigo_in.matches("uns"))
		{
			return artigo_in = "umas";
		}
		else if (artigo_in.matches("uma"))
		{
			return artigo_in = "um";
		}
		
		return artigo_in;
	}
	
	public String alteraNumero()//String artigo_in)
	{
		if (artigo_in.matches("umas"))
		{
			artigo_in = artigo_in.substring(artigo_in.lastIndexOf('s'));
		}
		else if (artigo_in.matches("uma"))
		{
			artigo_in = artigo_in.concat("s");
		}
		else if (artigo_in.matches("um"))
		{
			artigo_in = artigo_in.replace('m','n');
			artigo_in = artigo_in.concat("s");
		}
		else if (artigo_in.matches("uns"))
		{
			artigo_in = "um";
		}
		
		return artigo_in;
	}
	
}