package com.usp.poo;

public class TerceiraConj extends Verbo
{
	
	private String verbo = palavra;
	
	
	public TerceiraConj(String palavra)
	{	
		super(palavra);
	}
	
	
	public String alteraGenero()//String verbo)
	{
		return verbo;
	}
	
	public String alteraNumero()//String verbo)
	{
		if(verbo.endsWith("e"))
		{
			verbo.concat("m");
		}
		else if(verbo.endsWith("m"))
		{
			verbo = verbo.substring(0,verbo.lastIndexOf("m"));
		}
		
		return verbo;
	}
}