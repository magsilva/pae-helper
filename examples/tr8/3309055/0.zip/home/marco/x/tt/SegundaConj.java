package com.usp.poo;

public class SegundaConj extends Verbo
{
	
	private String verbo;
	
	
	public SegundaConj(String palavra)
	{
		super(palavra);
		verbo = palavra;
	}
	
	
	public String alteraGenero()//String verbo)
	{
		return verbo;
	}
	
	public String alteraNumero()//String verbo)
	{

		if(verbo.endsWith("e"))
		{
			return verbo.concat("m");
		}
		else if (verbo.endsWith("m"))
		{
			verbo = verbo.substring(0,verbo.lastIndexOf('m'));
			return verbo;
		}
		
		return "Parece que vc achou um erro.AlteraNum de verbo 2a conj";
	}
}