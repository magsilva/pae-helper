package com.usp.poo;

public abstract class Artigo extends Palavra 
{
	
Artigo artigo;	

	public Artigo(String palavra)
	{
		super(palavra);
	}
	
	
	
	public static boolean isArtigo(String artigo)
	{
		if( (artigo.matches("o")) || (artigo.matches("os")) ||
		  (artigo.matches("a")) ||
		  (artigo.matches("as")) ||
		  (artigo.matches("um")) ||
		  (artigo.matches("uma"))||
		  (artigo.matches("uns"))||
		  (artigo.matches("umas"))||
		  (artigo.matches("O"))  || (artigo.matches("Os")) ||
		  (artigo.matches("A"))  ||
		  (artigo.matches("As")) ||
		  (artigo.matches("Um")) ||
		  (artigo.matches("Uma"))||
		  (artigo.matches("Uns"))||
		  (artigo.matches("Umas")))	  
		return true;
		  
		else return false;
	}
	
	public static boolean isArtigoDefinido(String artigo)
	{
		if((artigo.matches("o")) ||
		  (artigo.matches("os")) ||
		  (artigo.matches("a"))  ||
		  (artigo.matches("as")) ||
		  (artigo.matches("O"))  ||
		  (artigo.matches("Os")) ||
		  (artigo.matches("A"))  ||
		  (artigo.matches("As")))
		return true;
		else return false;
	}
	
	
	
	//artigo:o,a,os,as.um,uma,uns,umas.
	/**Altera o g�nero do artigo.
	 *@param String artigo.
	 *@return String artigo.
	 *@author Diego.
	 */
	public String alteraGenero()
	{
		if(isArtigoDefinido(palavra))
			return ((ArtigoDefinido)artigo).alteraGenero();
			
		else
			return ((ArtigoIndefinido)artigo).alteraGenero();
	}
	
	/**Altera o n�mero do artigo.
	 *@param String artigo
	 *@return String artigo
	 *@author Diego.
	 */
	public String alteraNumero()
	{

System.out.println("ENTROU EM artigoaltNum");
		if(isArtigoDefinido(palavra))
			return ((ArtigoDefinido)artigo).alteraNumero();
			
		else
			return ((ArtigoIndefinido)artigo).alteraNumero();
	}	
	
	
}