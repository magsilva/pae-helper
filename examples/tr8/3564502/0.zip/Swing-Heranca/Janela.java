/********************************************************************/
/* Exercicio de POO  -- 10 de junho de 2003 -- Profa. Renata Pontin */
/*																	*/
/* Alunos:															*/
/*			Jose Arnaldo Mascagni de Holanda	nUSP: 3564502		*/
/*			Marcus Vinicius Secato				nUSP: 3285140		*/
/********************************************************************/

import java.io.*;
import java.util.*;
import java.lang.*;
import javax.swing.*;   
import javax.swing.filechooser.*;       
import java.awt.*;
import java.awt.event.*;

/***************************** CLASSE JANELA **********************************/

public class Janela extends JPanel 
					implements ActionListener, ItemListener{
	
	static private final String newline = "\n";
    static String opcao1 = "G�nero";
    static String opcao2 = "N�mero";
    JButton openButton, creditsButton, alterarButton;
    JFileChooser fc;
    JTextArea log, stringentrada, stringsaida;
    JCheckBox genero, numero;
    File file;
    Object source2;
     


//----- M�todo para cria��o da Janela(Containers, Button, CheckBox.....) -----//
    public Component criaJanela() {
       
        final JLabel msginicio = new JLabel("Frases originais");			
        final JLabel msgfinal = new JLabel("Frases alteradas");			
        final JLabel msgescolha = new JLabel("Escolha a(s) altera��o(�es)");
        final JLabel regactions = new JLabel("A��es realizadas");

        
	// Defini��o dos componentes da Janela             
        
        stringentrada = new JTextArea(5,20);  		 //caixa de texto para
        stringentrada.setMargin(new Insets(5,5,5,5));//exibir as frases iniciais
       	stringentrada.setEditable(false);
       	JScrollPane entrada = new JScrollPane(stringentrada);
        JPanel fraseinicial = new JPanel();
        	fraseinicial.add(msginicio);
        	fraseinicial.add(entrada);
                
        
        stringsaida = new JTextArea(5,20);			//caixa de texto para
        stringsaida.setMargin(new Insets(5,5,5,5)); //exibir as frases alteradas
       	stringsaida.setEditable(false);
        JScrollPane saida = new JScrollPane(stringsaida);
        JPanel frasefinal = new JPanel();
        	frasefinal.add(msgfinal);
        	frasefinal.add(saida);
        	      	
        
        alterarButton = new JButton("Alterar");//bot�o para ordenar a altera��o
        alterarButton.addActionListener(this);

        JPanel pAlterar = new JPanel();
        	pAlterar.add(alterarButton);
        	
        genero = new JCheckBox(opcao1); //op��o g�nero do Check-Box
        genero.setActionCommand(opcao1);
        genero.addItemListener(this);

        numero = new JCheckBox(opcao2); //op��o n�mero do Check-Box
        numero.setActionCommand(opcao2);
        numero.addItemListener(this);

		
        JPanel menuescolha = new JPanel();
        	menuescolha.setLayout(new GridLayout(0,1));
        	menuescolha.add(msgescolha);
        	menuescolha.add(genero);
        	menuescolha.add(numero);
        	              
      	
	//Definicao do objeto FileChooser(interface para escolha de arquivo)
      	    	
      	log = new JTextArea(5,20); 		   // caixa de texto para registrar as
        log.setMargin(new Insets(5,5,5,5));// opera��es realizadas com arquivos
        log.setEditable(false);
        JScrollPane logJanela = new JScrollPane(log);
   
        fc = new JFileChooser();
	
	//Cria��o dos bot�es Arquivo e Cr�ditos
      	openButton = new JButton("Arquivo"); //bot�o para iniciar abertura de 
      	openButton.addActionListener(this);  //arquivo
      	
      	creditsButton = new JButton("Cr�ditos");//exibe informa��es sobre os
        creditsButton.addActionListener(this);  //criadores do programa

	
    	JPanel menu = new JPanel(); 
    		menu.add(openButton);
        	menu.add(creditsButton);
       
       JPanel nomearq = new JPanel();
        	nomearq.add(regactions);
        	nomearq.add(logJanela);
       
		        
	//Defini��o do container principal que conter� todos componentes da Janela      
		        
        JPanel pane = new JPanel();
        pane.setBorder(BorderFactory.createEmptyBorder(
                                        10, //top
                                        30, //left
                                        10, //bottom
                                        30) //right
                                        );
        pane.setLayout(new GridLayout(0,1));
        pane.add(menu);
        pane.add(nomearq);
        pane.add(menuescolha);
        pane.add(pAlterar);
        pane.add(fraseinicial);
        pane.add(frasefinal);
        
        return pane;
    }
//--------------------- Fim m�todo de cria��o da Janela ----------------------//
    
    
    


//----------- M�todo para definir a a��o relacionada a cada bot�o ------------//
	
    public void actionPerformed(ActionEvent e) {

    	final JLabel linhavazia = new JLabel(" ");

        try {
        	if (e.getSource() == openButton) {
            	int returnVal = fc.showOpenDialog(Janela.this);
            
            	if (returnVal == JFileChooser.APPROVE_OPTION) {
            		file = fc.getSelectedFile();
            		stringentrada.setText("");
            		FileReader leArq = new FileReader(file);
            		BufferedReader buffer = new BufferedReader(leArq);
            		String aux;
            		while ((aux = buffer.readLine()) != null) { 
            			stringentrada.append(aux + "\n");
            		}
            	
           		 	log.append("arquivo aberto: " + file.getName() + "." + newline);
         			leArq.close();

            	} 
            	else {
                	log.append("Opera��o cancelada pelo usu�rio." + newline);

            	}
			} 
			else if (e.getSource() == creditsButton) {

				JLabel info = new JLabel("Programa desenvolvido por:");
				JLabel ze = new JLabel("Jos� Arnaldo Holanda      3564502");
				JLabel marcus = new JLabel("Marcus Vinicius Secato   3285140");
				JFrame creditos = new JFrame("Cr�ditos");
				JPanel cred = new JPanel();
				cred.setBorder(BorderFactory.createEmptyBorder(
             	                           10, //top
              	                           30, //left
               	                           10, //bottom
                                           30) //right
                      	                   );
					cred.setLayout(new GridLayout(0,1));
					cred.add(info);
					cred.add(linhavazia);
					cred.add(ze);
					cred.add(marcus);
				creditos.getContentPane().add(cred, BorderLayout.CENTER);
        		creditos.pack();
        		creditos.setVisible(true);
			}
			else if (e.getSource() == alterarButton) {
				FileReader leArq = new FileReader(file);
            	BufferedReader buffer = new BufferedReader(leArq);
            	String aux;
           		stringsaida.setText("");
            	while ((aux = buffer.readLine()) != null) {
            	
					if (source2 == genero) {
						Frase linha = new Frase(aux,0); // 0 para alterar genero
						numero.setSelected(false);
						stringsaida.append(linha.fraseGen + "\n");
       
					}
						
					if (source2 == numero) {
						Frase linha = new Frase(aux,1); // >=1 para alterar nro
						genero.setSelected(false);
						stringsaida.append(linha.fraseNum + "\n");
					}
				}
				
    		}

		}
		catch (IOException e1) {
			System.out.println("ERRO");
		}
			
	}
	
//-------- Fim M�todo para definir a a��o relacionada a cada bot�o -----------//




//--------- M�todo para definir o campo do Check-Box selecionado -------------//

	public void itemStateChanged(ItemEvent e1) {
        
        source2 = e1.getItemSelectable();
        
  	}

//------- Fim M�todo para definir o campo do Check-Box selecionado -----------//
		
		
		
//---------------------------- Fun��o Principal ------------------------------//
	public static void main(String[] args) {
        
        try {
            UIManager.setLookAndFeel(
                UIManager.getCrossPlatformLookAndFeelClassName());
        } catch (Exception e) {}

        //Create the top-level container and add contents to it.
        JFrame.setDefaultLookAndFeelDecorated(true);
        JDialog.setDefaultLookAndFeelDecorated(true);
        
        JFrame frame = new JFrame("Exercicio Swing - Java");
        Janela jan = new Janela();
        Component conteudo = jan.criaJanela();
        frame.getContentPane().add(conteudo, BorderLayout.CENTER);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}

/*****************************FIM CLASSE JANELA********************************/
