/********************************************************************/
/* Exercicio de POO  -- 10 de junho de 2003 -- Profa. Renata Pontin */
/*																	*/
/* Alunos:															*/
/*			Jose Arnaldo Mascagni de Holanda	nUSP: 3564502		*/
/*			Marcus Vinicius Secato				nUSP: 3285140		*/
/********************************************************************/

/************************** CLASSE FRASE ****************************/

class Frase {
	
	public String frase;
	public String[] palavra;		  // vetor para armazenamento de palavras
	String fraseGen = new String(""); // armazena a frase com o genero alterado
	String fraseNum = new String(""); // armazena a frase com o numero alterado
	
	public Frase(String f, int opcao){
		
		frase = f; // frase recebe um linha do texto do arquivo de entrada
		palavra = frase.split(" "); // divide a frase em palavras
		
		// examina o primeiro artigo da frase
		if ((palavra[0].charAt(0) == 'a') || (palavra[0].charAt(0) == 'o')) {
			ArtigoDefinido art = new ArtigoDefinido(palavra[0]);
			if (opcao == 0) fraseGen += art.genero() + " ";
			else fraseNum += art.numero() + " ";

		}
		else {
			ArtigoIndefinido art = new ArtigoIndefinido(palavra[0]);
			if (opcao == 0) fraseGen += art.genero() + " ";
			else fraseNum += art.numero() + " ";

		}	
		// examina o primeiro substantivo da frase
		Substantivo subs = new Substantivo(palavra[1]);
		if (opcao == 0) fraseGen += subs.genero() + " ";
		else fraseNum += subs.numero() + " ";
		
		// examina o verbo da frase
		if ((palavra[2].endsWith("a")) || (palavra[2].endsWith("am"))) {
			VerboPrimeira verb = new VerboPrimeira(palavra[2]);
			if (opcao == 0) fraseGen += palavra[2] + " ";
			else fraseNum += verb.numero() + " ";

		}
		else {
			VerboSegundaTerceira verb = new VerboSegundaTerceira(palavra[2]);
			if (opcao == 0) fraseGen += palavra[2] + " ";
			else fraseNum += verb.numero() + " ";
	
		}	
		
		// examina o segundo artigo da frase
		if ((palavra[3].charAt(0) == 'a') || (palavra[3].charAt(0) == 'o')) {
		ArtigoDefinido art2 = new ArtigoDefinido(palavra[3]);
			if (opcao == 0) fraseGen += art2.genero() + " ";
			else fraseNum += art2.numero() + " ";
		
		}
		else {
			ArtigoIndefinido art2 = new ArtigoIndefinido(palavra[3]);
			if (opcao == 0) fraseGen += art2.genero() + " ";
			else fraseNum += art2.numero() + " ";
		
		}	
		
		// examina o segundo substantivo da frase
		Substantivo subs2 = new Substantivo(palavra[4]);
		if (opcao == 0)fraseGen += subs2.genero() + ".";
		else fraseNum += subs2.numero() + "";

	}
}

/************************* FIM CLASSE FRASE *************************/

/************************** CLASSE PALAVRA **************************/

class Palavra {

	public String palavra;        
	public Palavra(String pal) {
		palavra = pal;
		
	}			
}

/************************ FIM CLASSE PALAVRA ************************/

/************************* CLASSE ARTIGO ****************************/
class Artigo extends Palavra { // classe derivada da classe Palavra
	
	public Artigo(String a){
		super(a);
	}
}

/************************ FIM CLASSE ARTIGO *************************/

/********************* CLASSE ARTIGO DEFINIDO ***********************/
class ArtigoDefinido extends Artigo {  // classe derivada da classe Artigo que
                                       // trata de artigos definidos
	public String art;	
	public ArtigoDefinido(String ad){
		super(ad);
		art = palavra;			
	}
	
	/****** MUDA O GENERO ******/
	public String genero(){
		String aux;
		if (art.charAt(art.length() - 1) == 'a') {
			aux = art.substring(0,(art.length() -1));
			aux += "o";
			art = new String(aux);
		} 
		else if (art.charAt(art.length() - 1) == 'o') {
			aux = art.substring(0,(art.length() -1));
			aux += "a";
			art = new String(aux);
		}
		else {
			
			if (art.charAt(art.length() - 2) == 'a') {
		
				aux = art.substring(0,(art.length()-2));
				aux += "os";
				art = new String(aux);
			}
			else {
				aux = art.substring(0,(art.length()-2));
				aux += "as";
				art = new String(aux);
			}
		}
	return art;
	}

	/***** MUDA O NUMERO *****/	
	public String numero(){
		String aux;
		
		if (art.endsWith("s")) {
			aux = art.substring(0,(art.length() -1));
			art = new String(aux);
		}
		
		else {
			art += "s";
		}		
		
	return art;
	}
}
/********************** FIM ARTIGO DEFINIDO *************************/

/******************** CLASSE ARTIGO INDEFINIDO **********************/

class ArtigoIndefinido extends Artigo { // classe derivada da classe Artigo que
                                        // trata de artigos indefinidos

	public String art;	
	public ArtigoIndefinido(String ad){
		super(ad);
		art = palavra;			
	}
	
	/****** MUDA O GENERO ******/
	public String genero(){
		String aux;
		
		if (art.endsWith("a")) {
			aux = art.substring(0,(art.length() -1));
			art = new String(aux);
		} 
		else if (art.endsWith("m")){
			
			art.concat("a");
		}
		else if (art.endsWith("s")){
			
			if (art.indexOf("a") != -1){
				art = new String("uns");
			}
			else{
				art = new String("umas");	
			}
		
				
		}
		return art;
	}

	
	/****** MUDA O NUMERO ******/
	public String numero(){
		
		
		if (art.endsWith("a")) {
			art = new String("umas");
		} 
		else if (art.endsWith("m")){
			
			art = new String("uns");
		}
		else if (art.endsWith("s")){
			
			if (art.indexOf("a") != -1){
				art = new String("uma");
			}
			else{
				art = new String("um");	
			}
		
				
		}	
		return art;
	}
}
/********************* FIM ARTIGO INDEFINIDO ************************/

/*********************** CLASSE SUBSTANTIVO *************************/

class Substantivo extends Palavra { // classe derivada da classe Artigo que
                                    // trata de substantivos
	
	public String subs;
	
	public Substantivo (String s){
	
		super(s);
		subs = palavra;	
	}
	
	public String genero(){ // mudanca de genero
		String aux;
		if (subs.endsWith("a")){
			aux = subs.substring(0,(subs.length() - 1));
			aux += "o";
			subs = new String(aux);
		}
		else if (subs.endsWith("o")){
			aux = subs.substring(0,(subs.length() - 1));
			aux += "a";
			subs = new String(aux);
		}
		else if (subs.endsWith("s")){
			int temp = subs.length() - 2;
			if (subs.charAt(temp) == 'a'){
				aux = subs.substring(0,temp);
				aux += "os";
				subs = new String(aux);
			}
			else {
				aux = subs.substring(0,temp);
				aux += "as";
				subs = new String(aux);
			}
		}
		return subs;		
	}
	
	public String numero() { // mudanca de numero
		
		String aux;
		if (subs.endsWith("s")){
			aux = subs.substring(0,(subs.length() - 1));
			subs = new String(aux);
		}
		else{
			subs += "s";	
		}
		return subs;
	}
}
/********************* FIM CLASSE SUBSTANTIVO ***********************/

/************************** CLASSE VERBO ****************************/

class Verbo extends Palavra { // classe derivada da classe Palavra
	
	public Verbo(String v){
	
		super(v);
	}
}
	
/************************ FIM CLASSE VERBO **************************/

/**************** CLASSE VERBO PRIMEIRA CONJUGACAO ******************/

class VerboPrimeira extends Verbo {  // classe derivada da classe Verbo que
                                     // trata de verbos na primeira conjugacao
	
	public String verb;
	
	public VerboPrimeira(String vp){
		super(vp);
		verb = palavra;
	}
	
	public String numero() { // muda o numero do verbo
	
		if (verb.endsWith("m"))	{
			verb = new String(verb.substring(0,(verb.length()- 1)));
		}
		else {
			verb += "m";
		}
		return verb;
	
	}
}
	

/************** FIM CLASSE VERBO PRIMEIRA CONJUGACAO ****************/

/*********** CLASSE VERBO SEGUNDA/TERCEIRA CONJUGACOES **************/

class VerboSegundaTerceira extends Verbo {  
// classe derivada da classe Verbo que trata de verbos na primeira e segunda conjugacao
	
	public String verb;
	
	public VerboSegundaTerceira(String vp) {
		super(vp);
		verb = palavra;
	}
	
	public String numero() { // muda o numero do verbo
		if (verb.endsWith("m"))	{
			verb = new String(verb.substring(0,(verb.length()- 1)));
		}
		else {
			verb += "m";
		}
		return verb;
	}	
}

/********* FIM CLASSE VERBO SEGUNDA/TERCEIRA CONJUGACOES ************/