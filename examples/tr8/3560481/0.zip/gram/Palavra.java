/**************************************************************************
 * Lista de exercicios 7 - Frases, palavras, artigos, numeros             *
 * Alunos															      *
 * Santiago de Moura Luz            3560495								  * 
 * Marco Aurelio Rescia Alher       3560481								  *
 * Cleber Castro Hage               3560345								  *
 *************************************************************************/

package gram;

import java.io.*;

public class Palavra {
	
	public String artGenero (String palavraInicial)
	{
		StringBuffer palavraFinal = new StringBuffer();
		
		if (palavraInicial.compareTo("a") == 0)
			palavraFinal.append('o');
		else if (palavraInicial.compareTo("o") == 0)
			palavraFinal.append('a');
		else if (palavraInicial.compareTo("as") == 0)
			palavraFinal.append('o');
		else if (palavraInicial.compareTo("os") == 0)
			palavraFinal.append('a');
		else if (palavraInicial.compareTo("um") == 0)
			palavraFinal.append("uma");
		else if (palavraInicial.compareTo("uns") == 0)
			palavraFinal.append("umas");			
		else if (palavraInicial.compareTo("uma") == 0)
			palavraFinal.append("um");
		else if (palavraInicial.compareTo("umas") == 0)
			palavraFinal.append("uns");			
			
		// trata as palavras escritas com letras mai�sculas
		else if (palavraInicial.compareTo("A") == 0)
			palavraFinal.append('O');
		else if (palavraInicial.compareTo("O") == 0)
			palavraFinal.append('A');
		else if (palavraInicial.compareTo("As") == 0)
			palavraFinal.append('O');
		else if (palavraInicial.compareTo("Os") == 0)
			palavraFinal.append('A');			
		else if (palavraInicial.compareTo("Um") == 0)
			palavraFinal.append("Uma");
		else if (palavraInicial.compareTo("Uns") == 0)
			palavraFinal.append("Umas");			
		else if (palavraInicial.compareTo("Uma") == 0)
			palavraFinal.append("Um");
		else if (palavraInicial.compareTo("Umas") == 0)
			palavraFinal.append("Uns");
	
		return palavraFinal.toString();
	}


	public String genero (String palavraInicial)
	{
		int ultimo = palavraInicial.length() - 1;
		StringBuffer palavraFinal = new StringBuffer();
		palavraFinal.append(palavraInicial);		

		if (palavraInicial.endsWith("a"))
			palavraFinal.setCharAt(ultimo, 'o');
		else if (palavraInicial.endsWith("o"))
			palavraFinal.setCharAt(ultimo, 'a');
		else if (palavraInicial.endsWith("as"))
			palavraFinal.setCharAt(ultimo - 1, 'o');
		else if (palavraInicial.endsWith("os"))
			palavraFinal.setCharAt(ultimo - 1, 'a');
			
		// trata as palavras escritas com letras mai�sculas
		else if (palavraInicial.endsWith("A"))
			palavraFinal.setCharAt(ultimo, 'O');
		else if (palavraInicial.endsWith("O"))
			palavraFinal.setCharAt(ultimo, 'A');
		else if (palavraInicial.endsWith("As"))
			palavraFinal.setCharAt(ultimo - 1, 'O');
		else if (palavraInicial.endsWith("Os"))
			palavraFinal.setCharAt(ultimo - 1, 'A');			

		return palavraFinal.toString();
	}
	

	public String numero (String palavraInicial)
	{
		int ultimo = palavraInicial.length() - 1;
		StringBuffer palavraFinal = new StringBuffer();
		palavraFinal.append(palavraInicial);
		
		if ((palavraInicial.charAt(ultimo) == 'a') ||
			(palavraInicial.charAt(ultimo) == 'o'))
			palavraFinal.append("s");
		else if ((palavraInicial.charAt(ultimo) == 's') &&
				 (palavraInicial.charAt(ultimo - 1) != 'n'))
			{
				palavraFinal = new StringBuffer();
		    	palavraFinal.append(palavraInicial.substring(0, ultimo));
			}

		// parte q trata o n�mero dos artigos "um", "uns", "Um" e "Uns"
		// poderia fazer parte de um m�todo artNumero(), por exemplo...
		else if (palavraInicial.endsWith("ns"))
		{
		    palavraFinal = new StringBuffer();
		    palavraFinal.append(palavraInicial.substring(0, ultimo));
		    palavraFinal.setCharAt(ultimo - 1, 'm'); //usa (ultimo - 1) pq o length era da palavra original
		}											 //e nao a atual q tem uma letra a menos...
		else if (palavraInicial.endsWith("m"))
		{
		    palavraFinal.setCharAt(ultimo, 'n');
		    palavraFinal.append('s');
		}

		return palavraFinal.toString();
	}
	
	public String verbo (String palavraInicial)
	{
		int ultimo = palavraInicial.length() - 1;
		StringBuffer palavraFinal = new StringBuffer();
		
		if ((palavraInicial.endsWith("a")) || (palavraInicial.endsWith("e")))
		{
			palavraFinal.append(palavraInicial);
			palavraFinal.append('m');
		}
		if ((palavraInicial.endsWith("u")))
		{
			palavraFinal.append(palavraInicial);
			palavraFinal.deleteCharAt(palavraInicial.length() - 1);
			palavraFinal.append("ram");
		}


		// agora ao contr�rio...
		else if (palavraInicial.endsWith("m"))
			palavraFinal.append(palavraInicial.substring(0, ultimo - 1));

		return palavraFinal.toString();
	}
    	
}