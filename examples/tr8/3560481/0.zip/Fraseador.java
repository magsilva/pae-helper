/**************************************************************************
 * Lista de exercicios 7 - Frases, palavras, artigos, numeros             *
 * Alunos															      *
 * Santiago de Moura Luz            3560495								  * 
 * Marco Aurelio Rescia Alher       3560481								  *
 * Cleber Castro Hage               3560345								  *
 *************************************************************************/



// Fraseador

// Java core packages
import java.io.*;
import java.awt.*;
import java.awt.event.*;

// Java extension packages
import javax.swing.*;
import javax.swing.filechooser.*;

import gram.Palavra;

public class Fraseador	extends JFrame
						implements ActionListener
						
{

	private JLabel arquivoLabel,
   		fraseOriginal,
   		fraseModificada,
   		modificar;
	private JTextField arquivoField, /** arquivoField: nome do arquivo a ser lido */
   		fraseField, /** fraseField: frase original retirada do arquivo */
   		displayField; /** displayField: campo em q a frase modificada eh mostrada */
	private JButton openButton,
   		numButton, /** numButton: botao q modifica o numero da frase */
   		genButton, /** genButton: botao q modifica o genero da frase */
		proxButton; /** proxButton: botao q vai para a pr�xima frase do arquivo */
	private JFileChooser fc;

	private BufferedReader arqEntrada; 
	
	public static void main (String args[])
	{
		Fraseador teste = new Fraseador();
		teste.init();
	}
	
	public void init()
  
	{
	  	Container container = getContentPane();
		container.setLayout( new FlowLayout() );
	
	    // set up arquivoLabel and arquivoField
		arquivoLabel = new JLabel( "Nome do Arquivo:" );
		arquivoField = new JTextField( 20 );
    	arquivoField.addActionListener( this );
		container.add( arquivoLabel );
		container.add( arquivoField );

		openButton = new JButton("Abrir arquivo...");
		openButton.addActionListener(this);
		container.add( openButton );     

		fraseOriginal = new JLabel( "      Frase Original: " );
		container.add( fraseOriginal );
      
        // set up fraseField
		fraseField = new JTextField( 30 );
		fraseField.setEditable( false );
		container.add( fraseField );

		fraseModificada = new JLabel( "Frase Modificada: " );
		container.add( fraseModificada );
            
        // set up displayField
		displayField = new JTextField( 30 );
		displayField.setEditable( false );
		container.add( displayField );
      
		modificar = new JLabel( "Modificar: " );
		container.add( modificar );

        // set up numButton
		numButton = new JButton( "N�mero" );
		numButton.addActionListener( this );
		container.add( numButton );

	    // set up genButton
		genButton = new JButton( "G�nero" );
		genButton.addActionListener( this );
		container.add( genButton );

	    // set up proxButton
		proxButton = new JButton( "Pr�xima frase" );
		proxButton.addActionListener( this );
		container.add( proxButton );
      
        setSize(500,150);
        updateDisplay();  // update text in displayField
		setResizable(false);
		show();
		
		this.setVisible(true);
		
	}

   	// handle button and text field events
	public void actionPerformed( ActionEvent actionEvent )
	{
        //Handle open button action.
		if (actionEvent.getSource() == openButton)
		{
			
			// fc = filechooser
			fc = new JFileChooser();
			int returnVal = fc.showDialog(this, "Abrir arquivo...");

			if (returnVal == JFileChooser.APPROVE_OPTION)
        	{
				abreArq();
			}
						
		}
   	  
      // process proxButton event
		else  if ( actionEvent.getSource() == numButton )
			num();
		else if ( actionEvent.getSource() == genButton )
			gen();
 		else if ( actionEvent.getSource() == proxButton )
			prox();
 	  	
      // process arquivoField event
      
		else if ( actionEvent.getSource() == arquivoField )
		{
		displayField.setText(actionEvent.getActionCommand());
		}


		updateDisplay();  // update displayField and status bar
	}
   
   // para abrir o arquivo escolhido
   public void abreArq()  
	{
  		File file = fc.getSelectedFile();
        arquivoField.setText(fc.getSelectedFile().getName());
		
		try 
		{
			arqEntrada = new BufferedReader(new InputStreamReader(new FileInputStream(file )));
		}
		catch (FileNotFoundException e)
		{
			arquivoField.setText("ERRO NA LEITURA");
		};
	}
	
   // funcao do bot�o de proxima frase, pega a proxima frase que esta no arquivo	
   public void prox()
	{
	
		try
			{
		        String linha = arqEntrada.readLine();
		    	fraseField.setText(linha);    
			}
		catch(IOException e)
			{
				displayField.setText("Arquivo n�o aberto");
			}
	}

   
   // update displayField and applet container's status bar
	public void updateDisplay()
	{
		//sei lah pra q serve isso! =P
	}

   // inverte o numero da frase
	public void gen()
	{
		String[] pal = frase();
		Palavra inv0 = new Palavra();
		Palavra inv1 = new Palavra();
		Palavra inv2 = new Palavra();
		Palavra inv3 = new Palavra();
		Palavra inv4 = new Palavra();   		
		displayField.setText( inv0.artGenero(pal[0]) + " "
							+ inv1.genero(pal[1]) + " "
							+ (pal[2]) + " "
							+ inv3.artGenero(pal[3]) + " "
							+ inv4.genero(pal[4]));
	}

	public void num()
	{
		String[] pal = frase();
		Palavra inv0 = new Palavra();
		Palavra inv1 = new Palavra();
		Palavra inv2 = new Palavra();
		Palavra inv3 = new Palavra();
		Palavra inv4 = new Palavra();		
		displayField.setText( inv0.numero(pal[0]) + " "
							+ inv1.numero(pal[1]) + " "
							+ inv2.verbo(pal[2]) + " "
							+ inv3.numero(pal[3]) + " "
							+ inv4.numero(pal[4]));
	}
							
	
	public String[] frase() // Separa a frase em um array de 5 palavras
    {
    	String[] fraseint = fraseField.getText().split("\\s");
    	return fraseint;
    }    

}  // end class Fraseador
