import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.text.*;

public class frase extends JFrame implements ActionListener{
  
  private JButton BtExit = new JButton("Fechar");
  private JButton BtOpenFile = new JButton("Procurar Arquivo");  
  private JButton BtModificaGenero = new JButton("Alterar G�nero");
  private JButton BtModificaNumero = new JButton("Alterar N�mero");
  private JButton BtProxima = new JButton("Pr�xima frase");
  JLabel nome_arq = new JLabel( "Nome do Arquivo:" );
  JLabel originalLabel = new JLabel("Frase do arquivo:");
  JLabel modificadaLabel = new JLabel("Frase modificada:");
  JTextField arquivo_selecionado = new JTextField(20);
  JTextField originalFrase = new JTextField(30);
  JTextField modificadaFrase = new JTextField(30);
  JFileChooser filechooser;
  private BufferedReader arquivo; 
  String aux,linha;

  public frase(){  
    Container c = this.getContentPane();
    c.setLayout(new FlowLayout());    
	
	// n�o � poss�vel editar esses campos
	originalFrase.setEditable(false);
	modificadaFrase.setEditable(false);
	arquivo_selecionado.setEditable(false);

	BtOpenFile.addActionListener(this);
	BtExit.addActionListener(this);
	BtModificaGenero.addActionListener(this);
	BtModificaNumero.addActionListener(this);
	BtProxima.addActionListener(this);

	c.add(nome_arq);
	c.add(arquivo_selecionado);	
	c.add(originalLabel);
	c.add(originalFrase);
	c.add(modificadaLabel);
	c.add(modificadaFrase);
	c.add(BtModificaGenero);
	c.add(BtModificaNumero);
	c.add(BtProxima);
	c.add(BtOpenFile);
    c.add(BtExit);  

	this.setSize(350,220);
	this.setResizable(false);
    this.show();
  }
 
  
  public void actionPerformed(ActionEvent e){

	if(e.getSource() == BtExit){
      System.exit(0);
    }
    else if(e.getSource()== BtOpenFile){
	  String estringue = "";
		
      filechooser = new JFileChooser();
      if(filechooser.showOpenDialog(this.getContentPane()) != JFileChooser.CANCEL_OPTION){
	    processa_arq();
	  } else if(e.getSource() == BtModificaNumero) {
		modificaNumeroFrase();
	  }	else if(e.getSource() == BtModificaGenero) {
		modificaGeneroFrase();
	  } else if(e.getSource() == BtProxima) {
		proximaFrase();
	  }

	} // end else
} // end do m�todo actionPerformed
	
  public void processa_arq() {
		
	File file = filechooser.getSelectedFile();
	
	// exibe o arquivo selecionado
	arquivo_selecionado.setText(filechooser.getSelectedFile().getName());
		
	try {
	  arquivo = new BufferedReader(new InputStreamReader(new FileInputStream(file)));
	}
	catch (FileNotFoundException e){}
  }

  public void modificaGeneroFrase(){
    String palavras[] = aux.split(" ");		
		
	artigo p1 = new artigo(palavras[0]);
	substantivo p2 = new substantivo(palavras[1]);
	verbo p3 = new verbo(palavras[2]);
	artigo p4 = new artigo(palavras[3]);
	substantivo p5 = new substantivo(palavras[4]);
	
	modificadaFrase.setText(p1.mudagenero()+ " " +
		p2.mudagenero() + " " +
		p3.mudagenero() + " " +
		p4.mudagenero() + " " +
		p5.mudagenero());
  } 
	
  public void modificaNumeroFrase(){
	String[] palavras = fraseToVector();

	artigo p1 = new artigo(palavras[0]);
	substantivo p2 = new substantivo(palavras[1]);
	verbo p3 = new verbo(palavras[2]);
	artigo p4 = new artigo(palavras[3]);
	substantivo p5 = new substantivo(palavras[4]);
	
	modificadaFrase.setText(p1.singplu() + " " +
							p2.singplu() + " " +
							p3.singplu() + " " +
							p4.singplu() + " " +
							p5.singplu());
  }
  
  // le proxima linha do arquivo
  public void proximaFrase(){
	try{
      linha = arquivo.readLine();
	  originalFrase.setText(linha);
	  aux = linha;
	}
	catch(IOException e){}
  }
	
  public static void main(String args[]){
    frase _frase = new frase(); 
  }	
	
  // armazena a frase original em um vetor
  public String[] fraseToVector(){
	String[] vectorFrase = originalFrase.getText().split(" ");
	
	return vectorFrase;
  }    

} // end da classe frase

abstract class palavra {
	abstract String singplu();
	abstract String mudagenero();
}

class artigo extends palavra { // o/a/um/uma/uns/umas
	String _artigo;
		
	artigo(String letras) {
		_artigo = letras;
	}
	
	public String singplu() {
		// trata o caso de 'um'
		if(_artigo.endsWith("m"))
			_artigo.replace('m','n');
		
		_artigo.concat("s");
		
		return _artigo;
	}

	public String mudagenero() {
		if(_artigo == "o")
			_artigo = "a";
		else if(_artigo == "a")
			_artigo = "o";
		else if(_artigo == "um")
			_artigo += "a";
		else if(_artigo == "uma")
			// tira 'a' de _artigo
			_artigo = _artigo.substring(0,2);
		else if(_artigo == "uns")
			_artigo = "umas";

		return _artigo;
	}
}

class substantivo extends palavra { // gato/rato
	String _substantivo;
	
	substantivo(String letras) {
		_substantivo = letras;
	}
	
	public String singplu() {
		_substantivo.concat("s");
		return _substantivo;
	}
	
	public String mudagenero() {

		if(_substantivo.endsWith("a")) {
			// tira �ltima letra do substantivo
			_substantivo.substring(0,_substantivo.length()-1);
			_substantivo.concat("o");
		} else {
			// tira �ltima letra do substantivo
			_substantivo.substring(0,_substantivo.length()-1);
			_substantivo.concat("a");
		}
		
		return _substantivo;
	}
}

class verbo extends palavra { // andar/correr/rir
	String _verbo;
	
	verbo(String letras) {
		_verbo = letras;
	}
	
	public String singplu() {
		// tira �ltima letra do verbo
		_verbo.substring(0,_verbo.length()-1);
		_verbo.concat("ram");
		
		return _verbo;
	}
	
	public String mudagenero() {
		return _verbo;
	}
}
