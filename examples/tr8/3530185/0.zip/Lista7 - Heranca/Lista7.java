/*################################################################
##	Lista 7 sobre JAVA - Heranca / Swing						##
##	USP - ICMC - Bacharelado em Ciencia da Computacao - 2001	##
##	Katsumi Arackawa Junior N#3530185							##
##	Data de Entrega: 10/06/03									##
##	Profa. Renata Pontin M. Fortes								##
##################################################################*/

import javax.swing.*;
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;

public class Lista7 extends JFrame implements ActionListener{
	private JPanel Paineldebotoes, P1, P2, Prin;
	private JButton botoes[];
	private JTextArea Saida;
	private JTextArea Entrada;
	private JLabel L1, L2;
	public BufferedReader b;
	String textoentrada, textomod, textosaida = "";
	String textoteste;
	
	
	Lista7(){
		super("Lista 7 - Heranca / Swing");
		
		Container c = getContentPane();
		//Painel com as Frases Originais
		P1 = new JPanel();
		P1.setLayout(new BorderLayout());
		L1 = new JLabel("Frase do Arquivo:");
		Entrada = new JTextArea(2,30);
		P1.add(L1, BorderLayout.NORTH);
		P1.add(Entrada, BorderLayout.SOUTH);
		//Painel com as Frases Modificadas
		P2 = new JPanel();
		P2.setLayout(new BorderLayout());
		L2 = new JLabel("Frase Modificada (Genero / Numero):");
		Saida = new JTextArea(10,30);
		P2.add(L2, BorderLayout.NORTH);
		P2.add(Saida, BorderLayout.CENTER);
		//Painel de Botoes
		Paineldebotoes = new JPanel();
		botoes = new JButton[4];
		Paineldebotoes.setLayout(new GridLayout(1, botoes.length));
		// Botoes do Painel de Botoes
		botoes[0] = new JButton("Abre Arquivo");
		botoes[0].addActionListener(this);
		Paineldebotoes.add(botoes[0]);
				
		botoes[1] = new JButton("Muda Genero");
		botoes[1].addActionListener(this);
		Paineldebotoes.add(botoes[1]);
		
		botoes[2] = new JButton("Muda Numero");
		botoes[2].addActionListener(this);
		Paineldebotoes.add(botoes[2]);
		
		botoes[3] = new JButton("Proximo");
		botoes[3].addActionListener(this);
		Paineldebotoes.add(botoes[3]);
		
		//Fonte da Area de Texto
		Entrada.setFont(new Font("Arial", Font.BOLD, 13));
		Saida.setFont(new Font("Corier", Font.PLAIN, 12));
		//Adicionando os Paineis no container
		c.add(P1, BorderLayout.NORTH);
		c.add(P2, BorderLayout.CENTER);
		c.add(Paineldebotoes, BorderLayout.SOUTH);
		setSize (460,400);		
		show();
		
		}
	//Metodo de Abertura do Arquivo	
	public void abrirArquivo()
  { 
    FileDialog f = new FileDialog(this, "Selecione um Arquivo", FileDialog.LOAD);
    f.setVisible(true);
    String nomeArquivo = f.getFile();
    if (nomeArquivo != null)
    {try
      { File arquivo = new File(nomeArquivo);
        b = new BufferedReader(new InputStreamReader (new FileInputStream(arquivo)));
        Entrada.setText(b.readLine());}
      catch (IOException e)
      {System.out.println("Erro na abertura do arquivo");} 
    }
  }
  	//Metodo que Adiciona a proxima frase do Arquivo
	public void proximafrase(){
		try{
		Entrada.append(b.readLine());}
		catch (IOException e){};
	}		
	//Metodo que executa as acoes nos botoes	
	public void actionPerformed(ActionEvent evt)
   {if (evt.getSource() == botoes[0])
        abrirArquivo();
    if (evt.getSource() == botoes[1]){
    	textoentrada = Entrada.getText();
    	Mudafrase teste =  new Mudafrase(textoentrada);
    	textosaida += (teste.Mudagenero() + "\n");
    	Saida.setText(textosaida);
      	} 
    if (evt.getSource() == botoes[2]){ 
     	textoentrada = Entrada.getText();
    	Mudafrase teste2 =  new Mudafrase(textoentrada);
    	textosaida += (teste2.Mudanumero() + "\n");
    	Saida.setText(textosaida);
    	}
    if (evt.getSource() == botoes[3])
    {try{
			Entrada.setText(b.readLine());
		}catch (IOException e){};
    }
   }
	//Programa principal
	public static void main(String[] args) throws IOException {
    Lista7 app = new Lista7();
    
    app.addWindowListener(
    	new WindowAdapter(){
    		public void windowClosing(WindowEvent e){
    			System.exit(0);
    			}
    		}
    	); 
    }
}

//classe que efetua as mudancas de genero e numero dos artigos
class Artigo{
	public String artigo, temp; 
	private String artigonovo;
	
	Artigo(String art){
		this.artigo = art;
		}
	//metodo da classe Artigo
	public String genero(){
		if ((this.artigo.equals("O")) || (this.artigo.equals("o")))		 artigonovo = "A";   else
		if ((this.artigo.equals ("Um")) || (this.artigo.equals("um"))) 	 artigonovo = "Uma"; else
		if ((this.artigo.equals("Os")) || (this.artigo.equals("os")))	 artigonovo = "As";  else
		if ((this.artigo.equals("Uns")) || (this.artigo.equals("uns")))	 artigonovo = "Umas";else
		if ((this.artigo.equals("A")) || (this.artigo.equals("a")))		 artigonovo = "O";   else
		if ((this.artigo.equals ("Uma")) || (this.artigo.equals("uma"))) artigonovo = "Um";  else
		if ((this.artigo.equals("As")) || (this.artigo.equals("as")))	 artigonovo = "Os";  else
		if ((this.artigo.equals("Umas")) || (this.artigo.equals("umas")))artigonovo = "Uns";
		return (artigonovo);	
	}
	//outro metodo da classe Artigo
	public String numero(){
		if ((this.artigo.equals("O"))||(this.artigo.equals("o")))	   artigonovo = "Os";  else
		if ((this.artigo.equals("A"))||(this.artigo.equals("a")))	   artigonovo = "As";  else
		if ((this.artigo.equals("Um"))||(this.artigo.equals("um")))	   artigonovo = "Uns"; else
		if ((this.artigo.equals("Uma"))||(this.artigo.equals("uma")))  artigonovo = "Umas";else
		if ((this.artigo.equals("Os"))||(this.artigo.equals("os")))	   artigonovo = "O";   else
		if ((this.artigo.equals("As"))||(this.artigo.equals("as")))	   artigonovo = "A";   else
		if ((this.artigo.equals("Uns"))||(this.artigo.equals("uns")))  artigonovo = "Um";  else
		if ((this.artigo.equals("Umas"))||(this.artigo.equals("umas")))artigonovo = "Uma";
	return artigonovo;
	}
}
//classe que efetua as mudancas de genero e numero dos substantivos
class Substantivo { 
	String subst, subnovo;
	int tam; //tamanho da string
	
	public Substantivo(String subs){
		subst = subs;
		this.tam = this.subst.length();
	}
	// retorna o substantivo modificado em genero
	public String genero(){
	if (this.subst.endsWith("a")) 		subnovo = this.subst.substring(0, (this.tam - 1)) + "o";   
    if (this.subst.endsWith("o"))		subnovo = this.subst.substring(0, (this.tam - 1)) + "a";   	
    if (this.subst.endsWith("as"))		subnovo = this.subst.substring(0, (this.tam - 2)) + "os";   
    if (this.subst.endsWith("os"))		subnovo = this.subst.substring(0, (this.tam - 2)) + "as";   
    return subnovo; 	
	}	
	//retorna o substantivo modificado em numero	
	public String numero(){
	if((this.subst.endsWith("a")) || (this.subst.endsWith("o"))) subnovo = this.subst + "s";    
    if ((this.subst.endsWith("as") || this.subst.endsWith("os"))) 
    subnovo= this.subst.substring(0,(this.tam - 1));    
    return subnovo;
	}
}

//classe que efetua as mudancas de genero do Verbo
class Verbo{
	String verbonovo;
	String verbo;
	int tam;
	
	public Verbo(String verb){
		this.verbo = verb;
		this.tam= verb.length();
		}
	//retorna o verbo modificado em numero
	public String numero(){
		if (this.verbo.endsWith("e") || this.verbo.endsWith("a")) verbonovo = this.verbo + "m";	else 
		if (this.verbo.endsWith("i")) verbonovo = this.verbo.substring(0, (tam - 1))+"em";		else
		if (this.verbo.endsWith("m")) verbonovo = this.verbo.substring(0, (tam-1));
		return (verbonovo);
	}
	//retorna o verbo modificado em genero
	public String genero(){
		return (this.verbo);
	}
}
//classe que efetua o modificacao da frase
class Mudafrase{
	String frase;
	String [] palavra;
	String modifica;
	
	public Mudafrase(String f){
		this.frase = f;
		this.palavra = f.split("\\s");
		this.modifica ="";
	}
	// metodo que muda o genero da frase
	public String Mudagenero (){
	this.palavra = this.frase.split("\\s");
	
	Artigo a1 = new Artigo(palavra[0]);
	Artigo a2 = new Artigo(palavra[3]);
	Substantivo s1 = new Substantivo(palavra[1]);
	Substantivo s2 = new Substantivo(palavra[4]);
	Verbo v = new Verbo(palavra[2]);
	
	this.modifica = a1.genero()+" "+ s1.genero()+" "+v.genero()+" "+a2.genero()+" "+ s2.genero();
    return(this.modifica);
	}
	//metodo que muda o numero da frase
	public String Mudanumero (){
	this.palavra = this.frase.split("\\s");
	
	Artigo a1 = new Artigo(palavra[0]);
	Artigo a2 = new Artigo(palavra[3]);
	Substantivo s1 = new Substantivo(palavra[1]);
	Substantivo s2 = new Substantivo(palavra[4]);
	Verbo v = new Verbo(palavra[2]);
	
	this.modifica = a1.numero()+" "+ s1.numero()+" "+v.numero()+" "+a2.numero()+" "+ s2.numero();
    return(this.modifica);
	}
}

