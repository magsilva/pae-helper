Exercicio de POO - JAVA

1) O Programa possui uma interface muito Facil.
Primeiro eh preciso Adicionar um arquivo com as frases no formato:

<Artigo> <Substantivo> <Verbo> <Artigo> <Substantivo>

2) Como Exemplo Utilizamos o arquivo: Arquivo.txt Anexado.

3) No Layout do Programa existe 4 Botoes.

Abrir - Abre o Arquivo que contem as frases a serem modificadasd.
Mudar Genero - Muda o Genero da Frase 
Mudar Numero - Muda em numero a Frase da Area texto Superior
Proxima - Adiciona a Frase seguinte do Arquivo

Creditos:
Elaborado por 	Katsumi Arackawa Junior 
		NUSP:3530185

	

