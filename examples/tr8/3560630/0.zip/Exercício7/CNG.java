/*Exerc�cio Heran�a e Swing - data 10/06/2003
  Alunos: 	Jo�o Paulo Scardua Coelho  	nUSP 3560630
  			Marco Aur�lio Roncatti		nUSP 3455855*/	

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;
import java.util.*;

//-------------------------------Defini��o das classes utilizadas em CNG---------------------------------------------//

//Esta frase possui o metodo modifica que recebe como par�metro 
//uma frase e o tipo de modifica��o (genero ou n�mero) que ser� feita
class Frase{
	public String modifica(String frase, int tipo){
		String result = "";
		//declara��o dos objetos que ser�o utilizados
		ArtigoDefinido artdef = new ArtigoDefinido();
		ArtigoIndefinido artindef = new ArtigoIndefinido();
		Substantivo nome = new Substantivo();
		PrimConj verboprim = new PrimConj();
		SegTercConj verbosegterc = new SegTercConj();

		//transforma a frase em um array de strings
		String palavra[] = frase.split("\\s");

		if (tipo == 0){ // Modifica numero

			//altera primeiro artigo
			if ((palavra[0].startsWith("u")) || (palavra[0].startsWith("U")))
				result += artindef.altera_numero(palavra[0]) + " ";
			else // � artigo definido
				result += artdef.altera_numero(palavra[0]) + " ";

			//altera primeiro substantivo
			result += nome.altera_numero(palavra[1]) + " ";

			//altera verbo da primeira conjugacao
			if ((palavra[2].endsWith("am")) || (palavra[2].endsWith("a")))
				result += verboprim.altera(palavra[2]) + " ";

			//altera verbo da segunda e terceira conjugacao
			else
				result += verbosegterc.altera(palavra[2]) + " ";
			
			//altera segundo artigo
			if ((palavra[3].startsWith("u")) || (palavra[3].startsWith("U")))
				result += artindef.altera_numero(palavra[3]) + " ";
			else // � artigo definido
				result += artdef.altera_numero(palavra[3]) + " ";

			//altera segundo substantivo
			result += nome.altera_numero(palavra[4]);

		}//fim do if modifica numero

		else{ //(tipo == 1) // modifica genero
			//altera primeiro artigo
			if ((palavra[0].startsWith("u")) || (palavra[0].startsWith("U")))
				result += artindef.altera_genero(palavra[0]) + " ";
			else // � artigo definido 
				result += artdef.altera_genero(palavra[0]) + " ";

			//altera primeiro substantivo
			result += nome.altera_genero(palavra[1]) + " ";

			//retorna o mesmo verbo, pois na mudan�a de genero este n�o se modidifica
			result += (palavra[2]) + " ";

			//altera segundo artigo
			if ((palavra[3].startsWith("u")) || (palavra[3].startsWith("U")))
				result += artindef.altera_genero(palavra[3]) + " ";
			else // � artigo definido
				result += artdef.altera_genero(palavra[3]) + " ";

			//altera segundo substantivo
			result += nome.altera_genero(palavra[4]);

		}

		return result;
	}
}

//Esta classe Palavra foi definida somente para se obedecer o crit�rio de heran�a 
//proposto pelo exerc�cio, mas n�o implementa nada em espec�fico
class Palavra {
}

class Artigo extends Palavra {
	public String altera(String art, String[] inart, String[] outart){
		int pos = 0;
		String result = "";
		while (!(inart[pos].equals(art)))
			pos ++;
		return outart[pos];
	}
}

class ArtigoDefinido extends Artigo {
	private final String[] in =  {"o", "a", "os", "as", "O", "A", "Os", "As"};
	private final String[] outgen = {"a", "o", "as", "os", "A", "O", "As", "Os"};
	private final String[] outnum = {"os", "as", "o", "a", "Os", "As", "O", "A"};

	public String altera_genero(String art_def){
		return altera(art_def,in, outgen);
	}

	public String altera_numero(String art_def){
		return altera(art_def,in, outnum);
	}
}

class ArtigoIndefinido extends Artigo {
	private String[] in =  {"um", "uma", "uns", "umas", "Um", "Uma", "Uns", "Umas"};
	private String[] outgen = {"uma", "um", "umas", "uns", "Uma", "Um", "Umas", "Uns"};
	private String[] outnum =  {"uns", "umas", "um", "uma", "Uns", "Umas", "Um", "Uma"};

	public String altera_genero(String art_indef){
		return altera(art_indef,in, outgen);
	}

	public String altera_numero(String art_indef){
			return altera(art_indef,in, outnum);
	}
}

class Substantivo extends Palavra {
	private String result = "";

	public String altera_numero(String nome){
		int tam = nome.length();
		if (nome.endsWith("s"))
			result = nome.substring(0,tam - 1);
		else if (nome.endsWith("or"))
			result = nome + "es";
		else //palavra termina em 'a' ou 'o'
			result = nome + "s";
		return result;

	}

	public String altera_genero(String nome){
		int tam = nome.length();
		if (nome.endsWith("as"))
			result = nome.substring(0,tam - 2) + "os";
		else if	(nome.endsWith("os"))
			result = nome.substring(0,tam - 2) + "as";
		else if	(nome.endsWith("a"))
			result = nome.substring(0,tam - 1) + "o";
		else if	(nome.endsWith("o"))
			result = nome.substring(0,tam - 1) + "a";
		else if	(nome.endsWith("r"))
			result = nome + "a";
		else if	(nome.endsWith("ra"))
			result = nome.substring(0,tam - 1);
		return result;
	}
}

//Esta classe Verbo foi definida somente para se obedecer o crit�rio de heran�a 
//proposto pelo exerc�cio, mas n�o implementa nada em espec�fico
class Verbo extends Palavra{
}

class PrimConj extends Verbo {
	public String altera(String nome){
		int tam = nome.length();
		if (nome.endsWith("a"))
			return nome + "m";
		else //verbo termina em "am"
			return nome.substring(0,tam - 1);
	}
}

class SegTercConj extends Verbo {
	public String altera(String nome){
		int tam = nome.length();
		if (nome.endsWith("e"))
			return nome + "m";
		else //verbo termina em "em"
			return nome.substring(0,tam - 1);
	}

}

//-------------------------------Inicio da Classe Principal da Aplica��o, CNG---------------------------------------------//

public class CNG extends JPanel implements ActionListener{

	JFileChooser fc;
	JTextField nomeArquivo;
	JButton bAbrir, bModifica;
	JTextArea frasesOri, frasesMod;
	JRadioButton numero, genero;

//---------------------------------------Inicio do Construtor---------------------------------------------//

	public CNG(){

//---------------------------------------Montagem da interface---------------------------------------------//


		setLayout(new BorderLayout());

	//Cria painel para a parte de cima da janela
		JPanel p1 = new JPanel();
		p1.setLayout(new FlowLayout());
		add(p1, BorderLayout.NORTH);

	//Campo para exibir o nome do arquivo
		nomeArquivo = new JTextField(20);
		nomeArquivo.setEditable(false);
		JLabel naLabel = new JLabel("Nome do arquivo: ");
		p1.add(naLabel);
		p1.add(nomeArquivo);

	//Botao para abrir arquivo
		bAbrir = new JButton("Abrir arquivo");
		bAbrir.addActionListener(this);
		p1.add(bAbrir);

	//Seletor de modifica��o a ser realizada
		numero = new JRadioButton("N�mero");
		numero.setSelected(true);
		genero = new JRadioButton("G�nero");
		ButtonGroup group = new ButtonGroup();
		group.add(numero);
		group.add(genero);
		p1.add(numero);
		p1.add(genero);

	//Botao para executar as modifica��es
		bModifica = new JButton("Modificar");
		bModifica.addActionListener(this);
		p1.add(bModifica);


	//�rea para exibir arquivo original
		frasesOri = new JTextArea(10, 30);
		frasesOri.setEditable(false);
		JScrollPane spOri = new JScrollPane(frasesOri);
		spOri.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		spOri.setBorder(
			BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder("Texto Original"),
				BorderFactory.createEmptyBorder(5,5,5,5)));
		add(spOri, BorderLayout.WEST);

	//�rea para exibir a modifica��o
		frasesMod = new JTextArea(10, 30);
		frasesMod.setEditable(false);
		JScrollPane spMod = new JScrollPane(frasesMod);
        spMod.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
		spMod.setBorder(
			BorderFactory.createCompoundBorder(
				BorderFactory.createTitledBorder("Texto Modificado"),
				BorderFactory.createEmptyBorder(5,5,5,5)));
		add(spMod, BorderLayout.EAST);

//---------------------------------------Declara��o da caixa de dialogo-------------------------------------//

		fc = new JFileChooser();

	}
//---------------------------------------Fim do Construtor---------------------------------------------//

	public void actionPerformed(ActionEvent e) {

		//Bot�o Abrir Arquivo
		if (e.getSource() == bAbrir){

			int returnVal = fc.showOpenDialog(CNG.this);
			if (returnVal == JFileChooser.APPROVE_OPTION) {
				try {

					String linha;

					File file = fc.getSelectedFile();
					nomeArquivo.setText(file.getName());

					BufferedReader in = new BufferedReader(new FileReader(file));
					frasesOri.setText("");
					while ((linha = in.readLine()) != null) {
						frasesOri.append(linha + "\n");
					}

					in.close();

				}
				catch (IOException ioE) {
					System.err.println("Erro ao ler arquivo: " + ioE);
				}


			}
		}

		//Bot�o Modifica
		if (e.getSource() == bModifica){
			frasesMod.setText("");
			Frase fraseclasse = new Frase();
			StringTokenizer frasestokens = new StringTokenizer(frasesOri.getText(), "\n");
			String frModificada = "";
			while(frasestokens.hasMoreTokens()){
				if (numero.isSelected())
					//chama o metodo modifica da classe Frase para alterar o numero da frase
					frModificada = fraseclasse.modifica(frasestokens.nextToken(), 0);//modifica numero
				else	//genero.isSelected()
					//chama o metodo modifica da classe Frase para alterar o genero da frase
					frModificada = fraseclasse.modifica(frasestokens.nextToken(), 1) ;//modifica genero

				frasesMod.append(frModificada + "\n");

			}
		}
	}

	public static void main(String[] args){
		JFrame frame = new JFrame("Conversor de N�mero e G�nero");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		CNG pane = new CNG();
		frame.getContentPane().add(pane);

		frame.pack();
		frame.setVisible(true);
	}

}//Fim da Classe CNG