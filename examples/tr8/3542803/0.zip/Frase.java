class Frase {
// A frase desta aplica��o somente aceita a seq��ncia Art-Subst-Verbo-Art-Subst   
   int numPalavras = 0;
   String palavras[];
   boolean valido = false;  // Uma frase v�lida � a que segue essa seq��ncia
   Artigo      p1;
   Substantivo p2;
   Verbo       p3;
   Artigo      p4;
   Substantivo p5;
   
   public Frase(String s) {
      palavras = XString.split(s, ' ');
      if ((numPalavras = palavras.length) == 5) {
         valido = true;
         p1 = new Artigo(palavras[0]);
         p2 = new Substantivo(palavras[1]);
         p3 = new Verbo(palavras[2]);
         p4 = new Artigo(palavras[3]);
         p5 = new Substantivo(palavras[4]);
      }
      else
         valido = false;
   }
   
   public String toString() {
      String s;
      s = p1.toString() + " ";
      s += p2.toString() + " ";
      s += p3.toString() + " ";
      s += p4.toString() + " ";
      s += p5.toString();
      return s;
   }
   
   public boolean ehValido() {
      return valido;
   }

   public void muda(boolean valorGenero, boolean valorNumero) {
      if (valorGenero) {
         p1.alteraGenero(); p2.alteraGenero(); p3.alteraGenero();
         p4.alteraGenero(); p5.alteraGenero();
      }
      if (valorNumero) {
         p1.alteraNumero(); p2.alteraNumero(); p3.alteraNumero();
         p4.alteraNumero(); p5.alteraNumero();
      }
   }
}