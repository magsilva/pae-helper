class Verbo extends Palavra {
   public Verbo(String s) {
      super(s);
   }
   
   public void alteraNumero() {
      if (dir(conteudo, 1).equalsIgnoreCase("m"))
         conteudo = esq(conteudo, -1);
      else 
         conteudo += "m";
   }
   
   public void alteraGenero() {
   }
}