class Artigo extends Palavra {
   public Artigo(String s) {
      super(s);
   }
   
   public void alteraGenero() {
      if (conteudo.equalsIgnoreCase("um"))
         conteudo = "uma";
      else if (conteudo.equalsIgnoreCase("uma"))
         conteudo = "um";
      else if (conteudo.equalsIgnoreCase("uns"))
         conteudo = "umas";
      else if (conteudo.equalsIgnoreCase("umas"))
         conteudo = "uns";
      else
         alteraGenero2();
   }
   
   public void alteraNumero() {
      alteraNumero2();
   }
}