class Texto {
   int numFrases = 0;
   boolean valido = false;
   Frase frases[];
   
   public Texto(String s) {
      String strFrases[];
      strFrases = XString.split(s, '\n');
      numFrases = strFrases.length;
      frases = new Frase[numFrases];

      valido = true;
      for (int i = 0; i < numFrases; i++) {
         frases[i] = new Frase(strFrases[i].trim());
         valido = valido && frases[i].ehValido();
      }  
   }

   public String toString() {
      if (valido) {
         String s = "";
         for (int i = 0; i < numFrases; i++)
            s += frases[i] + ((i < numFrases - 1) ? "\n" : "");
         return s;
      }
      else {
         return "O texto � inv�lido.";   
      }
   }

   public boolean ehValido() {
      return valido;
   }
   
   public void muda(boolean valorGenero, boolean valorNumero) {
      for (int i = 0; i < numFrases; i++)
         frases[i].muda(valorGenero, valorNumero);
   }
}