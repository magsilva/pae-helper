class Substantivo extends Palavra {
   public Substantivo(String s) {
      super(s);
   }
   
   public void alteraGenero() {
   // Exemplos de Substantivos irregulares
      if (conteudo.equalsIgnoreCase("mulher"))
         conteudo = "homem";
      else if (conteudo.equalsIgnoreCase("homem"))
         conteudo = "mulher";
      else if (conteudo.equalsIgnoreCase("mulheres"))
         conteudo = "homens";
      else if (conteudo.equalsIgnoreCase("homens"))
         conteudo = "mulheres";
      else
         alteraGenero2();
   }
   
   public void alteraNumero() {
      // Exemplos de Substantivos que n�o seguem o plural +"s" ou +"is"
      if (conteudo.equalsIgnoreCase("mulher"))
         conteudo = "mulheres";
      else if (conteudo.equalsIgnoreCase("mulheres"))
         conteudo = "mulher";

      // Outros casos
      else  
         alteraNumero2();
   }
}