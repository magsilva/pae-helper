class Palavra {
   String conteudo;
   
   public Palavra(String s) {
      conteudo = s;
   }
   
   static public String dir(String s, int n) {
      // Retorna uma string com as n ultimas letras da Palavra.
      return s.substring(s.length() - n);
   }
   
   static public String esq(String s, int n) {
      // Retorna uma string com as n primeiras letras da Palavra.
      // Se n < 0, retorna uma string com a Palavra inteira
      //   menos as ultimas |n| letras.
      if (n > 0)
         return s.substring(0, n);
      else
         return s.substring(0, s.length() + n);
   }

   public void alteraGenero2() {
      if (dir(conteudo, 1).equalsIgnoreCase("o"))
         conteudo = (esq(conteudo, -1) + "a");
      else if (dir(conteudo, 1).equalsIgnoreCase("a"))
         conteudo = (esq(conteudo, -1) + "o");
      else if (conteudo.length() > 1) {
         if (dir(conteudo, 2).equalsIgnoreCase("os"))
            conteudo = (esq(conteudo, -2) + "as");
         else if (dir(conteudo, 2).equalsIgnoreCase("as"))
            conteudo = (esq(conteudo, -2) + "os");
      }
   }
   
   public void alteraNumero2() {
      if (dir(conteudo, 1).equalsIgnoreCase("m"))
         conteudo = (esq(conteudo, -1) + "ns");
      else if (dir(conteudo, 1).equalsIgnoreCase("l"))
         conteudo = (esq(conteudo, -1) + "is");
      else if ((conteudo.length() > 1) && (dir(conteudo, 2).equalsIgnoreCase("ns")))
            conteudo = (esq(conteudo, -2) + "m");
      else if ((conteudo.length() > 1) && (dir(conteudo, 2).equalsIgnoreCase("is")))
            conteudo = (esq(conteudo, -2) + "l");
      else if (!dir(conteudo, 1).equalsIgnoreCase("s"))
         conteudo = (conteudo + "s");
      else if (dir(conteudo, 1).equalsIgnoreCase("s"))
         conteudo = (esq(conteudo, -1));
   }
   
   public String toString() {
      return conteudo;
   }
}