import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.filechooser.*;

public class Exerc1 extends JFrame implements ActionListener {

// Inicializadores dos componentes
   JPanel panU, panD, panL, panR;
   Label arqNome = new Label("(Nenhum documento aberto)");
   Button btnAbrir = new Button("Abrir");  
   Label status = new Label("Clique no bot�o Abrir para selecionar um arquivo...");
   TextArea txtOrig = new TextArea(null, 0, 0, java.awt.TextArea.SCROLLBARS_VERTICAL_ONLY);
   TextArea txtMod  = new TextArea(null, 0, 0, java.awt.TextArea.SCROLLBARS_VERTICAL_ONLY);
   Button btnGenero = new Button("G�nero");
   Button btnNumero = new Button("N�mero");
   JFileChooser fc = new JFileChooser();

// O Texto que ser� tratado
   Texto textoSaida;

// M�todo que l� o texto de um arquivo
   public String fileStream(File inputFile) {
      String s = null;
      try {
         FileInputStream in = new FileInputStream(inputFile);
         byte bt[] = new byte[(int)inputFile.length()];
         in.read(bt);
         s = new String(bt);
         in.close();
      }
      catch(java.io.IOException e){
         s = null;
      }
      return s;
   }

// M�todo que inicializa a interface gr�fica
   public Exerc1() {
   // display = sa�da gr�fica
      Container display = getContentPane();
   // layout  = para plotar os objetos, o tipo � GridBag   
      GridBagLayout layout = new GridBagLayout();
   // medidas = para as medidas dos objetos
      GridBagConstraints medidas = new GridBagConstraints();
   // atribui as layout ao display
      display.setLayout(layout);
   // medidas ocupam o espa�o todo do layout
      medidas.fill = GridBagConstraints.BOTH;
      
   // Insere o painel superior com o bot�o que abre arquivos e o label com o
   // nome do arquivo   
      JPanel panU = new JPanel();
      panU.setLayout(new BorderLayout());
      panU.setBorder(BorderFactory.createTitledBorder("Arquivo de Origem"));
      panU.add("Center", arqNome);
      panU.add("East", btnAbrir);
      medidas.gridx = 0;
      medidas.gridy = 0;
      medidas.gridwidth = 2;
      medidas.gridheight = 1;
      medidas.weightx = 1.0;
      layout.setConstraints(panU, medidas);
      display.add(panU);

   // Insere o painel inferior com os bot�es de altera��o de g�nero / n�mero
      JPanel panD = new JPanel();
      panD.setLayout(new BoxLayout(panD, BoxLayout.X_AXIS));
      panD.setBorder(BorderFactory.createTitledBorder("Modificadores"));
      panD.add(btnGenero);
      panD.add(btnNumero);
      btnGenero.setEnabled(false);
      btnNumero.setEnabled(false);
      medidas.gridx = 0;
      medidas.gridy = 2;
      medidas.gridwidth = 2;
      medidas.gridheight = 1;
      medidas.weightx = 1.0;
      layout.setConstraints(panD, medidas);
      display.add(panD);

   // Insere o painel esquerdo com a caixa de texto lida do arquivo
      JPanel panL = new JPanel();
      panL.setLayout(new BorderLayout());
      panL.setBorder(BorderFactory.createTitledBorder("Texto Original"));
      txtOrig.setEditable(false);
      panL.add(txtOrig);
      medidas.gridx = 0;
      medidas.gridy = 1;
      medidas.gridwidth = 1;
      medidas.gridheight = 1;
      medidas.weightx = 0.5;
      medidas.weighty = 1.0;
      layout.setConstraints(panL, medidas);
      display.add(panL);

   // Insere o painel direito com a caixa de texto de sa�da
      JPanel panR = new JPanel();
      panR.setLayout(new BorderLayout());
      panR.setBorder(BorderFactory.createTitledBorder("Sa�da"));
      txtMod.setEditable(false);
      panR.add(txtMod);
      medidas.gridx = 1;
      medidas.gridy = 1;
      medidas.gridwidth = 1;
      medidas.gridheight = 1;
      medidas.weightx = 0.5;
      medidas.weighty = 1.0;
      layout.setConstraints(panR, medidas);
      display.add(panR);
      
   // Insere o label de status, no canto inferior da tela
      medidas.gridx = 0;
      medidas.gridy = 3;
      medidas.gridwidth = 2;
      medidas.gridheight = 1;
      medidas.weighty = 0.0;
      layout.setConstraints(status, medidas);
      display.add(status);  
  
   // Insere os manipuladores de eventos
      btnAbrir.addActionListener(this);
      btnGenero.addActionListener(this);
      btnNumero.addActionListener(this);
      addWindowListener(new WindowAdapter() {
         public void windowClosing(WindowEvent e) {
            System.exit(0);
         }
      });
   }
   
// M�todo que detecta as a��es
   public void actionPerformed(ActionEvent e) {

   // Quando clica no bot�o abrir
      if (e.getSource() == btnAbrir) {
         int abrir = fc.showOpenDialog(Exerc1.this); // Abre di�logo de arquivo

      // Se a abertura foi confirmada
         if (abrir == JFileChooser.APPROVE_OPTION) {
            btnGenero.setEnabled(false);
            btnNumero.setEnabled(false);
            File file = fc.getSelectedFile();
            textoSaida = new Texto(fileStream(file));
            txtOrig.setText(fileStream(file));

         // Se o arquivo gerou uma exce��o ou tem tamanho nulo            
            if (textoSaida.toString() == "") {
               arqNome.setText("(Nenhum documento aberto)");
               status.setText("Arquivo ''" + file.getName() + "'' n�o p�de " +
                              "ser aberto ou tem tamanho nulo.");
            }  

         // Se o arquivo p�de ser aberto
            else {
               arqNome.setText(file.getName());

            // Se o arquivo n�o segue a especifica��o do trabalho
               if (textoSaida.ehValido() == false) {
                  txtMod.setText("     O arquivo aberto n�o segue a especifi" +
                                 "ca��o do trabalho: h� ao menos uma frase " +
                                 "que n�o possui 5 palavras.\n\n" +
                                 "     As fun��es de altera��o de g�nero e " +
                                 "n�mero n�o ser�o habilitadas enquanto o " + 
                                 "arquivo n�o seguir a especifica��o.");
                  status.setText("Arquivo ''" + file.getName() + "'' aberto " +
                                 "� inv�lido.");
               }
               
            // Se tudo ocorrer bem!!   
               else {
                  status.setText("Arquivo ''" + file.getName() + "'' aberto " +
                                 "com sucesso.");
                  txtMod.setText(textoSaida.toString());
                  btnGenero.setEnabled(true);
                  btnNumero.setEnabled(true);
               }
            }
         }

      // Se o usu�rio cancelar...   
         else {
            status.setText("Abertura de arquivo cancelada pelo usu�rio.");
         }
      }
      
   // Quando clica no bot�o de alterar o g�nero
      else if (e.getSource() == btnGenero) {
         textoSaida.muda(true, false);
         status.setText("G�nero do texto de sa�da alterado.");
         txtMod.setText(textoSaida.toString());
      }

   // Quando clica no bot�o de alterar o n�mero
      else if (e.getSource() == btnNumero) {
         textoSaida.muda(false, true);
         status.setText("N�mero do texto de sa�da alterado.");
         txtMod.setText(textoSaida.toString());
      }
   }

// M�todo que inicializa a interface gr�fica
   public static void main(String args[]) {
   // Inicializa janela
      Exerc1 window = new Exerc1();
   // Pega valores do tamanho das margens da janela
      Insets insets = window.getInsets();
   // Define o t�tulo da janela   
      window.setTitle("Lista 7 - Heran�a e Swing em JAVA");
   // Gera o tamanho inicial da janela, que tem 600x450 de �rea �til
      window.setSize(600 + insets.left + insets.right, 450 + insets.top + insets.bottom);
   // Exibe a janela na tela   
      window.setVisible(true);
  }
}