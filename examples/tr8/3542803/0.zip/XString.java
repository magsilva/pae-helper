class XString {   
   static public String[] split(String s, char sep) {
      String retorno[];
      int num = 0;
      int iUltimo;
      int iAtual;
      int iProximo;

      if (s.indexOf(sep) == -1) {
      // Se n�o houver separadores, retorna "s" em um array unit�rio
         retorno = new String[1];
         retorno[0] = s;
      }

      else {         
      // Conta quantos "sep"s a string "s" tem   
         iUltimo = s.lastIndexOf(sep);
         iAtual = -1;
         while (iAtual != iUltimo) {
            num++;
            iAtual = s.indexOf(sep, iAtual + 1);
         }
      // Divide a string "s" em um array de strings
         retorno = new String[num + 1];
         iAtual = 0;
         iProximo = s.indexOf(sep);
         for (int i = 0; i < num; i++) {
            retorno[i] = s.substring(iAtual, iProximo);
            iAtual = iProximo + 1;
            iProximo = s.indexOf(sep, iProximo + 1);
         }
         retorno[num] = s.substring(iAtual);
      }

      return retorno;
   }
}