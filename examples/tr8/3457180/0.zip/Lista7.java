/*
Lista 7 de POO - 10/06/2003
Autor: Lucas Antiqueira, 3457180, lantiq@grad.icmc.usp.br
*/

import java.util.*;
import java.io.*;


//Classe que engloba as palavras de uma frase. Ela le uma frase completa
// e cria os respectivos objetos associados a cada classe, para posterior
// alteracao de genero e numero.
class Frase {
    private String[] palavras;
    private Palavra[] objetos = new Palavra[5];

    public Frase(String frase) {
        palavras = frase.split("\\s");

        if (palavras[0].compareTo("a") == 0 || palavras[0].compareTo("as") == 0 || palavras[0].compareTo("o") == 0 || palavras[0].compareTo("os") == 0)
            objetos[0] = new ArtigoDefinido(palavras[0]);
        else
            objetos[0] = new ArtigoIndefinido(palavras[0]);

        objetos[1] = new Substantivo(palavras[1]);

        if (palavras[2].endsWith("a") || palavras[2].endsWith("am"))
            objetos[2] = new PrimConjugacao(palavras[2]);
        else
            objetos[2] = new SegConjugacao(palavras[2]);

        if (palavras[3].compareTo("a") == 0 || palavras[3].compareTo("as") == 0 || palavras[3].compareTo("o") == 0 || palavras[3].compareTo("os") == 0)
            objetos[3] = new ArtigoDefinido(palavras[3]);
        else
            objetos[3] = new ArtigoIndefinido(palavras[3]);

        objetos[4] = new Substantivo(palavras[4]);
    }

    public void mudaGenero() {
        objetos[0].mudaGenero();
        objetos[1].mudaGenero();
        objetos[3].mudaGenero();
        objetos[4].mudaGenero();
    }

    public void mudaNumero() {
        objetos[0].mudaNumero();
        objetos[1].mudaNumero();
        objetos[2].mudaNumero();
        objetos[3].mudaNumero();
        objetos[4].mudaNumero();
    }

    public String retornaFrase() {
        return objetos[0].lePalavra() + " " + objetos[1].lePalavra() + " " + objetos[2].lePalavra() + " " + objetos[3].lePalavra() + " " + objetos[4].lePalavra();
    }
}


//Esta classe apresenta alguns metodos que serao refinados nas subclasses, como
// mudaGenero e mudaNumero (e o proprio construtor). O metodo lePalavra eh o mesmo
// para todas as subclasses.
class Palavra {
    protected String palavra;
    protected boolean fem, pl;

    Palavra (String p) {
        palavra = p;
    }

    public void mudaGenero () {
    	//implementado nas subclasses
    }

    public void mudaNumero () {
    	//implementado nas subclasses
    }

    public String lePalavra () {
        return palavra;
    }
}


//Usado na especializacao das classes para os artigos definidos e indefinicos
class Artigo extends Palavra {
    Artigo (String p) {
        super(p);
    }
}


//Especializa alguns dos metodos herdados da classe Palavra.
class ArtigoDefinido extends Artigo {

    ArtigoDefinido (String p) {
        super(p);
        if (p.compareTo("a") == 0) {
            fem = true;
            pl = false;
        } else if (p.compareTo("as") == 0) {
            fem = true;
            pl = true;
        } else if (p.compareTo("o") == 0) {
            fem = false;
            pl = false;
        } else if (p.compareTo("os") == 0) {
            fem = false;
            pl = true;
        }
    }

    public void mudaGenero () {
        if (fem) {
            fem = false;
            if (pl)
                palavra = "os";
            else
                palavra = "o";
        } else {
            fem = true;
            if (pl)
                palavra = "as";
            else
                palavra = "a";
        }
    }

    public void mudaNumero () {
        if (pl) {
            pl = false;
            if (fem)
                palavra = "a";
            else
                palavra = "o";
        } else {
            pl = true;
            if (fem)
                palavra = "as";
            else
                palavra = "os";
        }
    }
}


//Especializa alguns dos metodos herdados da classe Palavra.
class ArtigoIndefinido extends Artigo {

    ArtigoIndefinido (String p) {
        super(p);
        if (p.compareTo("uma") == 0) {
            fem = true;
            pl = false;
        } else if (p.compareTo("umas") == 0) {
            fem = true;
            pl = true;
        } else if (p.compareTo("um") == 0) {
            fem = false;
            pl = false;
        } else if (p.compareTo("uns") == 0) {
            fem = false;
            pl = true;
        }
    }

    public void mudaGenero () {
        if (fem) {
            fem = false;
            if (pl)
                palavra = "uns";
            else
                palavra = "um";
        } else {
            fem = true;
            if (pl)
                palavra = "umas";
            else
                palavra = "uma";
        }
    }

    public void mudaNumero () {
        if (pl) {
            pl = false;
            if (fem)
                palavra = "uma";
            else
                palavra = "um";
        } else {
            pl = true;
            if (fem)
                palavra = "umas";
            else
                palavra = "uns";
        }
    }
}


//Especializa alguns dos metodos herdados da classe Palavra.
class Substantivo extends Palavra {

    Substantivo (String p) {
        super(p);
        if (p.endsWith("a")) {
            fem = true;
            pl = false;
        } else if (p.endsWith("as")) {
            fem = true;
            pl = true;
        } else if (p.endsWith("o")) {
            fem = false;
            pl = false;
        } else if (p.endsWith("os")) {
            fem = false;
            pl = true;
        }
    }

    public void mudaGenero () {
        if (fem) {
            fem = false;
            if (palavra.endsWith("a"))
                palavra = palavra.substring(0, palavra.length()-1) + "o";
            else
                palavra = palavra.substring(0, palavra.length()-2) + "os";
        } else {
            fem = true;
            if (palavra.endsWith("o"))
                palavra = palavra.substring(0, palavra.length()-1) + "a";
            else
                palavra = palavra.substring(0, palavra.length()-2) + "as";
        }
    }

    public void mudaNumero () {
        if (pl) {
            pl = false;
            palavra = palavra.substring(0,palavra.length()-1);
        } else {
            pl = true;
            if (palavra.endsWith("o"))
                palavra = palavra.substring(0,palavra.length()-1) + "os";
            else
                palavra = palavra.substring(0,palavra.length()-1) + "as";
        }
    }
}


//Usado na especializacao das classes para os verbos
class Verbo extends Palavra {
    Verbo (String p) {
        super(p);
    }
}


//Especializa alguns dos metodos herdados da classe Palavra.
class PrimConjugacao extends Verbo {
    PrimConjugacao (String p) {
        super(p);
        if (p.endsWith("a"))
            pl = false;
        else if (p.endsWith("am"))
            pl = true;
    }

    public void mudaNumero () {
        if (pl) {
            pl = false;
            palavra = palavra.substring(0,palavra.length()-1);
        } else {
            pl = true;
            palavra += "m";
        }
    }
}


//Eh o mesmo para a terceira conjugacao (para os verbos usados neste exemplo)
class SegConjugacao extends Verbo {
    SegConjugacao (String p) {
        super(p);
        if (p.endsWith("e"))
            pl = false;
        else if (p.endsWith("em"))
            pl = true;
    }
    public void mudaNumero () {
        if (pl) {
            pl = false;
            palavra = palavra.substring(0,palavra.length()-1);
        } else {
            pl = true;
            palavra += "m";
        }
    }
}