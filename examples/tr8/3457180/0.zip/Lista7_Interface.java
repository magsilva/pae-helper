/*
Lista 7 de POO - 10/06/2003
Autor: Lucas Antiqueira, 3457180, lantiq@grad.icmc.usp.br
Obs.: Deve-se compilar antes o arquivo Lista7.java
*/

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;


//Nesta classe cria-se os componentes necessarios a aplicacao, e implementa-se
// uma classe da interface ActionListener
class TextApplication {
	
	JTextField textField = new JTextField("Arquivo em uso: <Nenhum>", 50);
	JButton buttonAbrir = new JButton("Abrir aquivo...");
	JCheckBox generoButton = new JCheckBox("Mudar g�nero");
	JCheckBox numeroButton = new JCheckBox("Mudar n�mero");
    JButton buttonAlterar = new JButton("Alterar texto");
    JTextArea textArea1 = new JTextArea(15,30);
    JTextArea textArea2 = new JTextArea(15,30);
    JPanel pane = new JPanel();
    JPanel pNorte1 = new JPanel();
    JPanel pNorte2 = new JPanel();
	JFileChooser chooser = new JFileChooser(new File("."));
	Listener buttonListener = new Listener();

	//Cria os componentes, e retorna-os
    public Component createComponents() {
    	
    	textField.setEditable(false);
    	
        buttonAbrir.setMnemonic(KeyEvent.VK_A);  //seta tecla de atalho
		buttonAbrir.addActionListener(buttonListener);

		generoButton.setMnemonic(KeyEvent.VK_G);
		generoButton.setSelected(false);

        numeroButton.setMnemonic(KeyEvent.VK_N);
        numeroButton.setSelected(false);

        buttonAlterar.setMnemonic(KeyEvent.VK_L);
		buttonAlterar.addActionListener(buttonListener);
		buttonAlterar.setEnabled(false);

		pane.setLayout(new BorderLayout());

		pNorte1.setLayout(new FlowLayout());
		pane.add(pNorte1, BorderLayout.NORTH);  //painel para a parte superior
		
		pNorte1.add(textField);
		pNorte1.add(buttonAbrir);

		pNorte2.setLayout(new FlowLayout());		
		pane.add(pNorte2, BorderLayout.SOUTH);  //painel para a parte inferior
		
		pNorte2.add(generoButton);
		pNorte2.add(numeroButton);
		pNorte2.add(buttonAlterar);

		//Cria uma area de texto, adicionando barras de rolagem atraves de JScrollPane
		textArea1.setEditable(false);
        textArea1.setLineWrap(true);
        JScrollPane areaScrollPane1 = new JScrollPane(textArea1);
        areaScrollPane1.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        areaScrollPane1.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createCompoundBorder(
                                BorderFactory.createTitledBorder("Texto do arquivo:"),
                                BorderFactory.createEmptyBorder(5,5,5,5)),
                areaScrollPane1.getBorder()));
		pane.add(areaScrollPane1, BorderLayout.WEST);

		//Cria outra area de texto
		textArea2.setEditable(false);
        textArea2.setLineWrap(true);
        JScrollPane areaScrollPane2 = new JScrollPane(textArea2);
        areaScrollPane2.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        areaScrollPane2.setBorder(
            BorderFactory.createCompoundBorder(
                BorderFactory.createCompoundBorder(
                                BorderFactory.createTitledBorder("Texto alterado:"),
                                BorderFactory.createEmptyBorder(5,5,5,5)),
                areaScrollPane2.getBorder()));
		pane.add(areaScrollPane2, BorderLayout.EAST);

        pane.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));

        return pane;
    }

	//Manipulador de eventos
    class Listener implements ActionListener {

	    public void actionPerformed(ActionEvent e) {

			//Abre um arquivo e adiciona seu conteudo em textArea1
			if (e.getSource() == buttonAbrir) {
				String line;
				BufferedReader file;
				File arq;
				int returnVal = chooser.showOpenDialog(null);

				if (returnVal == JFileChooser.APPROVE_OPTION) {
					arq = chooser.getSelectedFile();
					textField.setText("Arquivo em uso: " + chooser.getName(arq));
					try {
	        			file = new BufferedReader(new FileReader(arq.getName()));
		        		textArea1.setText("");
		        		line = file.readLine();
			        	while (line != null) {
							textArea1.append(line + "\n");
				            line = file.readLine();
						}
						file.close();
						buttonAlterar.setEnabled(true);
        			}
		        	catch (IOException er) {
						System.err.println("Erro na leitura do arquivo: " + er);
					}
				}
			//Altera o conteudo do arquivo aberto de acordo com as selecoes de numero e genero
			} else if (e.getSource() == buttonAlterar) {
				String[] frases = textArea1.getText().split("\\n");
				Frase f;
				textArea2.setText("");
				for (int i = 0; i < frases.length; i++) {
					f = new Frase(frases[i]);
					if (generoButton.isSelected())
						f.mudaGenero();
					if (numeroButton.isSelected())
						f.mudaNumero();
					textArea2.append(f.retornaFrase() + "\n");
				}
			}
	    }
	}
}

public class Lista7_Interface {
	public static void main(String[] args) {
		//Cria um frame, onde sao adicionados componentes provenientes
		// da implementacao da classe TextApplication
		JFrame frame = new JFrame("Mudan�a de g�nero e n�mero");
		TextApplication app = new TextApplication();
        Component contents = app.createComponents();

        frame.getContentPane().add(contents, BorderLayout.CENTER);

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.pack();
		frame.setVisible(true);
    }
}