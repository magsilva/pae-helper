import java.util.ArrayList;
import java.util.StringTokenizer;

public class Frase {
    String conteudo = new String();
    ArrayList listaDePalavras = new ArrayList();
    
    public Frase(String frase) {
        this.conteudo = frase;
        StringTokenizer listaTemp = new StringTokenizer(this.conteudo, " ");
        int i = 0;
        while (listaTemp.hasMoreTokens()) {
            String palavraTemp = new String(listaTemp.nextToken());
            switch(i) {
                case 0:
                    if ((palavraTemp.compareToIgnoreCase("os") == 0) || (palavraTemp.compareToIgnoreCase("o") == 0) 
                    || (palavraTemp.compareToIgnoreCase("as") == 0) || (palavraTemp.compareToIgnoreCase("a") == 0) )
                        listaDePalavras.add(new ArtigoDefinido(palavraTemp));
                    else
                        listaDePalavras.add(new ArtigoIndefinido(palavraTemp));
                    break;
                case 1:
                    listaDePalavras.add(new Substantivo(palavraTemp));
                    break;
                case 2:
                    if (palavraTemp.lastIndexOf('a') >= palavraTemp.length()-2) {
                        listaDePalavras.add(new VerboPrimeiraConjugacao(palavraTemp));
                    }
                    else if (palavraTemp.lastIndexOf('e') >= palavraTemp.length()-2)
                        listaDePalavras.add(new VerboSegundaConjugacao(palavraTemp));
                    else
                       listaDePalavras.add(new VerboTerceiraConjugacao(palavraTemp));
                    break;
                case 3:
                    if ((palavraTemp.compareToIgnoreCase("os") == 0) ||
                    (palavraTemp.compareToIgnoreCase("o") == 0) ||
                    (palavraTemp.compareToIgnoreCase("as") == 0) ||
                    (palavraTemp.compareToIgnoreCase("a") == 0))
                        listaDePalavras.add(new ArtigoDefinido(palavraTemp));
                    else
                        listaDePalavras.add(new ArtigoIndefinido(palavraTemp));
                        break;
                case 4:
                    listaDePalavras.add(new Substantivo(palavraTemp));
                    break;
            }
            i++;
        }
    }
    
    public void mudaGenero() {
        for (int i=0; i < this.listaDePalavras.size(); i++) {
            Palavra temp = (Palavra)this.listaDePalavras.get(i);
            temp.mudaGenero();
            this.listaDePalavras.set(i, temp);
        }
    }
    
    public void mudaNumero() {
        for (int i=0; i < this.listaDePalavras.size(); i++) {
            Palavra temp = (Palavra)this.listaDePalavras.get(i);
            temp.mudaNumero();
            this.listaDePalavras.set(i, temp);
        }
    }
    
    public String listaToString() {
        String string = new String();
        for (int i = 0; i < this.listaDePalavras.size(); i++) {
            Palavra temp = (Palavra)this.listaDePalavras.get(i);
            string += temp.conteudo.toString();
            string += " ";
        }
        return string;
    }
    
    public static void main(String args[]) {
        Frase teste = new Frase("Os ratos escondem uma ratas");
        teste.mudaGenero();
        System.out.println("Genero:" + teste.listaToString());
        teste.mudaNumero();
        System.out.println("Numero: " + teste.listaToString());
    }
}

class Palavra {
    
    /** Creates a new instance of Palavra */
    StringBuffer conteudo;
    public Palavra() {
        this.conteudo = new StringBuffer("");
    }
    public Palavra(String palavra) {
        this.conteudo = new StringBuffer(palavra);
    }
    
    public void mudaGenero() {
    }
    
    public void mudaNumero() {
    }
}

class Artigo extends Palavra {
    
    /** Creates a new instance of Artigo */
    public Artigo() {
        super();
    }
    public Artigo(String artigo) {
        super(artigo);
    }
}

class ArtigoDefinido extends Artigo {
    
    /** Creates a new instance of ArtigoDefinido */
    public ArtigoDefinido(String artigo) {
        super(artigo);
    }
    
    public void mudaGenero() {
        if (this.conteudo.indexOf("A") == 0)
            super.conteudo.setCharAt(0, 'O');
        else if (super.conteudo.indexOf("O") == 0)
            super.conteudo.setCharAt(0, 'A');
        else if (super.conteudo.indexOf("a") == 0)
            super.conteudo.setCharAt(0, 'o');
        else
            super.conteudo.setCharAt(0, 'a');
    }
    public void mudaNumero() {
        if (super.conteudo.indexOf("s") != -1) //os as
            super.conteudo.deleteCharAt(1);
        else
            super.conteudo.append("s");
    }  
}
class ArtigoIndefinido extends Artigo{
    
    /** Creates a new instance of ArtigoIndefinido */
   public ArtigoIndefinido(String artigo) {
        super(artigo);
    }
    public void mudaGenero() {
        if (super.conteudo.indexOf("n") >= 0) 
            super.conteudo.replace(1,3, "mas");
        else if (super.conteudo.indexOf("a") >= 0) {
            super.conteudo.deleteCharAt(2);
            if (super.conteudo.indexOf("s") >= 0)
                super.conteudo.setCharAt(1, 'n');
        }
        else
            super.conteudo.append('a');
    }
    public void mudaNumero() {
        if (super.conteudo.indexOf("s") == -1) {
            super.conteudo.append('s');
            if (super.conteudo.indexOf("a") == -1)
                super.conteudo.setCharAt(1, 'n');
        }    
        else {
            super.conteudo.deleteCharAt(super.conteudo.length()-1);
            if (super.conteudo.indexOf("n") >= 0)
                super.conteudo.setCharAt(1, 'm');
        }
    }  
}

class Substantivo extends Palavra {
    
    /** Creates a new instance of Substantivo */
   public Substantivo(String substantivo) {
        super.conteudo = new StringBuffer(substantivo);
    }
    public void mudaGenero(){
        if (super.conteudo.lastIndexOf("a") >= (super.conteudo.length() - 2) ) { //termina em a ou em as
            super.conteudo.setCharAt(super.conteudo.lastIndexOf("a"), 'o');
        }
        else
            super.conteudo.setCharAt(super.conteudo.lastIndexOf("o"), 'a');
    }
    
    public void mudaNumero() {
        if (super.conteudo.lastIndexOf("s") == super.conteudo.length() - 1) {
            super.conteudo.deleteCharAt(super.conteudo.lastIndexOf("s"));
        }
        else
            super.conteudo.append("s");
    }
    
}

class Verbo extends Palavra{
    
    /** Creates a new instance of Verbo */
    public Verbo() {
        super("");
    }
    
    public Verbo(String verbo) {
        super(verbo);
    }
    
    public void mudaGenero() {
        return;
    }
      
}

class VerboPrimeiraConjugacao extends Verbo{
    
    /** Creates a new instance of VerboPrimeiraConjugacao */
    public VerboPrimeiraConjugacao(String verbo) {
        super(verbo);
    }
    
    public void mudaNumero() {
        if (super.conteudo.indexOf("m") == super.conteudo.length()-1) {
            super.conteudo.deleteCharAt(super.conteudo.length()-1);
        }
        else
            super.conteudo.append('m');
    }
     
}

class VerboSegundaConjugacao extends Verbo{
    
    /** Creates a new instance of VerboSegundaConjugacao */
    public VerboSegundaConjugacao(String verbo) {
        super(verbo);
    }
    
    public void mudaNumero() {
        if (super.conteudo.indexOf("m") == super.conteudo.length()-1) {
            super.conteudo.deleteCharAt(super.conteudo.length()-1);
        }
        else
            super.conteudo.append('m');
    } 
}

class VerboTerceiraConjugacao extends Verbo {
    
    /** Creates a new instance of VerboTerceiraConjugacao */
    public VerboTerceiraConjugacao(String verbo) {
        super(verbo);
    }
    
    public void mudaNumero() {
        if (super.conteudo.indexOf("m") == super.conteudo.length()-1) {
            super.conteudo.deleteCharAt(super.conteudo.length()-1);
        }
        else
            super.conteudo.append('m');
    }
}