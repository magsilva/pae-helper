/*
 * InterfaceGrafic.java
 *
 * Created on June 11, 2003, 1:03 AM
 */

/**
 *
 * @author  3457749
 */

import javax.swing.*;
import java.io.*;

import java.util.ArrayList;
import java.util.StringTokenizer;

class Frase {
    String conteudo = new String();
    ArrayList listaDePalavras = new ArrayList();
    
    public Frase(String frase) {
        this.conteudo = frase;
        StringTokenizer listaTemp = new StringTokenizer(this.conteudo, " ");
        int i = 0;
        while (listaTemp.hasMoreTokens()) {
            String palavraTemp = new String(listaTemp.nextToken());
            switch(i) {
                case 0:
                    if ((palavraTemp.compareToIgnoreCase("os") == 0) || (palavraTemp.compareToIgnoreCase("o") == 0) 
                    || (palavraTemp.compareToIgnoreCase("as") == 0) || (palavraTemp.compareToIgnoreCase("a") == 0) )
                        listaDePalavras.add(new ArtigoDefinido(palavraTemp));
                    else
                        listaDePalavras.add(new ArtigoIndefinido(palavraTemp));
                    break;
                case 1:
                    listaDePalavras.add(new Substantivo(palavraTemp));
                    break;
                case 2:
                    if (palavraTemp.lastIndexOf('a') >= palavraTemp.length()-2) {
                        listaDePalavras.add(new VerboPrimeiraConjugacao(palavraTemp));
                    }
                    else if (palavraTemp.lastIndexOf('e') >= palavraTemp.length()-2)
                        listaDePalavras.add(new VerboSegundaConjugacao(palavraTemp));
                    else
                       listaDePalavras.add(new VerboTerceiraConjugacao(palavraTemp));
                    break;
                case 3:
                    if ((palavraTemp.compareToIgnoreCase("os") == 0) ||
                    (palavraTemp.compareToIgnoreCase("o") == 0) ||
                    (palavraTemp.compareToIgnoreCase("as") == 0) ||
                    (palavraTemp.compareToIgnoreCase("a") == 0))
                        listaDePalavras.add(new ArtigoDefinido(palavraTemp));
                    else
                        listaDePalavras.add(new ArtigoIndefinido(palavraTemp));
                        break;
                case 4:
                    listaDePalavras.add(new Substantivo(palavraTemp));
                    break;
            }
            i++;
        }
    }
    
    public void mudaGenero() {
        for (int i=0; i < this.listaDePalavras.size(); i++) {
            Palavra temp = (Palavra)this.listaDePalavras.get(i);
            temp.mudaGenero();
            this.listaDePalavras.set(i, temp);
        }
    }
    
    public void mudaNumero() {
        for (int i=0; i < this.listaDePalavras.size(); i++) {
            Palavra temp = (Palavra)this.listaDePalavras.get(i);
            temp.mudaNumero();
            this.listaDePalavras.set(i, temp);
        }
    }
    
    public String listaToString() {
        String string = new String();
        for (int i = 0; i < this.listaDePalavras.size(); i++) {
            Palavra temp = (Palavra)this.listaDePalavras.get(i);
            string += temp.conteudo.toString();
            string += " ";
        }
        return string;
    }   
}

class Palavra {
    
    /** Creates a new instance of Palavra */
    StringBuffer conteudo;
    public Palavra() {
        this.conteudo = new StringBuffer("");
    }
    public Palavra(String palavra) {
        this.conteudo = new StringBuffer(palavra);
    }
    
    public void mudaGenero() {
    }
    
    public void mudaNumero() {
    }
}

class Artigo extends Palavra {
    
    /** Creates a new instance of Artigo */
    public Artigo() {
        super();
    }
    public Artigo(String artigo) {
        super(artigo);
    }
}

class ArtigoDefinido extends Artigo {
    
    /** Creates a new instance of ArtigoDefinido */
    public ArtigoDefinido(String artigo) {
        super(artigo);
    }
    
    public void mudaGenero() {
        if (this.conteudo.indexOf("A") == 0)
            super.conteudo.setCharAt(0, 'O');
        else if (super.conteudo.indexOf("O") == 0)
            super.conteudo.setCharAt(0, 'A');
        else if (super.conteudo.indexOf("a") == 0)
            super.conteudo.setCharAt(0, 'o');
        else
            super.conteudo.setCharAt(0, 'a');
    }
    public void mudaNumero() {
        if (super.conteudo.indexOf("s") != -1) //os as
            super.conteudo.deleteCharAt(1);
        else
            super.conteudo.append("s");
    }  
}
class ArtigoIndefinido extends Artigo{
    
    /** Creates a new instance of ArtigoIndefinido */
   public ArtigoIndefinido(String artigo) {
        super(artigo);
    }
    public void mudaGenero() {
        if (super.conteudo.indexOf("n") >= 0) 
            super.conteudo.replace(1,3, "mas");
        else if (super.conteudo.indexOf("a") >= 0) {
            super.conteudo.deleteCharAt(2);
            if (super.conteudo.indexOf("s") >= 0)
                super.conteudo.setCharAt(1, 'n');
        }
        else
            super.conteudo.append('a');
    }
    public void mudaNumero() {
        if (super.conteudo.indexOf("s") == -1) {
            super.conteudo.append('s');
            if (super.conteudo.indexOf("a") == -1)
                super.conteudo.setCharAt(1, 'n');
        }    
        else {
            super.conteudo.deleteCharAt(super.conteudo.length()-1);
            if (super.conteudo.indexOf("n") >= 0)
                super.conteudo.setCharAt(1, 'm');
        }
    }  
}

class Substantivo extends Palavra {
    
    /** Creates a new instance of Substantivo */
   public Substantivo(String substantivo) {
        super.conteudo = new StringBuffer(substantivo);
    }
    public void mudaGenero(){
        if (super.conteudo.lastIndexOf("a") >= (super.conteudo.length() - 2) ) { //termina em a ou em as
            super.conteudo.setCharAt(super.conteudo.lastIndexOf("a"), 'o');
        }
        else
            super.conteudo.setCharAt(super.conteudo.lastIndexOf("o"), 'a');
    }
    
    public void mudaNumero() {
        if (super.conteudo.lastIndexOf("s") == super.conteudo.length() - 1) {
            super.conteudo.deleteCharAt(super.conteudo.lastIndexOf("s"));
        }
        else
            super.conteudo.append("s");
    }
    
}

class Verbo extends Palavra{
    
    /** Creates a new instance of Verbo */
    public Verbo() {
        super("");
    }
    
    public Verbo(String verbo) {
        super(verbo);
    }
    
    public void mudaGenero() {
        return;
    }
      
}

class VerboPrimeiraConjugacao extends Verbo{
    
    /** Creates a new instance of VerboPrimeiraConjugacao */
    public VerboPrimeiraConjugacao(String verbo) {
        super(verbo);
    }
    
    public void mudaNumero() {
        if (super.conteudo.indexOf("m") == super.conteudo.length()-1) {
            super.conteudo.deleteCharAt(super.conteudo.length()-1);
        }
        else
            super.conteudo.append('m');
    }
     
}

class VerboSegundaConjugacao extends Verbo{
    
    /** Creates a new instance of VerboSegundaConjugacao */
    public VerboSegundaConjugacao(String verbo) {
        super(verbo);
    }
    
    public void mudaNumero() {
        if (super.conteudo.indexOf("m") == super.conteudo.length()-1) {
            super.conteudo.deleteCharAt(super.conteudo.length()-1);
        }
        else
            super.conteudo.append('m');
    } 
}

class VerboTerceiraConjugacao extends Verbo {
    
    /** Creates a new instance of VerboTerceiraConjugacao */
    public VerboTerceiraConjugacao(String verbo) {
        super(verbo);
    }
    
    public void mudaNumero() {
        if (super.conteudo.indexOf("m") == super.conteudo.length()-1) {
            super.conteudo.deleteCharAt(super.conteudo.length()-1);
        }
        else
            super.conteudo.append('m');
    }
}

public class InterfaceGrafic extends java.awt.Frame {
    
    /** Creates new form InterfaceGrafic */
    public InterfaceGrafic() {
        initComponents();
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    private void initComponents() {//GEN-BEGIN:initComponents
        jFileChooser1 = new javax.swing.JFileChooser();
        jPanel1 = new javax.swing.JPanel();
        jTextArea1 = new javax.swing.JTextArea();
        jTextArea2 = new javax.swing.JTextArea();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        botaoNumero = new javax.swing.JCheckBox();
        botaoGenero = new javax.swing.JCheckBox();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();

        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                exitForm(evt);
            }
        });

        jPanel1.setLayout(null);

        jPanel1.add(jTextArea1);
        jTextArea1.setBounds(10, 190, 500, 120);

        jPanel1.add(jTextArea2);
        jTextArea2.setBounds(10, 40, 500, 120);

        jLabel1.setText("Frases originais");
        jPanel1.add(jLabel1);
        jLabel1.setBounds(10, 20, 120, 16);

        jLabel2.setText("Frases alteradas");
        jPanel1.add(jLabel2);
        jLabel2.setBounds(10, 170, 100, 16);

        jButton1.setText("Altera");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        jPanel1.add(jButton1);
        jButton1.setBounds(550, 40, 68, 26);

        botaoNumero.setText("N\u00famero");
        jPanel1.add(botaoNumero);
        botaoNumero.setBounds(550, 80, 93, 24);

        botaoGenero.setText("G\u00eanero");
        jPanel1.add(botaoGenero);
        botaoGenero.setBounds(550, 120, 66, 24);

        jButton2.setText("Abrir");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });

        jPanel1.add(jButton2);
        jButton2.setBounds(550, 160, 62, 26);

        jButton3.setText("Sair");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });

        jPanel1.add(jButton3);
        jButton3.setBounds(550, 200, 57, 26);

        add(jPanel1, java.awt.BorderLayout.CENTER);

        pack();
    }//GEN-END:initComponents

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // Add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_jButton3ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        // Add your handling code here:
        BufferedReader arq;
        String linha;
        int valorDeRetorno = jFileChooser1.showOpenDialog(jPanel1);
        if (valorDeRetorno == jFileChooser1.APPROVE_OPTION) //sele�ao do arquivo bem sucedida
        {
            File arquivo = jFileChooser1.getSelectedFile();
            try {
                jTextArea1.setText("");
            arq = new BufferedReader(new FileReader(arquivo.getAbsoluteFile()));
            linha = arq.readLine();
            while (linha != null) {
                jTextArea1.append(linha + '\n');
                linha = arq.readLine();
            }
            }
            catch (IOException erro) {
                System.err.println("Erro na abertura do arquivo.");
            }
        }       
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // Add your handling code here:
                String[] listaDeFrases = jTextArea1.getText().split("\\n");
        Frase nossaFrase;
        jTextArea2.setText("");
        for (int i=0; i<listaDeFrases.length; i++) {
            nossaFrase = new Frase (listaDeFrases[i]);
            if (botaoNumero.isSelected())
                nossaFrase.mudaNumero();
            if (botaoGenero.isSelected())
                nossaFrase.mudaGenero();
            jTextArea2.append(nossaFrase.listaToString() + '\n');
        }
    }//GEN-LAST:event_jButton1ActionPerformed
    
    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_exitForm
        System.exit(0);
    }//GEN-LAST:event_exitForm
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        new InterfaceGrafic().show();
    }
    
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton2;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JCheckBox botaoNumero;
    private javax.swing.JCheckBox botaoGenero;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton3;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JFileChooser jFileChooser1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
    
}
