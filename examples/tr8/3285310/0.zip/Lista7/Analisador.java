/*
	Lista 7 de Poo
	Aluno:
				Rafael Henrique Manoel			3285310

*/

import java.awt.*;
import java.awt.event.*;
import java.io.*;

import javax.swing.*;

public class Analisador extends JFrame implements ActionListener{
	//Classes proprias
	Frase [] listaFrases;					//array para as frases
	int numFrases;							//numero de frases
	
	//objetos gui para a interface
	Container container;					//container da aplicacao
	JLabel label1, label2, label3;			// labels
	JTextArea textoOriginal, 
			  textoModificado;				// �reas de texto
	JScrollPane spOriginal,
				spModificado;				// scrolls
	JButton btnAbrir;						// bot�o para abrir o arquivo
	JTextField nomeArq;	  					// nome do arquivo
	JPanel panelOriginal, panelModificado,
		   panelTop, panelCheck;			//panels
	JCheckBox cbGenero, cbNumero;			//checkboxs para alterar genero e numero 
		   

	//construtor padr�o
	public Analisador(){
		super("Analisador de Frases");		//chamando o construtor da classe pai
		
		/*
		 * criando os objetos gui
		 */
		label1 = new JLabel("Texto original");				//label
		label2 = new JLabel("Texto modificado");			//label
		btnAbrir = new JButton("Abrir");					//botao para abrir arquivo
		nomeArq = new JTextField(15);						//caixa de texto com o nome do arquivo
		textoOriginal = new JTextArea(6,20);				//Area de texto para o texto original
		spOriginal = new JScrollPane(textoOriginal);		//Barra de Rolagem
		textoModificado = new JTextArea(6,20);				//Area de texto para o texto modificado
		spModificado = new JScrollPane(textoModificado);	//Barra de rolagem
		cbGenero = new JCheckBox("Genero");					//CheckBox para alterar genero
		cbNumero = new JCheckBox("N�mero");					//CheckBox para alterar n�mero
		
		panelOriginal = new JPanel();						//Panel 
		panelModificado = new JPanel();						//Panel
		panelTop = new JPanel();							//Panel
		panelCheck = new JPanel();							//Panel
		
		
		
		btnAbrir.addActionListener(this);	//"ouvindo" no botao 
		cbGenero.addActionListener(this);	//
		cbNumero.addActionListener(this);	//"ouvindo nos checkboxs
		
		container = this.getContentPane();	//obtendo o painel principal
		
		/*
		 * adicionando os componentes aos pain�is
		 */
		panelOriginal.setLayout(new FlowLayout());
		panelOriginal.add(label1);
		panelOriginal.add(spOriginal);
		
		panelModificado.setLayout(new FlowLayout());
		panelModificado.add(label2);
		panelModificado.add(spModificado);
		
		panelTop.setLayout(new FlowLayout());
		panelTop.add(nomeArq);
		panelTop.add(btnAbrir);
		
		panelCheck.setLayout(new FlowLayout());
		panelCheck.add(cbGenero);
		panelCheck.add(cbNumero);
		
		
		
		/*
		 * Adicionado tudo ao container
		 */ 
		container.setLayout(new GridLayout(2,2,2,2));
		
		container.add(panelOriginal);
		container.add(panelModificado);
		container.add(panelTop);
		container.add(panelCheck);
		
		this.setSize(500,200);
		this.setLocation(200,100);
		this.show();					//exibindo a janela
				
		
	}

	//metodo da interface 
	public void actionPerformed(ActionEvent e){
		int i;
		
		if (e.getSource() == btnAbrir) 
			abrirArquivo();
		else if (e.getSource() == cbGenero)
		{
			//alterar genero
			textoModificado.setText("");
			for (i=0; i<this.numFrases; i++){
				listaFrases[i].alterarGenero();
				textoModificado.append(listaFrases[i].toString() + "\n");
			}

		}
		else if (e.getSource() == cbNumero){
			//alterar n�mero
			textoModificado.setText("");
			for (i=0; i<this.numFrases; i++){
				listaFrases[i].alterarNumero();
				textoModificado.append(listaFrases[i].toString() + "\n");
			}
			
		}

	}//fim actionPerformed
	
	// m�todo para abrir o arquivo
	public void abrirArquivo(){
		JFileChooser filechooser;				// dialogo para abrir arquivos
		File arq;
		FileReader filereader; 
		BufferedReader input;
		StringBuffer buffer;
		Frase frase1;
		int numLinhas=0;						//n�mero de linhas
		
		filechooser = new JFileChooser();
		filechooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
		
		int result = filechooser.showOpenDialog(this);
		
		//se cancel, sai
		if (result == JFileChooser.CANCEL_OPTION)
			return;
		
		//okay
		arq = filechooser.getSelectedFile();
		
		//se arquivo for nulo ou em branco, exibir erro
		if (arq == null || arq.getName().equals("") )
			JOptionPane.showMessageDialog(this,"Erro","Arquivo inv�lido",JOptionPane.ERROR_MESSAGE);
		else {
			//abre o arquivo
			try	{
				
				filereader = new FileReader(arq);
				input = new BufferedReader(filereader);
				nomeArq.setText(arq.getName().toString());
				
				buffer = new StringBuffer();
				String linha = new String();

				
				//lendo o arquivo e adicionando linha por linha
				//em uma stringbuffer
				while ( (linha = input.readLine()) != null) {
					buffer.append(linha + "\n");
					numLinhas ++;
				}
				
				this.numFrases = numLinhas;
				
				//imprimindo o arquivo na area de texto apropriada
				textoOriginal.setText(buffer.toString());
				
				
				//variaveis auxiliares para passar o texto do 
				//stringbuffer para a lista de frases
				
				int i;
				int inicio, fim;
				
				inicio=0;
				
				listaFrases = new Frase[numLinhas];

				for (i=0; i< numLinhas; i++){
					
					fim = buffer.toString().indexOf('\n', inicio);
					if (fim == -1)
						fim = buffer.toString().length();
					
					//System.err.println("Entre [" + inicio + ","+fim+"]");
					linha = new String(buffer.toString().substring(inicio, fim));			
					listaFrases[i] = new Frase(linha);
					listaFrases[i].quebrarEmPalavras();
					inicio = fim + 1;
				}	
							 
				
				 
			}
			catch (IOException ioException) {
				JOptionPane.showMessageDialog(this,"Erro ao abrir o arquivo", "Erro", JOptionPane.ERROR_MESSAGE);
			}
				
		}// fim else
		
		
	}//fim abrirArquivo
	
	
	// fun��o principal
	public static void main(String[] args){
		
		Analisador App = new Analisador();
		App.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}// fim main
	
}// fim classe Analisador

/*
 * Classe para a manipula��o de frases. 
 */
 
class Frase{
	String texto;
	
	Artigo artigo1, artigo2;					// artigos da frase
	Substantivo substantivo1, substantivo2;		// Substantivos da Frase
	Verbo verbo;								// Verbo da frase
	
	int nPalavras;
	
	/*
	 * construtor da classe
	 */
	Frase(String frase){
		this.texto = new String(frase);
		contarPalavras();
	}// fim construtor

	/*
	 * Fun��o para contar o numero de palavras da frase
	 */
	private void contarPalavras() {
		int i, nEspacos=0;
			
		// la�o para contar o numero de espa�os em brancos
		for (i=0; i<texto.length(); i++){
			if (texto.charAt(i) == (char)32)
				nEspacos++;
		
		//numero de espa�os + 1 = numero de palavras
		this.nPalavras = nEspacos + 1;	
		}// fim for
	}//fim contar palavras
		
	/*
	 * Fun��o que retorna o numero de palavras
	 */
	public int getNumeroPalavras(){
		return this.nPalavras;
	}// fim getNumeroPalavras
	
	/*
	 *	Fun��o que divide a frase em palavras 
	 */
	public void quebrarEmPalavras(){
		int inicio=0,
			fim;
		
		//atribuindo o primeiro artigo
		fim = texto.indexOf((char)32, inicio);
		char primeiro = texto.charAt(0);
		System.err.println("primeiro = " + primeiro);
		if (primeiro == 'a' || primeiro == 'o')
			artigo1 = new ArtigoDef(texto.substring(inicio, fim));
		else
			artigo1 = new ArtigoIndef(texto.substring(inicio, fim));
			
		inicio = fim + 1;
		//atribuindo o primeiro substantivo
		fim = texto.indexOf((char)32, inicio);
		substantivo1 = new Substantivo(texto.substring(inicio, fim));
		inicio = fim + 1;
		//atribuindo o verbo
		fim = texto.indexOf((char)32, inicio);
		verbo = new Verbo(texto.substring(inicio, fim));
		inicio = fim + 1;
		
		//atribuindo o segundo artigo
		fim = texto.indexOf((char)32, inicio);
		primeiro = texto.charAt(inicio);
		if (primeiro == 'a' || primeiro == 'o')
			artigo2 = new ArtigoDef(texto.substring(inicio, fim));
		else
			artigo2 = new ArtigoIndef(texto.substring(inicio, fim));
		inicio = fim + 1;
		
		
		//atribuindo o segundo substantivo
		substantivo2 = new Substantivo(texto.substring(inicio, texto.length()));		

		
	}// fim quebrarEmPalavras
	
	/*
	 * Fun��o para alterar o genero da frase e retornar a frase alterada
	 */
	public void alterarGenero(){
		
		// alterando o genero de palavra por palavra
		artigo1.alterarGenero();
		substantivo1.alterarGenero();
		artigo2.alterarGenero();
		substantivo2.alterarGenero();
		
	}// fim alterarGenero

	/*
	 * Fun��o para alterar o n�mero da frase
	 */
	public void alterarNumero(){
		
		//alterando o numero de palavra por palavra
		artigo1.alterarNumero();
		substantivo1.alterarNumero();
		verbo.alterarNumero();
		artigo2.alterarNumero();
		substantivo2.alterarNumero();
	
	}// fim alterarNumero
	
	public String toString(){
		return artigo1.toString() + " " + substantivo1.toString() + " " + verbo.toString() + " " + artigo2.toString() + " " + substantivo2.toString();
	}


}// fim da classe frase


//-----------------------------------------------------------------------------

/*
 * Classe para a manipula��o de Palavras
 */
 class Substantivo{
 	private String texto;
 	
 	/*
 	 * Construtor Padr�o
 	 */
 	Substantivo(String palavra){
 		this.texto = new String(palavra);
 		
 	}// fim construtor
 	
 	/*
 	 * Devolve o tamanho da palavra
 	 */
 	public int getSize(){
 		return texto.length();
 	}// fim getSize
 	
 	
 	/*
 	 * Fun��o para setar o texto
 	 */
 	public void setTexto(String palavra){
 		this.texto = palavra;
 	}// fim setTexto
 	
 	/*
 	 * Fun��o que troca o genero do substantivo
	*/
	public void alterarGenero(){
		char ultimaLetra;
		int tamanho = this.texto.length();
		
		ultimaLetra = this.texto.charAt(tamanho-1);
		
		//trocando o genero do substantivo
		
		if (ultimaLetra == 's'){
			ultimaLetra = this.texto.charAt(tamanho-2);
			if (ultimaLetra == 'a')
				texto = texto.substring(0,tamanho-2) + "os";
			else
				texto = texto.substring(0,tamanho-2) + "as";
		}
		else 	
			if (ultimaLetra == 'a')				
				texto = texto.substring(0,tamanho-1) + "o";

			else {
				
				texto = texto.substring(0,tamanho-1) + "a";
			}	
	}//fim alterarGenero
 	
 	
 	/*
 	 * Funcao que retorna o objeto como string
 	 */
 	public String toString(){
 		return this.texto;
 	} // fim getString
 	
 	/*
 	 * Fun��o que altera o n�mero do substantivo
 	 */
 	public void alterarNumero(){
 		char ultimaLetra;
 		int tamanho = texto.length();
 		
 		//pegando o ultimo caracter da palavra
 		ultimaLetra = texto.charAt(tamanho-1);
 		
 		if (ultimaLetra == 's')
 			//elimina a letra S
 			texto = texto.substring(0, tamanho-1);
 		else
 			//adiciona a letra S
 			texto += "s";
 	}// fim alterarNumero
 	
 }
 	
 	
//-----------------------------------------------------------------------------

/*
 * Classes derivadas da classe palavra
 */ 	
	
class Verbo extends Substantivo{
	
	/*
	 * Construtor
	 */
	Verbo(String palavra){
		super(palavra);
	}// fim construtor
	
	/*
	 * Funcao que altera o genero do verbo
	 */
	public void alterarGenero(){
		//nao faz nada. Verbo nao tem genero
	}// fim alterarGenero
	
	/*
	 * Funcao para alterar o numero do verbo
	 */
	public void alterarNumero(){
		int tamanho = getSize();
		char ultimaLetra = toString().charAt(tamanho-1);
		
		if (ultimaLetra == 'm')
			setTexto(this.toString().substring(0,tamanho-1));
		else
			setTexto(this.toString().substring(0,tamanho) + 'm');
		
	}//fim alterarNumero
	
}//fim classe Verbo


/*
 * Interface para Artigo
 */
class Artigo extends Substantivo {
	
	Artigo(String palavra){
		super(palavra);
	}
	
	public void alterarGenero(){}
	public void alterarNumero(){
		super.alterarNumero();	
	}
	
}//fim classe Artigo


/*
 * Classe para tratamento de Artigos definidos
 */
class ArtigoDef extends Artigo {

	/*
	 * Construtor
	 */
	ArtigoDef(String palavra){
		super(palavra);
	}//fim construtor
	
	/*
	 * Altera o genero do artigo definido
	 */
	public void alterarGenero(){
		char primeiraLetra = toString().charAt(0);

		char def;
		
		if (primeiraLetra == 'a')
			//art = new String("o");
			def = 'o';
		else
			//art = new String("a");
			def = 'a';
		
		//alterando o texto
		setTexto(def + this.toString().substring(1,getSize()));
		
	}//fim alterarGenero
	
	/*
	 * Altera o numero do artigo
	 */
	//m�todo da classe substantivo q foi herdado para a classe Artigo
	 
}//fim classe ArtigoDef




/*
 * Classe para tratamento de Artigos definidos
 */
class ArtigoIndef extends Artigo {

	/*
	 * Construtor
	 */
	ArtigoIndef(String palavra){
		super(palavra);
	}//fim construtor
	
	/*
	 * Altera o genero do artigo definido
	 */
	public void alterarGenero(){
		int tamanho = getSize();
		char ultimaLetra = toString().charAt(tamanho-1);
		String art;
		
		if (ultimaLetra == 's')
			if ( toString().charAt(tamanho-2) == 'a' )
				setTexto(toString().substring(0,1) + "ns");
			else
				setTexto(toString().substring(0,1) + "mas");		
		else
			if (ultimaLetra == 'a')
				setTexto(toString().substring(0,tamanho-1));
			else
				setTexto(toString() + "a");
		
	}//fim alterarGenero
	
	/*
	 * Altera o numero do artigo
	 */
	public void alterarNumero(){
		int tamanho = getSize();
		char ultimaLetra = toString().charAt(tamanho-1);
		
		if (ultimaLetra == 's')
			setTexto(toString().substring(0, tamanho-2) + "m");
		else
			setTexto(toString().substring(0,1)+ "ns");
	}//fim alterarNumero

}//fim classe ArtigoIndef
	