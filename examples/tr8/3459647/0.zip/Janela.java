/* SCE-213 -- Programa��o Orientada a Objetos
   Profa. Renata Pontin
   Lista de Exerc�cios 7 - Java
   
   Alunos: F�bio Rodrigues Alves Margarido - 3459647
   		   Lucas Shindi Shimo - 3529892

*/

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;


// classe que separa a frase a ser alterada em palavras e realiza as altera��es corretamente de acordo com a 
// classe de cada palavra
class Frase {

	public String frase;
	public String[] palavras;

	public Frase(String arg) {

		frase = arg;
		palavras = frase.split("\\s");
	}

	// fun��o para alterar o g�nero da frase
	String genero() {
		Artigo art1 = new Artigo(palavras[0]);
		Artigo art2 = new Artigo(palavras[3]);
		Substantivo sub1 = new Substantivo(palavras[1]);
		Substantivo sub2 = new Substantivo(palavras[4]);
		Verbo verbo = new Verbo(palavras[2]);
		
		return (art1.altera_genero()+" " + sub1.altera_genero()+ " " + palavras[2] + " "+art2.altera_genero()+ " " + sub2.altera_genero());
	}
	
	// fun��o para alterar o n�mero da frase
	String numero() {
		Artigo art1 = new Artigo(palavras[0]);
		Artigo art2 = new Artigo(palavras[3]);
		Substantivo sub1 = new Substantivo(palavras[1]);
		Substantivo sub2 = new Substantivo(palavras[4]);
		Verbo verbo = new Verbo(palavras[2]);
		
		return (art1.altera_numero()+ " " + sub1.altera_numero()+ " " + verbo.altera_numero()+ " " + art2.altera_numero()+ " " + sub2.altera_numero());
	}

}


// classe que representa os substantivos e implementa as modifica��es de g�nero e n�mero corretamente para eles
class Substantivo {

	public String arg;
	public String novosubgen;
	public String novosubnum;
	
	public Substantivo(String sub) {
		arg = sub;
	}

	String altera_genero() {
		
		if (arg.endsWith("o"))
			novosubgen =  arg.substring(0,arg.length()-1).concat("a");
		else if (arg.endsWith("a"))
			novosubgen = arg.substring(0,arg.length()-1).concat("o");
		else if (arg.endsWith("os"))
				novosubgen = arg.substring(0,arg.length()-2).concat("as");
		else if (arg.endsWith("as"))
				novosubgen = arg.substring(0,arg.length()-2).concat("os");
		return novosubgen;
	}
	
	String altera_numero() {
		
		if (arg.endsWith("o"))
			novosubnum =  arg.substring(0,arg.length()-1).concat("os");
		else if (arg.endsWith("a"))
			novosubnum = arg.substring(0,arg.length()-1).concat("as");
		else if (arg.endsWith("s"))
				novosubnum = arg.substring(0,arg.length()-1);
		return novosubnum;
	}
}


// classe que representa os verbos e implementa a altera��o de n�mero corretamente para eles
class Verbo {
	
	public String arg;
	public String novoverbo;
	
	public Verbo(String verbo) {
		arg = verbo;
	}
	
	String altera_numero() {
		if ((arg.endsWith("e")) || (arg.endsWith("a")))
			novoverbo = arg.concat("m");
		else if (arg.endsWith("i"))
			novoverbo = arg.substring(0,arg.length()-1).concat("em");
		else if (arg.endsWith("m"))
			novoverbo = arg.substring(0, arg.length()-1);
		return novoverbo;
	}
}

// classe que representa os artigos e implementa as altera��es de g�nero e n�mero corretamente para eles
class Artigo {
	
	public String arg;
	public String novoartgen;
	public String novoartnum;
	
	public Artigo(String artigo) {
		arg = artigo;
	}
	
	String altera_genero() {
		if ((arg.equals("O")) || (arg.equals("o"))) novoartgen= "a";
		else if ((arg.equals("A")) || (arg.equals("a"))) novoartgen = "o";
		else if ((arg.equals("Os")) || (arg.equals("os"))) novoartgen = "as";
		else if ((arg.equals("As")) || (arg.equals("as"))) novoartgen = "os";
		else if ((arg.equals("Um")) || (arg.equals("um"))) novoartgen = "uma";
		else if ((arg.equals("Uma")) || (arg.equals("uma"))) novoartgen = "um";
		else if ((arg.equals("Uns")) || (arg.equals("uns"))) novoartgen = "umas";
		else if ((arg.equals("Umas")) || (arg.equals("umas"))) novoartgen = "uns";
		return novoartgen;
	}
	
	String altera_numero() {
		if ((arg.equals("O")) || (arg.equals("o"))) novoartnum= "os";
		else if ((arg.equals("A")) || (arg.equals("a"))) novoartnum = "as";
		else if ((arg.equals("Os")) || (arg.equals("os"))) novoartnum = "o";
		else if ((arg.equals("As")) || (arg.equals("as"))) novoartnum = "a";
		else if ((arg.equals("Um")) || (arg.equals("um"))) novoartnum = "uns";
		else if ((arg.equals("Uma")) || (arg.equals("uma"))) novoartnum = "umas";
		else if ((arg.equals("Uns")) || (arg.equals("uns"))) novoartnum = "um";
		else if ((arg.equals("Umas")) || (arg.equals("umas"))) novoartnum = "uma";
		return novoartnum;
	}
}


// classe principal, que implementa a interface
public class Janela extends JFrame
   implements ActionListener {


   private JLabel loriginal, lmodificada;
   private JTextArea original, modificada;
   private JButton alterar, abrir, proxima;
   private JCheckBox numero, genero;
   
   File arquivo;
   public BufferedReader arq;


	public Janela() {

	  super("Trabalho de POO");
      Container container = getContentPane();
      container.setLayout( new GridLayout(9,1) );
      
            
      abrir = new JButton( "Abrir Arquivo" );
      abrir.addActionListener( this );
      container.add( abrir );

      
      loriginal = new JLabel( "Frase Original" );
      original = new JTextArea( 5, 30 );
      original.setEditable(false);
      container.add( loriginal );
      container.add( original );
      
      
      lmodificada = new JLabel( "Frase Modificada" );
      modificada = new JTextArea( 5, 30 );
      modificada.setEditable(false);
      container.add( lmodificada );
      container.add( modificada );
      
      proxima = new JButton( "Pr�xima Frase" );
      proxima.setEnabled(false);
      proxima.addActionListener( this );
      container.add( proxima );
      
      numero = new JCheckBox("Alterar N�mero");
      genero = new JCheckBox("Alterar G�nero");
      container.add(numero);
      container.add(genero);
      
      alterar = new JButton( "Realizar Altera��es" );
      alterar.setEnabled(false);
      alterar.addActionListener( this );
      container.add( alterar );
      
      
      setSize(300,300);
      setVisible( true );
    }

	// fun��o que implementa as a��es de cada bot�o
	public void actionPerformed( ActionEvent actionEvent )
    {
		if ( actionEvent.getSource() == abrir )
         abre();
         
        if ( actionEvent.getSource() == proxima )
         getproxima();
         
        if ( actionEvent.getSource() == alterar )
         altera();
    }
	
	// fun��o main, que inicializa a aplica��o
	public static void main( String args[] ) {
		Janela application = new Janela();
		application.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
	}
	
	// a��o do bot�o que abre o arquivo
	public void abre() {
		JFileChooser fc = new JFileChooser();
		int opcao = fc.showOpenDialog(this);
		if (opcao == JFileChooser.APPROVE_OPTION) {
			arquivo = fc.getSelectedFile();
			proxima.setEnabled(true);
			alterar.setEnabled(true);
			
			try {
			
				arq = new BufferedReader(new InputStreamReader(new FileInputStream(arquivo)));
				original.setText(arq.readLine());
			
				} catch (FileNotFoundException e) {
				} catch (IOException e) {};
		}	
	}
	
	// a��o do bot�o para pegar a pr�xima linha do arquivo
	public void getproxima() {
		try {
		original.setText(arq.readLine());
		} catch (IOException e) {};
	}
	
	// a��o do bot�o para realizar as altera��es desejadas
	public void altera() {
		String orig = original.getText();
		String aux;
		
		Frase frase = new Frase(orig);
		
		if (orig.equals("")) modificada.setText("");
		else {
			if ((numero.isSelected()) && (genero.isSelected())) {
				aux = frase.genero();
				Frase aux2 = new Frase(aux);
				aux = aux2.numero();
				modificada.setText(aux);
			} else if ((!numero.isSelected()) && (genero.isSelected())) {
				aux = frase.numero();
				modificada.setText(aux);
			} else if ((numero.isSelected()) && (!genero.isSelected())) {
				aux = frase.genero();
				modificada.setText(aux);
			}
		}
	
	}
	
	
   
}