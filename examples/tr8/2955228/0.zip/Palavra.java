abstract class Palavra{

	// String que armazena uma palavra
	protected String palavra;

	// Construtor padrao
	Palavra(){}

	// Construtor sobrescrito onde jah se pode atribuir o conteudo da palavra
	Palavra(String palavra){
		this.set(palavra);
	}

	// Funcao que altera o genero de uma palavra qquer
	void mudaGenero(){
		if(this.palavra.endsWith("a")) this.palavra = this.palavra.substring(0,this.palavra.length()-1)+"o";
		else if(this.palavra.endsWith("o")) this.palavra = this.palavra.substring(0,this.palavra.length()-1)+"a";
		else if(this.palavra.endsWith("as")) this.palavra = this.palavra.substring(0,this.palavra.length()-2)+"os";
		else if(this.palavra.endsWith("os")) this.palavra = this.palavra.substring(0,this.palavra.length()-2)+"as";
	}

	// Funcao que altera o numero de uma palavra qquer
	void mudaNumero(){
		if(this.palavra.endsWith("a")||this.palavra.endsWith("o")) this.palavra = this.palavra+"s";
		else if(this.palavra.endsWith("as")||this.palavra.endsWith("os")) this.palavra = this.palavra.substring(0,this.palavra.length()-1);
	}

	// Funcao para imprimir o objeto (a palavra)
	public String toString(){
		return this.palavra;
	}

	// Funcao para atribuir um valor para a String palavra
	void set(String conteudo){
		this.palavra=conteudo;
		this.palavra.toLowerCase();
	}

}