class Verbo extends Palavra{

	// Construtor padrao
	Verbo(){}

	// Construtor sobrescrito onde jah se pode atribuir o conteudo da palavra
	Verbo(String palavra){
		this.set(palavra);
	}

	// Sobrescrita da funcao da clase Palavra, pois para o verbo o genero eh indiferente
	void mudaGenero(){}

	// Sobrescrita da funcao da clase Palavra, adicionando as particularidades de um verbo
	void mudaNumero(){
		if(this.palavra.endsWith("a")||this.palavra.endsWith("e")) this.palavra = this.palavra+"m";
		else if(this.palavra.endsWith("i")) this.palavra = this.palavra+"em";
		else if(this.palavra.endsWith("iem")) this.palavra = this.palavra.substring(0,this.palavra.length()-2);
		else if(this.palavra.endsWith("m")) this.palavra = this.palavra.substring(0,this.palavra.length()-1);
	}
}