class Artigo extends Palavra{

	// Construtor padrao
	Artigo(){}

	// Construtor sobrescrito onde jah se pode atribuir o conteudo da palavra
	Artigo(String palavra){
		this.set(palavra);
	}

	// Sobrescrita da funcao da clase Palavra, adicionando as particularidades de um artigo
	void mudaGenero(){
		if(palavra.equals("um")) palavra = palavra + "a";
		else if(palavra.equals("uma")) palavra = "um";
		else if(palavra.equals("uns")) palavra = "umas";
		else if(palavra.equals("umas")) palavra = "uns";
		else super.mudaGenero();
	}

	// Sobrescrita da funcao da clase Palavra, adicionando as particularidades de um artigo
	void mudaNumero(){
		if(palavra.equals("um")) palavra = "uns";
		else if(palavra.equals("uns")) palavra = "um";
		else super.mudaNumero();
	}

}