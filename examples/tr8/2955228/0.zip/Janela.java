// Classe que define a interface grafica (janela)

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;
import java.util.*;

class Janela extends JFrame {

		// Area de texto que mostra o texto original do arquivo
		private JTextArea textoOrig = new JTextArea("<texto original>");
		// Area de texto que mostra o texto jah alterado
		private JTextArea textoAlt = new JTextArea("<texto alterado>");
		// Objeto que contem a logica do programa
		private Trab7 trab;

  	//Construtor da janela
	public Janela(Trab7 trab) {

		// Painel principal
		JPanel painelPrincipal = new JPanel();
		// Painel com os botoes de acao
		JPanel menu = new JPanel();

		JScrollPane jScrollPane1 = new JScrollPane(textoOrig);
		JScrollPane jScrollPane2 = new JScrollPane(textoAlt);


		// Botao que abre a janela pra escolher o arquivo e definicao do listener
		JButton procurar = new JButton("Procurar...");
		procurar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        	procurar_actionPerformed(e);
		      	}
		});

		// Botao que altera o genero das frases e definicao do listener
		JButton genero = new JButton("g�nero");
		genero.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        	genero_actionPerformed(e);
		      	}
		});

		// Botao que altera o numero das frases e definicao do listener
		JButton numero = new JButton("n�mero");
		numero.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
		        	numero_actionPerformed(e);
		      	}
		});

		// Labels para auxiliar o usuario
		JLabel jLabel1 = new JLabel("Clique no bot�o para selecionar o arquivo.");
		JLabel jLabel2 = new JLabel("Alterar:");
		JLabel jLabel3 = new JLabel("Texto original:");
		JLabel jLabel4 = new JLabel("Texto alterado:");

		// Aponta o objeto Trab7 desta classe para o da classe Trab7
		this.trab=trab;

		// Titulo da janela
		this.setTitle("SCE-213 - Trabalho 7");
		// Quando a janela for fechada o programa deve ser encerrado
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		// Deixa o layout nulo para poder arrumar as posicoes livremente
		painelPrincipal.setLayout(null);
		// Nao deixa o usuario dar resize na janela
		this.setResizable(false);
		// Deixa os campos de texto desabilitados
		textoOrig.setEnabled(false);
		textoAlt.setEnabled(false);
		// Nao permite editar os campos de texto
		textoOrig.setEditable(false);
		textoAlt.setEditable(false);
		// Cria uma borda para o menu de acao
		menu.setBorder(BorderFactory.createEtchedBorder());
		// Deixa o layout nulo para poder arrumar as posicoes livremente
		menu.setLayout(null);

		// Adiciona os componentes aos respectivos paineis
		painelPrincipal.add(procurar, null);
		painelPrincipal.add(jLabel1, null);
		painelPrincipal.add(jScrollPane2, null);
		painelPrincipal.add(jScrollPane1, null);
		painelPrincipal.add(jLabel3, null);
		painelPrincipal.add(jLabel4, null);
		painelPrincipal.add(menu, null);
		menu.add(jLabel2, null);
		menu.add(genero, null);
		menu.add(numero, null);
		this.getContentPane().add(painelPrincipal);
		this.pack();

		// Arruma as dimensoes dos componentes
		this.setSize(new Dimension(404, 397));
		procurar.setBounds(new Rectangle(10, 42, 102, 25));
		genero.setBounds(new Rectangle(55, 16, 74, 25));
		numero.setBounds(new Rectangle(209, 15, 74, 25));
		jLabel1.setBounds(new Rectangle(130, 49, 230, 15));
		jScrollPane1.setBounds(new Rectangle(9, 97, 376, 87));
		jScrollPane2.setBounds(new Rectangle(10, 267, 377, 92));
		jLabel3.setBounds(new Rectangle(20, 76, 103, 15));
		jLabel4.setBounds(new Rectangle(21, 246, 101, 15));
		jLabel2.setBounds(new Rectangle(13, 4, 36, 15));
		menu.setBounds(new Rectangle(10, 193, 377, 50));

		// Mostra a janela
		this.setVisible(true);
  	}

	void procurar_actionPerformed(ActionEvent e) {

		// Janela de escolha do arquivo
    		JFileChooser chooser = new JFileChooser();

		// Classe que filtra os arquivos vistos por extensao
		// Nota: exemplo da classe ExampleFileFilter pode ser visto em FileChooserDemo,
		// no diretorio demo/jfc directory no Java 2 SDK, Standard Edition.
		BrowseFileFilter filter = new BrowseFileFilter();
		filter.addExtension("txt");
		filter.setDescription("Arquivo de texto puro");
		chooser.setFileFilter(filter);
		int returnVal = chooser.showOpenDialog(this);

		// Apos o usuario escolher o arquivo
		if(returnVal == JFileChooser.APPROVE_OPTION) {
			try{
				// O arquivo eh aberto
				trab.arquivo=new BufferedReader(new FileReader(chooser.getSelectedFile().getAbsolutePath()));
				this.textoOrig.setEnabled(true);
				String linha="";
				String tudo="";
				// Leitura das frases do arquivo ateh o fim do mesmo
				while((linha=trab.arquivo.readLine())!=null){
					tudo=tudo+linha+"\n";
					// Pra cada linha eh criado um objeto frase com seu conteudo
					Frase frase = new Frase(linha);
					trab.texto.add(frase);
				}
				// Mostra o texto original na tela
				this.textoOrig.setText(tudo);
			} catch(IOException ex){
			}
		}
	}

	void genero_actionPerformed(ActionEvent e) {
		this.textoAlt.setEnabled(true);
		String result="";
		// Cada frase (representada por um objeto Frase) tem seu genero alterado
		for(int i=0;i<trab.texto.size();i++) result=result+((Frase)trab.texto.get(i)).mudaGenero()+"\n";
		this.textoAlt.setText(result);
	}

	void numero_actionPerformed(ActionEvent e) {
		this.textoAlt.setEnabled(true);
		String result="";
		// Cada frase (representada por um objeto Frase) tem seu numero alterado
		for(int i=0;i<trab.texto.size();i++) result=result+((Frase)trab.texto.get(i)).mudaNumero()+"\n";
		this.textoAlt.setText(result);
	}

	// Destrutor do objeto. Fecha o arquivo quando a janela eh fechada
  	public void finalize(){
    		try{
      			trab.arquivo.close();
    		} catch (IOException ex){
    		}
  	}
}