class Frase{

	// Colecao de objetos Palavra implementado com array
	Palavra frase[] = new Palavra[5];

	// Construtor padrao
	Frase(){}

	// Seguindo a estrutura de frase pedida na descricao, inicializa cada elemento
	Frase(String s){
		String palavras[] = new String[5];
		palavras = s.split(" ",5);
		frase[0] = new Artigo(palavras[0]);
		frase[1] = new Substantivo(palavras[1]);
		frase[2] = new Verbo(palavras[2]);
		frase[3] = new Artigo(palavras[3]);
		frase[4] = new Substantivo(palavras[4]);
	}

	// Altera o genero de cada objeto da frase
	String mudaGenero(){
		for(int i=0;i<frase.length;i++) frase[i].mudaGenero();
		return (this.toString());
	}

	// Altera o numero de cada objeto da frase
	String mudaNumero(){
		for(int i=0;i<frase.length;i++) frase[i].mudaNumero();
		return (this.toString());
	}

	// Imprime (retorna o valor d)a frase
	public String toString(){
		return(frase[0]+" "+frase[1]+" "+frase[2]+" "+frase[3]+" "+frase[4]);
	}
}