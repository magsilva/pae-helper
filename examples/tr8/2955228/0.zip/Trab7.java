// Classe principal que define a logica do programa

import javax.swing.*;
import java.io.*;
import java.util.*;

class Trab7{

	// Arquivo de texto com as frases
	BufferedReader arquivo;

	// Array de Objetos Frase (vide classe Frase.java)
	ArrayList texto = new ArrayList(0);

	// Construtor padrao
	Trab7(){

		// Deixa a interface grafica a cara do sistema operacional hospedeiro
		try{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch (Exception ex){}

		// Chama a janela
		Janela jan = new Janela(this);
	}

	// Metodo principal
	public static void main(String args[]){

		// Inicia o trabalho
		Trab7 trab7 = new Trab7();
		
	}

}