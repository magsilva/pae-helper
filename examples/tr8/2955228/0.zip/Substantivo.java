class Substantivo extends Palavra{

	// Construtor padrao
	Substantivo(){}

	// Construtor sobrescrito onde jah se pode atribuir o conteudo da palavra
	Substantivo(String palavra){
		this.set(palavra);
	}

}