

class genero
{
        
        static String  gen (String args)
        {        
                int i=0;
                int o=0;
                int l=0;
                int tes=0;
                int espaco[];
                char artigo1;
                char artigo1n='A';
                char artigo2;
                char artigo2n = ' ';
                String subst1;
                String subst2;
                String verbo;
                String subst1n;
                String subst2n;
                String finall;
                        
                o = args.length();

                espaco = new int[5];
                
                
                        
                for(i=0;i<o;i++)
                {        if (args.charAt(i) == ' ')
                        {        
                                espaco[l]=i;
                                l = l + 1;
                                }
                        
                        }
                
                artigo1 = args.charAt(0);
                subst1 = args.substring(espaco[0],espaco[1]);
                verbo =  args.substring(espaco[1],espaco[2]);
                artigo2= args.charAt(espaco[2] + 1);
                subst2 = args.substring(espaco[3],o);
                
                
                if (artigo1 == 'O')
                                artigo1n = 'A';
                else
                        if (artigo1 == 'A')
                                artigo1n = 'O';
                                
                if (artigo2 == 'o')
                                artigo2n = 'a';
                else
                        if (artigo2 == 'a')
                                artigo2n = 'o';
                                
                subst1n = genero.generosubst(subst1);
                subst2n = genero.generosubst(subst2);
                
                
                finall =( artigo1n + subst1n + verbo + ' ' + artigo2n + subst2n);
                return finall;
                
                
                
        }
        static String generosubst(String args)
        {
                int t1=0;
                String novofim=" ";
                
                t1 = args.length();
                                
                if (args.charAt(t1-1) == 'o')
                {
                        novofim = args.substring(0,t1-1).concat("a");
                                
                }
                        
                if (args.charAt(t1-1) == 'a')
                {
                        novofim = args.substring(0,t1-1).concat("o");
                        
                }
                return novofim;
        }
        
        static String numero(String args)
        {
                int i=0;
                int o=0;
                int l=0;
                int tes=0;
                int espaco[];
                int tamsub;
                String artigo1;
                String art1n;
                String artigo2;
                String art2n;
                String sub1;
                String sub2;
                String verbo;
                String verbon;
                String sub1n;
                String sub2n;
                String finalnum;
                        
                o = args.length();

                espaco = new int[5];
                
                for(i=0;i<o;i++)
                {        if (args.charAt(i) == ' ')
                        {        
                                espaco[l]=i;
                                l = l + 1;
                                }
                        
                        }
                
                artigo1= args.substring(0,espaco[0]);
                sub1 = args.substring(espaco[0],espaco[1]);
                verbo =  args.substring(espaco[1],espaco[2]);
                artigo2= args.substring(espaco[2],espaco[3]);
                sub2 = args.substring(espaco[3],o);
                
                
                art1n = artigo1.concat("s");
                sub1n  = sub1.concat("s");
                art2n = artigo2.concat("s");
                sub2n  = sub2.concat("s");
                
                
                tamsub = verbo.length();
                
                
                if (verbo.charAt(tamsub-1) == 'i')
                                verbon = verbo.substring(0,tamsub-1).concat("em");
                                        
                else
                        verbon = verbo.concat("m");
                
                
                finalnum =( art1n + sub1n + verbon + art2n + sub2n);
                return finalnum;
                
                
                
        }

       
        
}
