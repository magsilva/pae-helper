import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.io.*;


public class Principal extends JFrame {
	private JLabel titulo, titulo2, titulo3;
	private JTextField nome_arquivo,linha_lida,linha_alterada;
	private JButton generobut, numerobut;
	
	String linha, alterada;
	
	public Principal()
	{
	super ("Lista de exerc�cios 7");
	Container container = getContentPane();
	container.setLayout(new FlowLayout());
	
	titulo = new JLabel("Digite o nome do arquivo e pressione enter");
	container.add(titulo);
	nome_arquivo = new JTextField("c:\\ent.txt", 30);
	container.add(nome_arquivo);
	
	titulo2 = new JLabel("Linha lida :");
	container.add(titulo2);
	linha_lida = new JTextField(30);
	linha_lida.setEditable (false);
	container.add(linha_lida);
	
	generobut = new JButton("Alterar G�nero");
	container.add(generobut);
	numerobut = new JButton("Alterar N�mero");
	container.add(numerobut);
	
	
	titulo3 = new JLabel("Linha alterada :");
	container.add(titulo3);
	linha_alterada = new JTextField(30);
	linha_alterada.setEditable (false);
	container.add(linha_alterada);
	
	
	ButtonHandler hand = new ButtonHandler();
	generobut.addActionListener(hand);
	numerobut.addActionListener(hand);
	TextFieldHandler handler = new TextFieldHandler();
	nome_arquivo.addActionListener(handler);
		
	setSize(340,200);
	setVisible(true);
	}
	
	
	
	public static void main(String args[])
	{
		
	Principal app = new Principal();
	
	app.setDefaultCloseOperation( JFrame.EXIT_ON_CLOSE );
	}
	
	private class ButtonHandler implements ActionListener
		{
			public void actionPerformed ( ActionEvent event )
				{
				if (event.getSource() == generobut)	
					{
						alterada = genero.gen(alterada);
						linha_alterada.setText(alterada);

					}	
					
				else if (event.getSource() == numerobut)	
					{
						alterada = genero.numero(alterada);
						linha_alterada.setText(alterada);
					}
				}
		}
	
	private class TextFieldHandler implements ActionListener
		{
			public void actionPerformed (ActionEvent event)
			{
			
				if (event.getSource() == nome_arquivo)	
				{
					try {
   						FileReader reader = new FileReader(event.getActionCommand());
   						BufferedReader input = new BufferedReader(reader);
   						linha = input.readLine();
   						alterada = linha;
 						linha_lida.setText(linha);
						} 
					catch (IOException ex) {
						JOptionPane.showMessageDialog(null, "Erro ao ler o arquivo" );	
						}
   			

				}
				
				
				
			}
		}// Fim da classe interna TextFieldHandler
}// Fim da classe Principal





