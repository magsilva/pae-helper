class Palavra{
	public String palavra;
	private int fim;

	public Palavra(String arg){
	palavra = arg;
	fim = palavra.length() -1;
	} // end of contructor method palavra

	public int analize(){

	if( (palavra.charAt(0) == '<') && (palavra.charAt(fim) == '>') ) return 1;
	else if( (palavra.charAt(0) == '<') && (palavra.charAt(fim) != '>') ) return 2;
	else if( (palavra.charAt(0) != '<') && (palavra.charAt(fim) == '>') ) return 2;
	else if(palavra.charAt(0) == '>')return 2;
	else if(palavra.charAt(fim) == '<')return 2;
	else return 0;

	}	

} // end of class Palavra

class Frase {
	private String frase;
	public int n;

 	public Frase(String arg){
	frase = arg;
	n = frase.split(" ").length;
	}// end of constructor method Frase

	public String[] getPals(){
	return frase.split(" ");

	}

} // end of class Frase

class Texto {
	public String[] frase;

	public Texto(String[] args){
	frase = args;

	} //end of method texto

} //end of class texto



public class MainEx1{
	public static void main(String[] args) {

	String[] aux={"abc <123> def","<456 >fgh 789<"};

	Texto texto = new Texto(aux); //cria um objeto com o texto a analizar

	for(int i=0; i<texto.frase.length; i++) {
		StringBuffer[] tags= new StringBuffer[10];
		int k=0; //contador de tags invalidas
		int p=0; //contador de tags validas
		int q=0; //contador de palavras


		Frase frase = new Frase(texto.frase[i]); //para o texto cria objetos frases
		for(int j=0; j<frase.n; j++) {
			q=frase.n;
			Palavra palavra = new Palavra(frase.getPals()[j]); // para cada frase, palavras

			if (palavra.analize()==1) tags[p++]=new StringBuffer(palavra.palavra);
			else if(palavra.analize()==2) k++;

			} //fim da verificacao de cada palavra
		System.out.println("Frase: " + (i+1) + " com " + q + " palavras, " + p + " tags validas, " + k + " tags invalidas");
		System.out.print("Tags validas: ");
		for(int w=0;w<p;w++) System.out.print(tags[w]); System.out.println();

	} //fim da leitura do texto
	

	} //end of main method
} //end of class Main
