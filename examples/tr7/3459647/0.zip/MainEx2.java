public class MainEx2{

	// programa principal exemplo para teste

	public static void main(String[] args){
	
	ConjInteiros bla = new ConjInteiros();
	ConjInteiros blaw = new ConjInteiros();
	
	blaw.add(61);
	blaw.add(71);
	blaw.add(91);
	blaw.add(-20);
	

	bla.add(61);
	bla.add(61);
	bla.add(51);
	bla.add(76);
	bla.add(-20);
	bla.add(-38);
	bla.remove(51);

	blaw.print();
	bla.print();

	
	blaw.interseccao(bla);
	bla.uniao(blaw);
	bla.subtracao(blaw);

	}


}


class ConjInteiros{
	// escolhemos armazenar os n�meros em uma string, como caracteres. Os inteiros correspondem
	// ao c�digo ASCII de cada caracter.

	public StringBuffer conjp= new StringBuffer(50); // string que armazena os positivos
	public StringBuffer conjn= new StringBuffer(50); // string que armazena os negativos


	public ConjInteiros(){
	}//end of constructor method ConjInteiros

	// m�todo para adicionar um elemento no conjunto, se o elemento ainda naum existe nele
	public void add(int arg){
	int indp= conjp.indexOf(String.valueOf( (char)arg));
	int indn= conjn.indexOf(String.valueOf( (char)-arg));

	if( (arg>=0)&&(indp==-1) ) conjp.append( (char)arg);
	else if ( (arg < 0)&&(indn==-1) ) conjn.append( (char)-arg);

	}//---------------------------------------------fim do method add

	// m�todo para remover um elemento do conjunto, se o elemento existe nele
	public void remove(int arg){

	int indp= conjp.indexOf(String.valueOf( (char)arg));
	int indn= conjn.indexOf(String.valueOf( (char)-arg));

	if( (arg >= 0)&&(indp != -1) ) conjp.deleteCharAt(indp);
	else if( (arg < 0)&&(indn != -1) ) conjn.deleteCharAt(indn);

	}//-----------------------------------------------fim do method remove
	
	// m�todo para imprimir todos os elementos do conjunto na tela
	public void print() {
		
	int i;	
	
	for(i=0; i<conjp.length(); i++)
		System.out.println( (int)conjp.charAt(i));
		
	for(i=0; i<conjn.length(); i++)
		System.out.println( -(int)conjn.charAt(i));
		
	System.out.println();
	System.out.println();
	}//--------------------------------------------fim do method print
	

	// m�todo que realiza a uni�o do conjunto com outro conjunto passado como par�metro
	public void uniao(ConjInteiros other) {

	int i;

	ConjInteiros result = new ConjInteiros();

	result.conjn = conjn;
	result.conjp = conjp;

	for(i=0; i<other.conjp.length(); i++)
		result.add((int)other.conjp.charAt(i));
	
	for(i=0; i<other.conjn.length(); i++)
		result.add(-(int)other.conjn.charAt(i));
		
	System.out.println("Uniao dos conjuntos:");
	result.print();

	} //--------------------------------------------fim do method uniao

	// m�todo que realiza a intersec��o do conjunto com outro conjunto passado como par�metro
	public void interseccao(ConjInteiros other) {

	int i,j;

	ConjInteiros result = new ConjInteiros();

	for(i=0; i<conjp.length(); i++)
		for(j=0; j<other.conjp.length(); j++)
			if(conjp.charAt(i) == other.conjp.charAt(j))
				result.add((int)conjp.charAt(i));

	for(i=0; i<conjn.length(); i++)
		for(j=0; j<other.conjn.length(); j++)
			if(conjn.charAt(i) == other.conjn.charAt(j))
				result.add(-(int)conjn.charAt(i));


	System.out.println("Interseccao dos conjuntos:");
	result.print();

	} //-------------------------------------------fim do method interseccao

	// m�todo que realiza a subtra��o de um conjunto passado como par�metro do conjunto
	public void subtracao(ConjInteiros other) {

	int i,j, cont;
	
	ConjInteiros result = new ConjInteiros();

	result.conjp = conjp;
	result.conjn = conjn;

	for(i=0; i<other.conjp.length(); i++)
		if(result.conjp.indexOf(String.valueOf(other.conjp.charAt(i))) != -1)
			result.remove((int)other.conjp.charAt(i));

	for(i=0; i<other.conjn.length(); i++)
		if(result.conjn.indexOf(String.valueOf(other.conjn.charAt(i))) != -1)
			result.remove(-(int)other.conjn.charAt(i));

	System.out.println("Subtracao dos conjuntos:");
	result.print();
	} //----------------------------------------- fim do method subtracao

} //end of class ConjInteiros
