/*

SCE-213 - Programa��o Orientada a Objetos

Lista de Exerc�cios 6 - Java

Exerc�cio 3)


	O exerc�cio anterior poderia ser resolvido utilizando-se classes do pr�prio Java, como por
exemplo estendendo a classe HashSet, que implementa a interface Set. No caso de utilizar essa classe,
poder�mos utilizar os m�todos 'add' e 'remove', que j� est�o implementados de maneira a checar se um
objeto existe no set antes de adicion�-lo ou remov�-lo.
	A vantagem de utilizarmos uma classe do pr�prio Java � justamente essa, a possibilidade de
realizarmos sobrecarga sobre os m�todos j� implementados
	Uma desvantagem dessa solu��o � o fato de termos de adaptar nosso programa � classe, e n�o a
classe ao programa, como seria se desenvolv�ssemos nossa pr�pria classe.

*/