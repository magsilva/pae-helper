class palavra extends tag
{    

	static int npalavras(String args)
	{	
	
		int o;
		int i=0;
		int count=0;
		
		o = (args.length());
		
		while (i<o)

		{	char p;
			p = args.charAt(i);
			if (p==' ')	
				{count++;
			 	     i++;	}

			 	else	

				   i++;
			
		}	
		
		return count;
		
		
     }

	
	public static void main(String args[])
	{
		int i=0;
		int cont;
		int cont1;
		int er1;
		int er2;
		String txt;
	    String txt2;
		
		palavra pal = new palavra();
		
		txt = "Teste de uso de <tags> em poo";
		txt2 = "e processamento de <problemas com <mau> uso <de> tag";
		
		cont = palavra.npalavras(txt);
		cont1 = palavra.npalavras(txt2);
		
		er1 = tag.erros(txt);
		er2 = tag.erros(txt2);

		
	
		System.out.println("Numero de palavras da primeira linha e: " + (cont+1) );
		System.out.println("Numero de palavras da segunda linha e: " + (cont1+1) );
		System.out.println("Numero de tags errados na primeira linha:" + er1 );
		System.out.println("Numero de tags errados na segunda linha:" + er2 );


	}	
}




class tag 
{
	
	static int erros(String args)
	{	
		int i=0;
		int o=0;
		int l=0;
		int errado=0;
		char p;
		
		o = args.length();
		
		StringBuffer strin = new StringBuffer();
		
		for(i=0;i<o;i++)
		{
			if ((args.charAt(i)=='<') || (args.charAt(i)=='>'))
			{	
				p = args.charAt(i);
				strin.append(p);
				}
       	}
		
		l = strin.length();
		
		
		for(i=0;i<(l-1);i++)
		{ if(strin.charAt(i)=='<')
			{	if(strin.charAt(i+1)=='<')
							errado++;
							 		
			}	
			
			
		}
				
		return errado;
		
		
		
	}
	
	public static void main(String args[])
	{	
		
		tag novo = new tag();
		
		
		}
	
	
}




