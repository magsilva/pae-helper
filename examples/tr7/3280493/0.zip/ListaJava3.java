/*
Para resolver o problema utilizando-se a interface set seria necess�rio redefinir
todos os m�todos da mesma (uma vez que eles sao abstratos), ent�o o problema ser� 
resolvido utilizando-se uma classe concreta que j� implementa SET (no caso, hashset)
Todos os outros m�todos devem ser implementados de forma an�loga. 
*/


import java.util.HashSet;

class Aux
    {
    public int x;
    }

class ConjuntoInteiros extends HashSet
    {

        public void adiciona(int valor)
        {
        Aux a = new Aux();
        a.x = valor;
        add(a);
        }
    }
        
