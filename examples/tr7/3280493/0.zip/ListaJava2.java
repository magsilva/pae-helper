
public class ListaJava2 
        {
        public static void main(String args[])
            { 
             ConjuntoInteiros c = new ConjuntoInteiros();
             ConjuntoInteiros d = new ConjuntoInteiros();
             
             System.out.print("Conjuntos b e d instanciados\n");
             
             c.adiciona(10);
             c.adiciona(11);
             c.adiciona(12);
             c.adiciona(13);

             c.imprime();
                          
             c.remove(10);
             c.remove(30);

             c.imprime();
             
             d.adiciona(10);
             d.adiciona(11);
             d.adiciona(12);
             d.imprime();
             
             c.intersec��o(d);
             System.out.print("Intersec��o executada\n");
             c.imprime();
             
             c.uni�o(d);
             System.out.print("Uniao executada\n");
             c.imprime();
             
             d.remove(10);
             d.remove(11);
             c.subtra�ao(d);
             System.out.print("Subtra�ao executada\n");
             c.imprime();
            }
        }



class ConjuntoInteiros 
        {
        int valores[];
        int cardinalidade;
  
        
        public ConjuntoInteiros()
        {
            cardinalidade = 0;
            valores = new int[300];
            System.out.print("Classe inicializada\n");
        }
        
        
        public void adiciona(int valor)
        {
            try
            {
                valores[cardinalidade] = valor;
                cardinalidade++;
            }
            catch (NumberFormatException num)
            {
                System.out.print("Apenas aceitam-se n�meros inteiros.\n");
            }
        }
        
        
        public void remove(int valor)
        {
         int i,j;
         for ( i = 0; i < cardinalidade; i++)
         {
            if (valor == valores[i])
            {
                for (j = i; j < cardinalidade; j++)
                    valores[j] = valores[j + 1];
                cardinalidade--;    
            }   
         }
        }
        
        
        public void uni�o (ConjuntoInteiros outro)
        {
            int i,j,k;
            for (j = 0; j < outro.cardinalidade; j++) 
                adiciona(outro.valores[j]);  
                // Soma os dois conjuntos
            
            for (j = 0; j < cardinalidade; j++)             
                for (i = j+1 ; i < cardinalidade ; i++)
                    if (valores[j] == valores[i]) 
                    {
                     for (k = i; k < cardinalidade; k++)
                         valores[k] = valores[k + 1];
                     cardinalidade--;   
                    }
            // Retira os repetidos
        }
        
        
        public void intersec��o(ConjuntoInteiros outro)
        {
            int cardaux = 0;
            int array[];
            array = new int[300];
            for ( int i = 0; i < cardinalidade; i++)
                for (int j = 0; j < outro.cardinalidade; j++)
                {
                    if (valores[i] == outro.valores[j])                    
                    {
                    valores[cardaux] = outro.valores[j];
                    cardaux++;
                    }
                }
            cardinalidade = cardaux;
        }
        
        
        public void subtra�ao(ConjuntoInteiros outro)
        {
            for (int j = 0; j < outro.cardinalidade; j++)
                remove(outro.valores[j]);
        }


        public void imprime()
        {
            System.out.print("M�todo imprime. Valores : ");
            for (int i = 0; i < cardinalidade; i++)
                System.out.print(valores[i]+" ");
            System.out.print("\n");
        }
}// Fim classe conjuntointeiros
