import java.io.*;


/****************** CLASSE PALAVRA ********************/
/* Esta classe recebe uma palavra, identifica se �    */
/* uma Tag v�lida ou n�o e calcula o n�mero de Tags   */
/******************************************************/

class Palavra {
	
	public int cont_tag = 0;
	public int cont_invtag = 0;
	
	public Palavra(StringBuffer p) {
		
		int len = p.length();
		
		if ((p.charAt(0) == '<') && (p.charAt(len - 1) == '>')) {
				cont_tag++;
		}
		else if ((p.charAt(0) == '<') ^ (p.charAt(len - 1) == '>')){
				cont_invtag++;
		}
			
	}
}


/**************** FIM CLASSE PALAVRA ******************/



/****************** CLASSE FRASE **********************/
/* Esta classe recebe uma string e divide cada string */
/* em palavras 					      */
/******************************************************/

class Frase {

	public StringBuffer word = new StringBuffer(); 
	public int cont_word = 0;
	public int c_tag = 0;
	public int c_invtag = 0;
	public StringBuffer tv = new StringBuffer();

	public Frase(String text) {
		
		int len = text.length();
		int i = 0;
		int j = 0;

		while (text.charAt(i) == ' ') {   
			i++;
		}
		
		for (j = i; j < len; j++) {
			if (text.charAt(j) != ' ') {
				word.append(text.charAt(j));
			}
			else {
				cont_word++;
				Palavra P = new Palavra(word);
				c_tag += P.cont_tag;
				c_invtag += P.cont_invtag;
				if (P.cont_tag == 1){
					tv.append(" " + word);
				}
				word = new StringBuffer();
			}
		}
		cont_word++;
		Palavra P = new Palavra(word);
		c_tag += P.cont_tag;
		c_invtag += P.cont_invtag;
		if (P.cont_tag == 1){
			tv.append("" + word);
		}		
	}	
}

/**************** FIM CLASSE FRASE ********************/



/************* CLASSE TEXTO (PRINCIPAL) ***************/
/* Esta classe le o texto de entrada e armazena em um */
/* vetor de strings				      */
/******************************************************/

public class Texto {
   

	public static void main(String[] args) {

		final int n_linhas;
		int i = 0;

		try {   /* Le o numero de linhas */
			System.out.println("Entre com o numero de linhas: ");
			BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
			n_linhas = Integer.parseInt(entrada.readLine());

			/* Leitura das frases */
			String[] tex = new String[n_linhas];
			System.out.println("Entre com o texto: ");
			BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
			tex[i] = "";	
			while (i < n_linhas) {

				tex[i] = in.readLine();
				i++;
				}
			System.out.println(" ");
	        	System.out.println("Leitura de dados efetuada");

			for(i = 0; i < n_linhas; i++){
  				Frase F = new Frase(tex[i]);
				System.out.print("Linha " + (i+1) + ": " + F.cont_word + " palavras -- ");
				System.out.print(F.c_tag + " tags validas -- " + "(" + F.tv + " )");
				System.out.println(F.c_invtag + " tags invalidas.");
			}


		} 
		catch (IOException e) {
			System.out.print("Voce conseguiu errar maneh!");
			}
		catch (NumberFormatException e1){
			System.out.print("Entre com valores inteiros!");
			}
		catch (ArrayIndexOutOfBoundsException e2){
			System.out.print("O texto deve conter pelo menos uma linha!");
			}

		
	  }
}

/**************** FIM CLASSE TEXTO ********************/	
