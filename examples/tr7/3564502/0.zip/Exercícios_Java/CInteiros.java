import java.io.*;

public class CInteiros {

		static int opcao = 0;
		static int tamanho = 0;
		static int[] vetor;

	public static void main(String[] args) {
		
	  try{	
		CInteiros c = new CInteiros();
		while (opcao != 8){
			c.telaInicial();

			switch (opcao) {

				case 1: /*inicializa conjunto*/
					int i = 0;
					System.out.println("");
					System.out.println("Qual o tamanho do conjunto?");
					BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
					tamanho = Integer.parseInt(entrada.readLine());
					vetor = new int[tamanho];

					System.out.println("");
					System.out.println("Entre com os numeros: ");
					BufferedReader elementos = new BufferedReader(new InputStreamReader(System.in));

					for(i =0; i<tamanho; i++){
					vetor[i] = Integer.parseInt(elementos.readLine());
					}
					c.inicializar(vetor, tamanho);
					break;

				case 2: /*adiciona elemento*/

					int elemento= 0;
						  
					System.out.println("");
					System.out.println("Qual elemento deseja adicionar?");
					BufferedReader ent = new BufferedReader(new InputStreamReader(System.in));
					elemento = Integer.parseInt(ent.readLine());
					c.adiciona(elemento);
				
					break;

				case 3: /* remove elemento*/
						elemento = 0;
						System.out.println("");
						System.out.println("Qual elementto deseja remover?");
						BufferedReader ent2 = new BufferedReader(new InputStreamReader(System.in));
						elemento  = Integer.parseInt(ent2.readLine()); 				
						c.remove(elemento);
						break;
				
				case 4: 
						int[] vetor2;
						int tamanho2 = 0;
						System.out.println("");
						System.out.println("Qual o tamanho do novo conjunto?");
						BufferedReader ent3 = new BufferedReader(new InputStreamReader(System.in));
						tamanho2 = Integer.parseInt(ent3.readLine());
						vetor2 = new int[tamanho2];

						System.out.println("");
						System.out.println("Entre com os numeros: ");
						BufferedReader elementos2 = new BufferedReader(new InputStreamReader(System.in));

						for(i =0; i<tamanho2; i++){
						vetor2[i] = Integer.parseInt(elementos2.readLine());
						}
						c.uniao(vetor2, tamanho2);
						break;
				
				case 5: 
						int[] vetor3;
						int tamanho3 = 0;
						System.out.println("");
						System.out.println("Qual o tamanho do novo conjunto?");
						BufferedReader ent4 = new BufferedReader(new InputStreamReader(System.in));
						tamanho3 = Integer.parseInt(ent4.readLine());
						vetor3 = new int[tamanho3];

						System.out.println("");
						System.out.println("Entre com os numeros: ");
						BufferedReader elementos3 = new BufferedReader(new InputStreamReader(System.in));

						for(i =0; i<tamanho3; i++){
						vetor3[i] = Integer.parseInt(elementos3.readLine());
						}
						c.interseccao(vetor3, tamanho3);
						break;

				case 6: int[] vetor4;
						int tamanho4 = 0;
						System.out.println("");
						System.out.println("Qual o tamanho do novo conjunto?");
						BufferedReader ent5 = new BufferedReader(new InputStreamReader(System.in));
						tamanho4 = Integer.parseInt(ent5.readLine());
						vetor4 = new int[tamanho4];

						System.out.println("");
						System.out.println("Entre com os numeros: ");
						BufferedReader elementos4 = new BufferedReader(new InputStreamReader(System.in));

						for(i =0; i<tamanho4; i++){
						vetor4[i] = Integer.parseInt(elementos4.readLine());
						}
						
						c.subtracao(vetor4, tamanho4);
						break;
				case 7: c.imprime();
						break;
				case 8: break;

				default: System.out.println("entrada invalida");
			}
		}
	  }
	  catch (IOException e) {System.out.println("Erro de entrada/saida");}
	  catch (ArrayIndexOutOfBoundsException e1) {System.out.println("");}


	}
/**************** METODO TELA INICIAL ********************/

	void telaInicial(){
	  try{
		System.out.println("   :: Escolha opcao ::");
		System.out.println("");
		System.out.println("1 - Inicializar Conjunto de Inteiros");
		System.out.println("2 - Adicionar Numeros");
		System.out.println("3 - Remover Numeros");
		System.out.println("4 - Uniao de Conjunto");
		System.out.println("5 - Interseccao de Conjunto");
		System.out.println("6 - Subtracao de Conjunto");
		System.out.println("7 - Visualizar Conjunto");
		System.out.println("8 - Sair");

		BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        	opcao = Integer.parseInt(entrada.readLine());
	     }
  	  catch (IOException e0){
		System.out.println("erro de Entrada/Saida");
		}

	}

/****************** FIM TELA INICIAL *********************/

/***************** METODO INSERE *************************/

	void inicializar(int[] vet, int tam) {

		
			int i = 0;
			boolean teste = false;
			
			if (!repetido(vetor)) {
				System.out.println("insercao Ok!");
				System.out.println("");
			}
			else{
				vet = new int[tam];
				System.out.println("insercao falhou!");
				System.out.println("");
			}
		

	}

/******************* FIM INSERE ****************************/

/****************** METODO REPETIDO ************************/

	boolean repetido(int[] vet) {
		int i = 0;
		int j = 0;
		boolean teste = false;

		for (i=0; i < (vet.length -1); i++) {
			for (j=i+1; j< vet.length; j++){
				if (vet[j] == vet[i]) {
					teste = true;
				}
			}
		}
		return (teste);
	}

/******************** FIM REPETIDO *************************/

/******************* METODO ADICIONA ***********************/

	void adiciona(int elemento) {
		int i = 0;
		boolean teste = false;
		
		int[] vetaux = new int[tamanho];

		for(i =0; i<tamanho; i++){
			vetaux[i] = vetor[i];
		}
		tamanho = tamanho +1;
		vetor = new int[tamanho];

		for(i =0; i< (tamanho-1); i++){
			vetor[i] = vetaux[i];
		}
		vetor[tamanho - 1] = elemento;
		
		if (repetido(vetor)) {
			tamanho = tamanho - 1;
			System.out.println("Elemento ja existente no conjunto");
		}
		else {
			System.out.println("Adicao OK!");
			
		}
	      

	}

/********************* FIM ADICIONA ************************/

/******************* METODO REMOVE *************************/

	void remove(int elemento) {
		int[] vetaux = new int[tamanho];
		int i = 0;
		int j = 0;
	
		
		while (i < tamanho) {
				if (vetor[i] != elemento) {
					vetaux[j] = vetor[i];
					i++;
					j++;
				}
				else {
					i++;
				}
			}
			tamanho = j;
			vetor = new int[tamanho];
			for (i=0; i<tamanho; i++) {
				vetor[i] = vetaux[i];
			}
		 
	}
			
	
/*********************** FIM REMOVE ************************/

/********************* METODO UNIAO ************************/

	void uniao(int[] vet2,int tam2) {
		int tam = 0;
		int i = 0;
		
		while (i<tam2){
			adiciona(vet2[i]);
			i++;
		}
	}

/*********************** FIM UNIAO *************************/

/******************** METODO INTERSECCAO *******************/

	void interseccao(int[] vet3,int tam3) throws ArrayIndexOutOfBoundsException {
		int k = 0;
		int i = 0;
		int j = 0;
		int[] vetaux;
		int contador = 0;
		
		for (i = 0; i<tamanho;i++){
			for (j = 0; j<tam3;j++){
				if (vetor[i] == vet3[j]){
					contador++;
								
				}
			}
		}
		vetaux = new int[contador];
	
		for (i = 0; i<tamanho;i++){
			for (j = 0; j<tam3;j++){
				if (vetor[i] == vet3[j]) {
					if (k <contador) {
						vetaux[k] = vetor[i];
						k++;
					}
								
				}
			}
		}
		
		vetor = new int[contador];
		for (i = 0; i<contador; i++){
			vetor[i] = vetaux[i];	
		}
	}

/********************** FIM INTERCESSAO ********************/

/********************* METODO SUBTRACAO ********************/

	void subtracao(int[] vet4, int tam4) {
		int[] vetaux;
		int i = 0;
		int j = 0;
		boolean igual = false;
		int contador = 0;
		int k = 0;
		
		for (i = 0; i<tamanho;i++){
			for (j = 0; j<tam4;j++){
				if (vetor[i] == vet4[j]){
					contador++;
								
				}
			}
		}
		int size = tamanho - contador;
		System.out.println(size);
		vetaux = new int[size];
	
		for (i = 0; i<tamanho;i++){
			for (j = 0; j<tam4;j++){
				if (vetor[i] == vet4[j]) {
					igual = true;
											
				}
			}
			if (!igual && k<size) {
				vetaux[k] = vetor[i];
				k++;
			}
			igual = false;
		}
		
		vetor = new int[size];
		for (i = 0; i<size; i++){
			vetor[i] = vetaux[i];	
		}
		
		
		
	}

/************************ FIM SUBTRACAO *********************/

/********************** METODO IMPRIME **********************/

	void imprime() {
		int i =0;
		System.out.println(" ");
		for (i =0; i<tamanho; i++){
			System.out.print(vetor[i] + " ");
			System.out.println("");
		}
	}

/*********************** FIM IMPRIME ************************/
}
