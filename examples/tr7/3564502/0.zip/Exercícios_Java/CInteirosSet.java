import java.io.*;
import java.util.*;

class CInteirosSet extends Vector
{	
	private int num;
	TreeSet vet;
	
	public CInteirosSet()
	{
		vet = new TreeSet();
	}


	public void adiciona (int num)
	{
		Integer inteiro = new Integer(num);
		vet.add(inteiro);
	}
	

	public void remove (int num){
		Integer inteiro = new Integer(num);
		vet.remove(inteiro);
	}

	
	public TreeSet uniao (CInteirosSet vet2){  
		vet.addAll(vet2.vet);
		return vet;
		
	}

	public TreeSet interseccao(CInteirosSet vet2){
		vet.retainAll(vet2.vet);
		return vet;
	}

	public TreeSet subtracao(CInteirosSet vet2){
		vet.removeAll(vet2.vet);
		return vet;
	}

	public void imprime(){
		System.out.println("Saida: " + vet);
	}

			/* metodo principal*/
			
	public static void main(String[] args){
		CInteirosSet aux1 = new CInteirosSet();
		CInteirosSet aux2 = new CInteirosSet();
		TreeSet c = new TreeSet();
		aux1.adiciona(10);
		aux1.adiciona(20);
		aux1.remove(10);
		aux2.adiciona(10);
		aux2.remove(10);
		aux2.adiciona(30);
		aux2.adiciona(40);
		aux2.remove(30);
		aux1.imprime();			
		aux2.imprime();			
		aux3 = aux1.uniao(aux2);
		aux3 = aux1.interseccao(aux2);
		aux3 = aux1.subtracao(aux2);		
		System.out.println(aux3);
	}
	
}