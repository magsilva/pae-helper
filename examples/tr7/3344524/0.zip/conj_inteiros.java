import java.io.*;
import javax.swing.JOptionPane;
import java.util.*;


class ConjuntoInteiros extends TreeSet{

	void adiciona (int i) {
		add(new Integer(i));
	}
	void remocao(int i) {
		remove(new Integer(i));
	}
	void uniao(ConjuntoInteiros outro){
		addAll(outro);
	}

	void interseccao(ConjuntoInteiros outro){
		retainAll(outro);
	}
	void diferenca(ConjuntoInteiros outro){
		removeAll(outro);
	}

	void impressao(){
		System.out.println(this);
		System.out.println();
	}

}
class conj_inteiros {
	public static void main(String[] args) {	
		ConjuntoInteiros Conj = new ConjuntoInteiros();
		ConjuntoInteiros Outro = new ConjuntoInteiros();

		Conj.adiciona(10);
		Conj.adiciona(20);
		Conj.adiciona(30);	
		Outro.adiciona(30);
		Outro.adiciona(25);
		Conj.impressao();
		Outro.impressao();

		Conj.uniao(Outro);
		Conj.impressao();

		Conj.interseccao(Outro);
		Conj.impressao();
		Conj.adiciona(40);

		Conj.diferenca(Outro);
		Conj.impressao();

		Conj.adiciona(10);
		Conj.adiciona(20);
		Conj.remocao(10);
		Conj.impressao();
	}
}