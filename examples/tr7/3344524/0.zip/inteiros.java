import java.io.*;
import javax.swing.JOptionPane;
import java.util.*;


class ConjuntoInteiros {
	Vector conjunto = new Vector();
	void adiciona (int i) {
		if (!conjunto.contains(new Integer(i))){
			conjunto.add(new Integer(i));
		}
	
	}
	void remocao(int i) {
		conjunto.remove(new Integer(i));
	}
	void uniao(ConjuntoInteiros outro){
		int tamanho;
		tamanho = outro.conjunto.size();
		for (int i=0; i < tamanho; i++) {
			if (!conjunto.contains(outro.conjunto.elementAt(i))){
				conjunto.add(outro.conjunto.elementAt(i));
			}
				
		}
	}

	void interseccao(ConjuntoInteiros outro){
		int tamanho;
		Vector aux = new Vector();
		for (int i=0; i < conjunto.size(); i++) {		
			if (outro.conjunto.contains(conjunto.elementAt(i))) {
				aux.add(conjunto.elementAt(i));
			}
		}
		conjunto = aux;
	}
	void diferenca(ConjuntoInteiros outro){
		int tamanho;	
		Vector aux = new Vector();
		for (int i=0; i < conjunto.size(); i++) {		
			if (!outro.conjunto.contains(conjunto.elementAt(i))) {
				aux.add(conjunto.elementAt(i));
			}
		}
		conjunto = aux;
	}

	void impressao(){
		for (int i=0; i < conjunto.size(); i++) 
			System.out.println(conjunto.elementAt(i));
		System.out.println();
	}

}
class inteiros {
	public static void main(String[] args) {	
		ConjuntoInteiros Conj = new ConjuntoInteiros();
		ConjuntoInteiros Outro = new ConjuntoInteiros();

		Conj.adiciona(10);
		Conj.adiciona(20);
		Conj.adiciona(30);	
		Outro.adiciona(30);
		Outro.adiciona(25);
		Conj.impressao();
		Outro.impressao();

		Conj.uniao(Outro);
		Conj.impressao();

		Conj.interseccao(Outro);
		Conj.impressao();
		Conj.adiciona(40);

		Conj.diferenca(Outro);
		Conj.impressao();

		Conj.adiciona(10);
		Conj.adiciona(20);
		Conj.remocao(10);
		Conj.impressao();
	}
}