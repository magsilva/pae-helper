import java.io.*;
import javax.swing.JOptionPane;


public class analisa {
	public static void main(String[] args) {
		frases f = new frases();
		String str;
		int i = 0, n;
		
		str = JOptionPane.showInputDialog("Entre com o numero de frases: ");
		n = Integer.parseInt(str);
		
		while (i < n) {
			Integer aux = new Integer( i+1 );
			str = JOptionPane.showInputDialog("Entre com a " + aux.toString() + "a. frase:");
			f.addFrase(str);
			i++;
		}
		

		JOptionPane.showMessageDialog(null, f.toString(), "Resultados", JOptionPane.PLAIN_MESSAGE);
		
		//imprime no DOS
		//System.out.println(f.toString());

		System.exit(0);
		
	}
}

class frases {

	private int cont;
	private String linhas;
	
	public frases(){
		this.setCont(0);
		this.setLinhas ("");
	}
	
	private String analisa (String a) {

		palavras p = new palavras();
		Tags t = new Tags();
		String aux = "";
		int n = a.length();
		boolean tag_state = false;
		
		this.setCont(this.getCont() + 1);
		
		Integer c = new Integer( this.getCont() );

		for (int i=0; i < n; i++) {
			char pos = a.charAt(i);
			
			if ((' ' == pos) || (i == (n-1))) {
				p.incrementa();
			} else {
				if ( ('<' == pos ) && ( !tag_state )){
					tag_state = true;
					t.incNum_tags();					
				} else {
					if (('<' == pos )&&(tag_state)) {
						aux = "";
						t.incNum_tags_probl();
					} else {
						if (('>' == pos)&&(tag_state)){
							tag_state = false;
							aux += pos;
							t.addTags(aux);
							aux = "";
						}
					}
				}
			}
			
			if (tag_state) {
				aux += pos;
			}
			
		}

		return "Linha " + c.toString() + " - " + p.toString() + " - " + t.toString() + "\n";
	}
	
	private int getCont(){
		return this.cont;
	}
	
	private void setCont(int a){
		this.cont = a;
	}
	
	private void setLinhas(String a) {
		this.linhas = a;
	}
	
	private String getLinhas() {
		return this.linhas;
	}
	
	public void addFrase(String a){
		this.setLinhas(this.getLinhas() + this.analisa(a));
	}
	
	
	public String toString(){
		if (this.getCont() == 0) {
			return "nao foi analisada nenhuma linha";
		} else {
			return linhas;
		}
	}
	
}

final class palavras {
	
	private int num_pal;
	
	public palavras () {
		this.setQuant(0);
 	}
	
	public void incrementa() {
		this.setQuant(this.getQuant() + 1);
	}
	
	private int getQuant(){
		return this.num_pal;
	}
	
	private void setQuant(int a){
		this.num_pal = a;
	}
	
	public String toString(){
	
		Integer i = new Integer( this.getQuant() );
		return i.toString() + " palavras";
		
	}
}

final class Tags {
	
	private int num_tags;
	private int num_tags_probl = 0;
	private String tags;
	
	public Tags() {
		this.setNum_tags(0);
		this.setNum_tags_probl(0);
		this.setTags("");
	}
	
	public void incNum_tags(){
		this.setNum_tags(this.getNum_tags() + 1);
	}
	
	public void incNum_tags_probl(){
		this.setNum_tags_probl(this.getNum_tags_probl() + 1);
	}
	
	public void addTags(String a){
		this.setTags(this.getTags() + a);
	}
	
	private void setNum_tags(int a){
		this.num_tags = a;
	}
	
	private void setNum_tags_probl(int a){
		this.num_tags_probl = a;
	}
	
	private void setTags(String a){
		this.tags = a;
	}
	
	private int getNum_tags () {
		return this.num_tags;
	}
	
	private int getNum_tags_probl () {
		return this.num_tags_probl;
	}
	
	private String getTags () {
		return this.tags;
	}
	
	public String toString(){
		
		Integer i = new Integer(this.getNum_tags());
		Integer j = new Integer(this.getNum_tags_probl());
		
		return i.toString() + " tags validas (" + this.getTags() + ") - " + j.toString() + " tags invalidas";
		
	}
	
}





