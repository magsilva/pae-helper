//package Exe2;
// Utilizavel para inteiros >= 0.

public class ConjuntoInteiros
{
	private int vet_inteiros [];
	private int qtos;

	/*========================================================================*/
	/** Funcao : ConjuntoInteiros (Construtor da Classe).
	      Objetivo : Inicializar as variaveis de instancia da classe.
	 */
	/*========================================================================*/
	ConjuntoInteiros (int qtos)
	{
		this.vet_inteiros = new int [qtos];
	}


	/*========================================================================*/
	/** Funcao : ConjuntoInteiros (Construtor da Classe).
	      Objetivo : Inicializar as variaveis de instancia da classe.
	 */
	/*========================================================================*/
	ConjuntoInteiros (ConjuntoInteiros outro)
	{
		this.qtos = outro.Get_Qtos();
		this.vet_inteiros = new int [this.qtos + 50];   // para posterior inclusao de elementos
		for (int cont = 0; cont < outro.Get_Qtos(); cont ++)
			this.vet_inteiros[cont] = outro.Get_Elem(cont);
		
	}


	/*========================================================================*/
	/** Funcao : Busca.
	      Objetivo : Buscar um determinado numero no vetor de inteiros.
	 */
	/*========================================================================*/
	private int Busca (int num_procurado)
	{
		for (int cont = 0; cont < this.qtos; cont ++)
		{
			if (this.vet_inteiros[cont] == num_procurado)
				return cont;
		}
		return -1;
		
	}	

	/*========================================================================*/
	/** Funcao : Insere.
	      Objetivo : Inserir um novo numero no vetor de inteiros, verificando se o mesmo ja existe.
	 */
	/*========================================================================*/
	public void Insere (int num_inserir)
	{
		if (this.Busca(num_inserir) == -1)
			this.vet_inteiros [this.qtos++] = num_inserir;
	}
	

	/*========================================================================*/
	/** Funcao : Remove.
	      Objetivo : Remover um numero do vetor de inteiros.
	 */
	/*========================================================================*/
	public void Remove (int num_remover)
	{
		int indice = this.Busca(num_remover);
		
		if (indice != -1)
		{
			for (int cont = indice; cont < this.qtos; cont ++)
				this.vet_inteiros [cont] = this.vet_inteiros[cont + 1];

			this.qtos --;
		}
		
	}	



	/*========================================================================*/
	/** Funcao : Uniao.
	      Objetivo : Executar a uniao de dois conjuntos de inteiros.
	 */
	/*========================================================================*/
	public ConjuntoInteiros Uniao(ConjuntoInteiros outro)
	{
		ConjuntoInteiros resultado = new ConjuntoInteiros (this);

		for (int cont = 0; cont < outro.Get_Qtos(); cont ++)
		{
			resultado.Insere (outro.Get_Elem(cont));
		}

		return resultado;
	}	



	/*========================================================================*/
	/** Funcao : Interseccao.
	      Objetivo : Retornar um conjunto com a interseccao de outros dois conjuntos.
	 */
	/*========================================================================*/
	public ConjuntoInteiros Interseccao (ConjuntoInteiros outro)
	{
		ConjuntoInteiros resultado = new ConjuntoInteiros (20);
		boolean maior = (this.qtos > outro.Get_Qtos());

		int tmp;

		if (maior)
		{
			for (int cont = 0; cont < outro.Get_Qtos(); cont ++)
				if (this.Busca ((tmp = outro.Get_Elem(cont))) != -1)
					resultado.Insere (tmp); 
		}
		else
		{
			for (int cont = 0; cont < this.qtos; cont ++)
				if (outro.Busca ((tmp = this.vet_inteiros[cont])) != -1)
					resultado.Insere (tmp); 
		}

		return resultado;
	}



	/*========================================================================*/
	/** Funcao : Subtracao.
	      Objetivo : Calcular a diferenca entre dois conjuntos de inteiros.
	 */
	/*========================================================================*/
	public ConjuntoInteiros Subtracao (ConjuntoInteiros outro)
	{
		ConjuntoInteiros resultado = new ConjuntoInteiros (20);
		int tmp;

		for (int cont = 0; cont < this.qtos; cont ++)
			if (outro.Busca ((tmp = this.vet_inteiros[cont])) == -1)
				resultado.Insere (tmp); 

		return resultado;
	}	
	
	
	/*========================================================================*/
	/** Funcao : toString.
	      Objetivo : Retornar o conjunto como string, utilizado para impressao.
	 */
	/*========================================================================*/
	public String toString ()
	{
		String resultado = new String("");
		
		for (int cont = 0; cont < this.qtos; cont ++)
			resultado += this.vet_inteiros[cont] + " "; 	

		return resultado;
	}

	/*========================================================================*/
	/** Funcao : Get_Qtos.
	      Objetivo : Obter o numero de elementos do conjunto.
	 */
	/*========================================================================*/
	public int Get_Qtos ()
	{
		return this.qtos;
	}


	/*========================================================================*/
	/** Funcao : Get_Elem.
	      Objetivo : Obter um elemento do conjunto localizado na posicao indice.
	 */
	/*========================================================================*/
	public int Get_Elem (int indice)
	{
		if (indice > this.qtos)
			return -1;
		else
			return this.vet_inteiros[indice];
	}


}