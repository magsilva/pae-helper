
class Principal
{
	public static void main (String Args [] )
	{
		ConjuntoInteiros teste = new ConjuntoInteiros (10);
		ConjuntoInteiros teste2 = new ConjuntoInteiros (20);
		
		teste.Insere (20);
		teste.Insere (26);
		
		teste.Insere (26);
		teste.Insere (36);
		teste.Insere (19);
		
		System.out.println ("Teste 1 antes de Remover : " + teste);

		teste.Remove (20);

		System.out.println ("Teste 1 " + teste);

		teste2.Insere (87);
		teste2.Insere (56);
		teste2.Insere (59);
		teste2.Insere (19);

		System.out.println ("Teste 2 " + teste2);

		System.out.println ("Uniao : " + teste.Uniao(teste2));
		System.out.println ("Interseccao : " + teste.Interseccao(teste2));
		System.out.println ("Subtracao : " + teste.Subtracao(teste2));
	}
}