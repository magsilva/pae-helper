import java.util.*;
import java.io.*;

class ConjuntoInteiros extends Vector
{	
	private int numero;
	TreeSet vetor;
	
	/*========================================================================*/
	/** Funcao : ConjuntoInteiros (Construtor da Classe).
	      Objetivo : Inicializar o vetor de inteiros da classe.
	 */
	/*========================================================================*/
	public ConjuntoInteiros()
	{
		this.vetor = new TreeSet();
	}


	/*========================================================================*/
	/** Funcao : Insere.
	      Objetivo : Inserir um novo numero no vetor de inteiros, verificando se o mesmo ja existe.
	 */
	/*========================================================================*/
	public void Insere (int num_inserir)
	{
		Integer num = new Integer(num_inserir);
		this.vetor.add(num);
	}
	

	/*========================================================================*/
	/** Funcao : Remove.
	      Objetivo : Remover um numero do vetor de inteiros.
	 */
	/*========================================================================*/
	public void Remove(int num_remover)
	{
		Integer num = new Integer (num_remover);

		this.vetor.remove(num);
	}

	/*========================================================================*/
	/** Funcao : toString.
	      Objetivo : Retornar o conjunto como string, utilizado para impressao.
	 */
	/*========================================================================*/
	public String toString ()
	{
		String resultado = new String(this.vetor.toString());
		
		return resultado;
	}

	/*========================================================================*/
	/** Funcao : Uniao.
	      Objetivo : Executar a uniao de dois conjuntos de inteiros.
	 */
	/*========================================================================*/
	public ConjuntoInteiros Uniao(ConjuntoInteiros outro)
	{
		ConjuntoInteiros resultado = new ConjuntoInteiros ();

		resultado.vetor.addAll(this.vetor);
		resultado.vetor.addAll(outro.vetor);

		return resultado;
		
	}

	/*========================================================================*/
	/** Funcao : Interseccao.
	      Objetivo : Retornar um conjunto com a interseccao de outros dois conjuntos.
	 */
	/*========================================================================*/
	public ConjuntoInteiros Interseccao(ConjuntoInteiros outro)	
	{
		ConjuntoInteiros resultado = new ConjuntoInteiros ();

		resultado.vetor.addAll(this.vetor);

		resultado.vetor.retainAll(outro.vetor);

		return resultado;
	}

	/*========================================================================*/
	/** Funcao : Subtracao.
	      Objetivo : Calcular a diferenca entre dois conjuntos de inteiros.
	 */
	/*========================================================================*/
	public ConjuntoInteiros Subtracao(ConjuntoInteiros outro)
	{
		ConjuntoInteiros resultado = new ConjuntoInteiros ();

		resultado.vetor.addAll(this.vetor);

		resultado.vetor.removeAll(outro.vetor);

		return resultado;
	}

	
}