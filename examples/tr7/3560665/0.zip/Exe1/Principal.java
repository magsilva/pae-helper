//import Exe1.*;

class Principal
{
	public static void main (String Args [] )
	{
		Texto teste = new Texto("arq_dados.txt");
		teste.Executar ();
		
		System.out.println (teste);
	}
}