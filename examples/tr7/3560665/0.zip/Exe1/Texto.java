//package Exe1;

import java.io.*;

public class Texto extends Texto_Base
{
	private int qtas_frases;
	private Frase vet_frases [];
	
	private String nome_arq;

	/*========================================================================*/
	/** Funcao ; Texto(Construtor da classe).
	      Objetivo ;
	 */
	/*========================================================================*/
	public Texto (String nome_arq)
	{
		this.qtas_frases = 0;
		this.nome_arq = new String(nome_arq);
		
		this.vet_frases = new Frase[30];
	}


	/*========================================================================*/
	/** Funcao ; Executar.
	      Objetivo ;
	 */
	/*========================================================================*/
	public void Executar ()
	{
		InputStream arq_fis;
      	DataInputStream arq_logic;
		String dados;
		
      	try
      	{
        	arq_fis = new FileInputStream(this.nome_arq);
           	arq_logic = new DataInputStream(arq_fis);

			while ((dados = arq_logic.readLine()) != null)
			{
				this.vet_frases[this.qtas_frases++] = new Frase (dados);
			}
			
        	arq_fis.close();
        	
      	}   	
		catch(IOException e) {};
//      	catch(FileNotFoundException e){};
 	}



	/*========================================================================*/
	/** Funcao ; toString (chamada ao exibir objeto)r.
	      Objetivo ;
	 */
	/*========================================================================*/
	public String toString ()
	{
		String resultado = new String("");
		
		for (int cont = 0; cont < this.qtas_frases; cont ++)
		{
			resultado += "Linha " + (cont + 1)+ " - " + this.vet_frases[cont] + "\n";
		}
		
		return resultado;
					
	}
	
}