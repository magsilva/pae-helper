//package Exe1;

abstract class Texto_Base
{
	protected String texto;



	/*========================================================================*/
	/** Funcao ; Executar.
	      Objetivo ;
	 */
	/*========================================================================*/
	public abstract void Executar ();





	/*========================================================================*/
	/** Funcao ; toString (chamada ao exibir objeto).
	      Objetivo ;
	 */
	/*========================================================================*/
	public abstract String toString ();
}