//package Exe1;

public class Palavra extends Texto_Base
{
	private boolean tag;
	private boolean valido;

	/*========================================================================*/
	/** Funcao : Palavra (Construtor da Classe).
	      Objetivo : Inicializar as variaveis de instancia da classe.
	 */
	/*========================================================================*/
	Palavra (String texto)
	{
		this.tag = false;
		this.valido = false;

		this.texto = new String(texto);
		this.Executar();
	}


	/*========================================================================*/
	/** Funcao : Executar.
	      Objetivo : Verificar se a palavra e um tag, e neste caso verificar se e valido.
	*/
	/*========================================================================*/
	public void Executar ()
	{
		if (this.texto.indexOf('<')  != -1)
		{
			this.tag = true;

			if (this.texto.indexOf('>')  != -1)
				this.valido = true;
		}
			// nao executa acao pois tag ja inicia falsa.
	}

	/*========================================================================*/
	/** Funcao : toString (chamada ao enviar classe para a saida).
	      Objetivo : Formatar a saida de texto da classe para exibicao no dispositivo de saida.
	 */
	/*========================================================================*/
	public String toString ()
	{
		return this.texto;
	}


	/*========================================================================*/
	/** Funcao : Get_Tag.
	      Objetivo : Retornar o valor da variavel tag.
	 */
	/*========================================================================*/
	public boolean Get_Tag ()
	{
		return this.tag;
	}

	/*========================================================================*/
	/** Funcao : Get_Valido.
	      Objetivo : Retornar o valor da variavel valido.
	 */
	/*========================================================================*/
	public boolean Get_Valido ()
	{
		return this.valido;
	}

}