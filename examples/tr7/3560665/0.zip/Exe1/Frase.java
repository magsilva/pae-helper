//package Exe1;

public class Frase extends Texto_Base
{
	private int qtas_palavras;
	private int qtas_tags_validas;
	private int qtas_tags_invalidas;

	private Palavra vet_palavras[];
	private int vet_validas [];

	/*========================================================================*/
	/** Funcao ; Frase (construtor da classe).
	      Objetivo ;
	 */
	/*========================================================================*/
	public Frase (String texto)
	{
		this.qtas_palavras = 0;
		this.qtas_tags_validas = 0;
		this.qtas_tags_invalidas = 0;

		this.vet_palavras = new Palavra[30];
		this.vet_validas = new int [30];

		this.texto = new String(texto);
		
		this.Executar ();
	}

	/*========================================================================*/
	/** Funcao ; Executar.
	      Objetivo ;
	 */
	/*========================================================================*/
	public void Executar ()
	{
		int anterior,
		    atual;

		for (anterior = 0; (atual = this.texto.indexOf (' ', anterior)) != -1; anterior = atual + 1)
		{
			
			this.vet_palavras[qtas_palavras] = new Palavra(this.texto.substring(anterior, atual));
			
			if (this.vet_palavras[qtas_palavras].Get_Tag ())
			{
				if (this.vet_palavras[qtas_palavras].Get_Valido())
				{
					this.vet_validas[this.qtas_tags_validas] = this.qtas_palavras;
					this.qtas_tags_validas ++;
				}
				else
					this.qtas_tags_invalidas ++;
			}

			this.qtas_palavras ++;

		}
		this.vet_palavras[qtas_palavras] = new Palavra(this.texto.substring(anterior, this.texto.length()));
	}

	/*========================================================================*/
	/** Funcao ; toString (chamado pelos metodos de exibicao da classe).
	      Objetivo ;
	 */
	/*========================================================================*/
	public String toString ()
	{
		String resultado = new String (this.qtas_palavras + " palavras - " + this.qtas_tags_validas + " tags validas (");

		for (int cont = 0; cont < qtas_tags_validas; cont ++)
			resultado += vet_palavras[this.vet_validas[cont]];

		resultado += ") - " + this.qtas_tags_invalidas + " tags invalidas.";

		return resultado;

	}
}