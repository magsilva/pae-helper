/**
 * Usar�amos a interface Set pois esta interface  modela  a  abstra��o
 * matem�tica de conjunto.
 * Criar�amos a classe ConjuntoInteiros extendida de Set. Nesta classe
 * seria implementado somente o m�todo Imprimir - alem do(s) construtor
 * (s). Os outros m�todos que foram implementados no exerc�cio anterior 
 * seria  substitu�do  pelos m�todos da interface Set como segue:
 * 
 * -----------------------------
 * -----------------------------
 * Exercicio2      Exercicio3
 * -----------------------------
 * -----------------------------
 * Adicionar       add
 * _____________________________
 * Remover         remove
 * _____________________________
 * Uniao           addAll
 * _____________________________
 * Interseccao     retainAll 
 * _____________________________
 * Subtracao       removeAll
 * _____________________________
 *
 * Vantagem(s) de se utilizar classes extendidas:
 *    . Nao h� necessidade de implementacao dos m�todos que ser�o utili-
 *      zados no qual nao se quer nenhuma modifica��o;
 * 
 * Desvantagem(s) de se utilizar classes extendidas:
 *    . Deve-se declarar os prot�tipos de todos os m�todos da interface
 *      mesmo daqueles que nao serao utilizados;
 */

