import java.util.ArrayList;
import java.util.StringTokenizer;

public class Lista1 {
	public static void main ( String[] args ) {
            int i = 0;
            String entrada = new String ("Teste do uso de <TAGS> em POO\ne processamento de <problemas com <mau> uso <de> tags?");
		ArrayList listaDeFrases = new ArrayList();
		StringTokenizer listaTemp = new StringTokenizer (entrada, "\n");
		while (listaTemp.hasMoreTokens()) {
                	Frase temp = new Frase (listaTemp.nextToken());
			listaDeFrases.add(temp); //adiciona cada frase a lista de frases.
            } //while

            Frase temp;
            for (int k=0; k<listaDeFrases.size(); k++) {
                temp = (Frase)listaDeFrases.get(k);
                System.out.println("Frase: " + temp.conteudo);
                System.out.println("Tags Problema: " + temp.numTagsProblema);
                System.out.println("Tags boas: " + temp.numTagsBoas);
                System.out.println("Total de Tags: " + temp.numTags);
            }


      	} //main
} //Lista1

class Tag {
	boolean tagCorreta;
	String conteudo;
	public Tag (String tagAtual) {
                tagCorreta = true;
                this.conteudo = tagAtual;

	}
}

class Frase {
        int numTags, numTagsProblema, numTagsBoas;
	String conteudo;
	ArrayList listaDePalavras, listaDeTags;
        public Frase (String frase) {

                //inicializacao das variaveis
        	this.numTags = this.numTagsProblema = this.numTagsBoas = 0;

        	String tagAtual = new String("");
		Palavra tagTemp = new Palavra("");

        	this.conteudo = new String(frase);

        	this.listaDePalavras = new ArrayList();

        	this.listaDeTags = new ArrayList();

        	StringTokenizer listaTemp = new StringTokenizer(frase);

        	while (listaTemp.hasMoreTokens()) {

        		tagTemp = new Palavra(listaTemp.nextToken());

			listaDePalavras.add (tagTemp.conteudo);

                        //casos em que existe o sinal de < ou >
                        if ((tagTemp.conteudo.indexOf('<') >= 0) || (tagTemp.conteudo.indexOf('>') >= 0)) {

                                if (tagAtual.length() > 0) { //jah existe uma tag iniciada
                                        if (tagTemp.conteudo.indexOf('<') >= 0) {
                                                numTagsProblema++;
                                                //reinicializa tagAtual
                                                tagAtual = new String(tagTemp.conteudo);
                                                if ((tagAtual.indexOf('<') == 0) && (tagAtual.indexOf('>') == (tagAtual.length()-1)) ) {
                                                        this.numTagsBoas++;
                                                        listaDeTags.add(new Tag(tagAtual));
                                                        tagAtual = new String("");                                                       
                                                } 
                                        }

                                        else {
                                                tagAtual.concat(tagTemp.conteudo);
                                                if ((tagAtual.indexOf('<') == 0) && (tagAtual.indexOf('>') == (tagAtual.length()-1)) ) {
                                                        this.numTagsBoas++;
                                                        listaDeTags.add(new Tag(tagAtual));
                                                        tagAtual = new String("");                                                       
                                                }
                                        }
                                }
                                //nao tem nada em tagAtual
                                else {

                                        tagAtual = new String(tagTemp.conteudo);
                                        if ( (tagAtual.indexOf('<') == 0) && (tagAtual.indexOf('>') == (tagAtual.length()-1) ) ) {
                                                this.numTagsBoas++;
                                                tagAtual = new String("");
                                                listaDeTags.add(new Tag(tagAtual));
                                        }
                                                                        
                                        else {
                                                if (tagAtual.indexOf('<') == -1) {
                                                        numTagsProblema++;
                                                        tagAtual = new String("");
                                                }
                                                else if (tagAtual.indexOf('>') >=0) {
                                                        numTagsProblema++;
                                                        tagAtual = new String("");
                                                }
                                                else {
                                                        tagAtual = new String (tagTemp.conteudo);
                                                        tagAtual.concat(" ");
                                                }
                                        }
                                }
                        }

                        //nao existe nem < nem >
                        else if (tagAtual.length() > 0) {
				tagAtual.concat(tagTemp.conteudo);
				tagAtual.concat(" ");
			}
                } //fim while
                
                if ((tagAtual.length() > 0) && (tagAtual.indexOf('<') >= 0)) {
                        numTagsProblema++;
                }
                numTags = numTagsBoas + numTagsProblema;
		
	}
}

class Palavra {	
	public String conteudo;
	public Palavra (String word) {
		this.conteudo = new String(word);
        }
}
