import java.util.ArrayList;

public class Exercicio2 {
    
    public static void main (String args[]) {
        ConjuntoInteiros A = new ConjuntoInteiros ();
        ConjuntoInteiros B = new ConjuntoInteiros (2);
        A.Adicionar (3);
        A.Adicionar (4);
        A.Adicionar (5);
        B.Adicionar (4);
        
        System.out.println ("Conjuto A:");
        A.Imprimir ();
        
        System.out.println ("\nConjunto B:");
        B.Imprimir ();
        
        System.out.println ("\nA U B:");
        A.Uniao(B).Imprimir ();
        
        System.out.println ("\nB - {4}");
        B.Remover (4);
        B.Imprimir ();
        
        System.out.println ("\nA Interseccao B:");
        A.Interseccao(B).Imprimir();
        
        System.out.println ("\nA - B");
        A.Subtracao(B).Imprimir();
    }
    
}

class ConjuntoInteiros {
    ArrayList conteudo = new ArrayList();
    
    public ConjuntoInteiros () {
    }
    
    public ConjuntoInteiros (int num) {
        /*verificar o tipo de num para depois adicionar a conteudo*/
        this.conteudo.add (new Integer (num));
    }
    
    public boolean Adicionar (int num) {
         if (this.conteudo.contains(new Integer (num))) //elemento ja existente
            return false;
        else {
            /*verificar o tipo de num para depois adicionar a conteudo*/
            this.conteudo.add(new Integer (num));
            return true;
        }    
    }    
    
    public boolean Remover (int num) {
        if (this.conteudo.contains(new Integer (num))) { //elemento esta contido no conjunto
            this.conteudo.remove(new Integer (num));
            return true;
        }    
        else //elemento nao esta contido no conjunto
            return false;
    }    
    
    public ConjuntoInteiros Uniao (ConjuntoInteiros other) {
        ConjuntoInteiros temp = new ConjuntoInteiros();
        temp.conteudo = this.conteudo;
        for (int index = 0; index < other.conteudo.size(); index++) {
            if ( !( this.conteudo.contains(other.conteudo.get(index)) ) ) 
                temp.conteudo.add (other.conteudo.get(index));
        }    
        return temp;
    }    
        
    public ConjuntoInteiros Interseccao (ConjuntoInteiros other) {
        ConjuntoInteiros temp = new ConjuntoInteiros();
        for (int index = 0; index < this.conteudo.size(); index++) {
            if ( other.conteudo.contains(this.conteudo.get(index)) )
                temp.conteudo.add(this.conteudo.get(index));
        }   
        return temp;
    }    
    
    public ConjuntoInteiros Subtracao (ConjuntoInteiros other) {
        ConjuntoInteiros temp = new ConjuntoInteiros();
        for (int index = 0; index < this.conteudo.size(); index++) {
                if ( !(other.conteudo.contains(this.conteudo.get(index))) ) 
                    temp.conteudo.add(this.conteudo.get(index));
        }
        return temp;
    }
    
    public void Imprimir () {
        System.out.println (this.conteudo);
    }
     
}