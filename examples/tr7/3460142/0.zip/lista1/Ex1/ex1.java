/*Marcelo Kenji Hotta
 *3460142
 *kenji@grad.icmc.usp.br*/

/*Classe Ex1
 *Esta classe contem o main. Instancia as outras classes e imprime o resultado*/
class Ex1 {
    public static void main(String[] args) {
		System.out.println("==============Inicializado!==============");


//Instanciando o Texto
        Texto t = new Texto("Teste de uso de <TAGS> em POO\ne processamento de <problemas com <mau> uso <de> tags?");
        
//print texto (mostra o conteudo do texto)
        System.out.println("\nTEXTO:-----------------------");
        System.out.println(t.PrintTexto());
        				
//print frase (mostra o conteudo de cada frase)
		System.out.println("\nFRASE:-----------------------");
		for(int i=0; i<t.N(); i++){
			System.out.println("F" + i + ":" + t.frase[i].PrintFrase());
		}
		
//print palavra (mostra o conteudo de cada palavra)
		System.out.println("\nPALAVRA:---------------------");
		for(int i=0; i<t.N(); i++){
			for(int j=0; j<t.frase[i].N(); j++){
				System.out.println("F" + i + "|P" + j + ":" + t.frase[i].palavra[j].PrintPalavra());
			}
		}

//print letra (mostra o conteudo de cada letra)
		System.out.println("\nLETRA:-----------------------");
		for(int i=0; i<t.N(); i++){
			for(int j=0; j<t.frase[i].N(); j++){
				for(int k=0; k<t.frase[i].palavra[j].N(); k++){
					System.out.println("F" + i + "|P" + j + "|L" + k + ":" + t.frase[i].palavra[j].letra.charAt(k));
				}
			}

		}
	
//print Resultados (imprime os dados requeridos
		System.out.println("\nResultados:\n");
		for(int i=0; i<t.N(); i++){
			System.out.println("linha " + i + " - " + t.frase[i].N() + " palavras " + t.frase[i].NTagOK() + " tags validas (" + t.frase[i].TagOK() + ") - " + t.frase[i].NTagBAD() + " tags invalidas (" + t.frase[i].TagBAD() + ")");
		}
	}
}



/*classe Texto
 *frase -> Array que guarda frases do texto*/
class Texto {
	Frase[] frase;
	
	Texto(String texto) {
		String[] f;
		
		f = texto.split("\n");
		frase = new Frase[f.length];
		for (int i=0; i<f.length; i++){
			frase[i] = new Frase(f[i]);
		}
	}
	
	//metodo que retorna o conte�do do texto
	String PrintTexto() {
		String resultado = frase[0].PrintFrase();
		for (int i=1; i<frase.length; i++){
			resultado = resultado + "\\n" + frase[i].PrintFrase();
		}
		return(resultado);
	}
	
	//metodo que retorna a quantidade de frases no texto
	int N() {
		return (frase.length);
	}	
}


/*classe Frase
 *palavra -> Array que guarda palavras da frase*/
class Frase {
	Palavra[] palavra;
	
	Frase(String frase) {
		String[] p;
		
		p = frase.split(" ");
		palavra = new Palavra[p.length];
		for (int i=0; i<p.length; i++){
			palavra[i] = new Palavra(p[i]);
		}
	}
	
	//metodo que retorna o conte�do da frase
	String PrintFrase() {
		String resultado = palavra[0].PrintPalavra();
		for (int i=1; i<palavra.length; i++){
			resultado = resultado + " " + palavra[i].PrintPalavra();
		}
		return(resultado);
	}
	
	//metodo que retorna a quantidade de palavras na frase
	int N() {
		return (palavra.length);
	}
	
	//metodo que retorna o numero de Tags validas
	int NTagOK() {
		int resultado = 0;
		for(int i=0; i<this.N(); i++){
			if(palavra[i].Tag()==1) resultado++;
		}
		return (resultado);
	}
	
	//metodo que retorna o numero de Tags invalidas
	int NTagBAD() {
		int resultado = 0;
		for(int i=0; i<this.N(); i++){
			if(palavra[i].Tag()==-1) resultado++;
		}
		return (resultado);
	}
	
	//metodo que retorna as Tags validas
	String TagOK() {
		String resultado = " ";
		for(int i=0; i<this.N(); i++){
			if(palavra[i].Tag()==1){
				resultado = resultado + palavra[i].PrintPalavra() + " ";
			}
		}
		return (resultado);
	}
	
	//metodo que retorna as Tags invalidas
	String TagBAD() {
		String resultado = " ";
		for(int i=0; i<this.N(); i++){
			if(palavra[i].Tag()==-1){
				resultado = resultado + palavra[i].PrintPalavra() + " ";
			}
		}
		return (resultado);
	}
}

/*classe Palavra
 *letra -> Array que guarda letras da palavra*/
class Palavra {
	String letra;
	
	Palavra(String palavra) {
		letra = palavra;
	}
	
	//metodo que retorna o conte�do da palavra
	String PrintPalavra() {
		return (letra);
	}
	
	//metodo que retorna a quantidade de letras na palavra
	int N() {
		return (letra.length());
	}	
	
	/*metodo que testa a palavra
	 * 1 > Tag valida
	 * 0 > Nada
	 *-1 > Tag invalida*/
	int Tag() {
		if((letra.charAt(0) == '<') || (letra.charAt(this.N()-1) == '>')){
			if((letra.charAt(0) == '<') && (letra.charAt(this.N()-1) == '>')){
				return(1);//eh tag
			}else{
				return(-1);//tag com defeito
			}
		}else{
			return(0);//nao eh tag
		}
	}
}