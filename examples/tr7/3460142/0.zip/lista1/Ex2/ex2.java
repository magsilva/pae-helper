/*Marcelo Kenji Hotta
 *3460142
 *kenji@grad.icmc.usp.br*/



/*Classe Ex2
 *Esta classe contem o main. Instancia as outras classes e imprime o resultado*/
class Ex2 {
    public static void main(String[] args) {
    	//declaracao e instanciacao dos objetos para teste
    	ConjuntoInteiros A = new ConjuntoInteiros();
		ConjuntoInteiros B = new ConjuntoInteiros();
		
		
		A.Add(1); 
    	A.Add(-1); 
    	A.Add(0); 
    	
    	B.Add(1); 
    	B.Add(-1); 
    	B.Add(1000); 
    	B.Add(-1000); 
    	
    	
    	//Testes
    	System.out.println("A:\t" + A.Print() + "\t\t\tantes");
    	System.out.println("B:\t" + B.Print() + "\tantes");
		System.out.println("----------------------------------------------");
    	System.out.println("A\\/B:\t" + A.Uniao(B).Print() + "\tuniao");
    	System.out.println("A/\\B:\t" + A.Interseccao(B).Print() + "\t\t\tinterseccao");
    	System.out.println("A-B:\t" + A.Subtracao(B).Print() + "\t\t\t\ta - b");
    	System.out.println("B-A:\t" + B.Subtracao(A).Print() + "\t\tb - a");
    	System.out.println("----------------------------------------------");
    	System.out.println("A:\t" + A.Print() + "\t\t\tdepois");
    	System.out.println("B:\t" + B.Print() + "\tdepois");
    	
	}
}



/*classe ConjuntoInteiros
 *Armazena no array de inteiros X*/
class ConjuntoInteiros {
	int[] X = {};
	ConjuntoInteiros(){
	}
	
	//metodo para adicionar elemento se nao houver
	void Add(int input){
		if(!Pertence(input)){
			poe(input);
		}
	}
	
	//metodo para remover elemento se existir
	void Rem(int input){
		if(Pertence(input)){
			tira(input);
		}
	}
	
	//metodo para adicionar um elemento
	void poe(int input){
		int[] Y = new int[X.length+1];
		for(int i=0; i<X.length; i++){
			Y[i] = X[i];
		}
		Y[X.length] = input;
		X = Y;
	}
	
	//metodo para remover elemento
	void tira(int input){
		int[] Y = new int[X.length-1];
		for(int i=0, j=0; i<X.length; i++){
			if(input != X[i]){
				Y[j] = X[i];
				j++;
			}
		}
		X = Y;
	}

	//metodo que retorna a Uniao dos conjuntos
	ConjuntoInteiros Uniao(ConjuntoInteiros Otro){
		ConjuntoInteiros resultado = new ConjuntoInteiros();
		for(int i=0; i<this.N(); i++){
			resultado.Add(this.X[i]);
		}
				
		for(int i=0; i<Otro.N(); i++){
			resultado.Add(Otro.X[i]);
		}
		
		return(resultado);
	}

	//metodo que retorna a Subtracao dos conjuntos
	ConjuntoInteiros Subtracao(ConjuntoInteiros Otro){
		ConjuntoInteiros resultado = new ConjuntoInteiros();
		for(int i=0; i<this.N(); i++){
			resultado.Add(this.X[i]);
		}
		
		for(int i=0; i<Otro.N(); i++){
			resultado.Rem(Otro.X[i]);
		}
		return(resultado);
	}
	
	//metodo que retorna a Interseccao dos conjuntos
	ConjuntoInteiros Interseccao(ConjuntoInteiros Otro){
		ConjuntoInteiros resultado = new ConjuntoInteiros();
		
		ConjuntoInteiros A = new ConjuntoInteiros();
		for(int i=0; i<this.N(); i++){
			A.Add(this.X[i]);
		}
		
		ConjuntoInteiros AmenosB = new ConjuntoInteiros();
		for(int i=0; i<this.N(); i++){
			AmenosB.Add(this.X[i]);
		}
		for(int i=0; i<Otro.N(); i++){
			AmenosB.Rem(Otro.X[i]);
		}
		
		
		resultado = A.Subtracao(AmenosB);
		
		return(resultado);
	}
	
	//metodo que retorna o conteudo do conjunto
	String Print(){
		String resultado = "(  ";
		for (int i=0; i<X.length; i++){
			resultado = resultado + X[i] + ", ";
		}
		resultado = resultado.substring(0, resultado.length()-2) + "  )";
		return(resultado);
	}
	
	//metodo que verifica se o elemento pertence ao conjunto
	boolean Pertence(int input){
		boolean resultado = false;
		for(int i=0; i<X.length && !resultado; i++){
			if(input == X[i]) resultado = true;
		}
		return(resultado);
	}
	
	//metodo que retorna a quantidade de elementos no conjunto
	int N(){
		return(X.length);
	}
}