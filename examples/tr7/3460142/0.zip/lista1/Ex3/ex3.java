/*Marcelo Kenji Hotta
 *3460142
 *kenji@grad.icmc.usp.br


	Para solucionar o problema anterior utilizando alguma classe da interface
Set, eu escolheria a HashSet para estender.
	Esta classe ja contem os metodos de adicao e remocao de elementos, levando
em consideracao que nao pode haver repeticao, e soh pode remover caso ele exista
	Ao estender, bastaria implementar os metodos de unicao, interseccao e 
subtracao. Esta classe tambem possui o metodo clone(), que permite a copia das
instancias, nao precisando copiar atributo por atributo quando quiser copiar o 
objeto todo.
	Tentei usar o clone() no exercicio anterior, mas nao consegui :| (nem sei se
eh possivel)
	A Vantagem de usar a classe existente eh a rapidez, reutilizacao de codigo,
produtividade, etc...  A unica vantagem de fazer sem usar classes pre-definidas
eh que voce sabe exatamente como a classe que vc criou funciona e foi desenvolvida
exclusivamente para o problema. Apesar de toda a documentacao sobre as bibliotecas
Java, nao dah para saber tudo sobre suas classes.
*/


class Ex3 {
    public static void main(String[] args) {
		System.out.println("\tMarcelo Kenji Hotta");
		System.out.println("\t3460142");
		System.out.println("\tkenji@grad.icmc.usp.br\n");
		System.out.println("\tPara solucionar o problema anterior utilizando alguma classe da interface Set, eu escolheria a HashSet para estender.");
		System.out.println("\tEsta classe ja contem os metodos de adicao e remocao de elementos, levando em consideracao que nao pode haver repeticao, e soh pode remover caso ele exista");
		System.out.println("\tAo estender, bastaria implementar os metodos de unicao, interseccao e subtracao. Esta classe tambem possui o metodo clone(), que permite a copia das instancias, nao precisando copiar atributo por atributo quando quiser copiar o objeto todo.");
		System.out.println("\tTentei usar o clone() no exercicio anterior, mas nao consegui :| (nem sei se eh possivel)");
		System.out.println("\tA Vantagem de usar a classe existente eh a rapidez, reutilizacao de codigo, produtividade, etc...  A unica vantagem de fazer sem usar classes pre-definidas eh que voce sabe exatamente como a classe que vc criou funciona e foi desenvolvida exclusivamente para o problema. Apesar de toda a documentacao sobre as bibliotecas Java, nao dah para saber tudo sobre suas classes.");
	}
}
