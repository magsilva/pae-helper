/*
 * SCE-213: Programa��o Orientada a Objetos
 * Bacharelado em Ci�ncias de Computa��o
 * Professora Renata Pontin M. Fortes
 *
 * Exerc�cio de JAVA 1.2.
 *
 * Anderson Sumitomo Otuka  - 3542803
 * Jefferson Otuka Kuramoto - 3529760
 *
 */

class Programa1_2 {
   public static void main(String argv[]) {
      // Cria um array z1 para gerar um C.I. x a partir dele
      int[] z1 = {1,5,8,9,5,3,2,1,5,8,9,6,5,4,2,1,3,6,8,9,4,6,8};
      ConjuntoInteiros x = new ConjuntoInteiros(z1);
      // Realiza opera��es com x
      System.out.print("O conjunto principal eh este:\nx = ");
      x.imprime();
      System.out.print("\nInserindo numero 7...\nx = ");
      x.insElem(7);
      x.imprime();
      System.out.print("\nRemovendo numero 3...\nx = ");
      x.remElem(3);
      x.imprime();
      System.out.print("\nUniao com y = ");
      
      // Cria um array z2 para gerar um C.I. y a partir dele
      int[] z2 = {1,5,8,9,12,15,18,1,6,7};
      ConjuntoInteiros y = new ConjuntoInteiros(z2);
      // Realiza opera��es com x e y
      y.imprime();
      x.uniao(y);
      System.out.print("x = ");
      x.imprime();
      System.out.print("\nInterseccao com w = ");
      
      // Cria um array z3 para gerar um C.I. w a partir dele
      int[] z3 = {1,5,67,8,9,12,99,15,18,10023};
      ConjuntoInteiros w = new ConjuntoInteiros(z3);
      // Realiza opera��es com x e w
      w.imprime();
      x.intersec(w);
      System.out.print("x = ");
      x.imprime();
      System.out.print("\nSubtraindo m = ");
      
      // Cria um array z4 para gerar um C.I. m a partir dele
      int[] z4 = {6,12,18};
      ConjuntoInteiros m = new ConjuntoInteiros(z4);
      m.imprime();
      // Realiza opera��es com x e m
      x.sub(m);
      System.out.print("x = ");
      x.imprime();
      System.out.print("\n");
   }
}


class ConjuntoInteiros extends Object {
   int[] lista;

   public ConjuntoInteiros(int[] l) {
      // nElem = n�mero de elementos efetivamente usados no array
      int nElem = 0;
      // Cria um conjunto com o mesmo tamanho da lista de entrada.
      // Guarda os numeros nao-repetidos da lista no conjunto. 
      this.lista = new int[l.length];
      for (int i = 0; i < l.length; i++) {
         if (!this.contemNum(l[i])) {
            this.lista[nElem] = l[i];
            nElem++;
         }
      }

      // Os numeros repetidos nao foram armazenados no conjunto,
      // mas ha memoria desperdicada reservada para eles... 
      
      // Ajusta o tamanho do conjunto, com uso de uma lista auxiliar
      // OBS: Esta tecnica eh utilizada em varios metodos adiante
      int[] aux = new int[nElem];
      for (int i = 0; i < aux.length; i++)
         aux[i] = this.lista[i];
         
      this.lista = aux;
   }

   protected int retTamanho() {
      return this.lista.length;
   }
 
   protected int retElem(int n) {
      return this.lista[n];
   }
 
   protected boolean contemNum(int n) {
      boolean resp = false;
      for (int i = 0; i < this.retTamanho(); i++) {
         if (n == this.lista[i]) 
            resp = true;
      }
      return resp;
   }

   protected boolean insElem(int n) {
      if (this.contemNum(n))
         return false;
      else {
         int[] aux = new int[(this.retTamanho() + 1)];
         for (int i = 0; i < this.retTamanho(); i++)
            aux[i] = this.lista[i];
            
         aux[(aux.length - 1)] = n;
         this.lista = aux;
         return true;
      }
   }

   protected boolean remElem(int n) {
      if (!this.contemNum(n))
         return false;
      else {
         int nElem = 0;
         int[] aux = new int[(this.retTamanho() - 1)];
         for (int i = 0; i < this.retTamanho(); i++) {
            if (this.lista[i] != n) {
               aux[nElem] = this.lista[i];
               nElem++;
            }
         }
         this.lista = aux;      
         return true;
      }
   }
   
   protected void uniao(ConjuntoInteiros l) {
      for (int i = 0; i < l.retTamanho(); i++)
         this.insElem(l.retElem(i));
   }

   protected void sub(ConjuntoInteiros l) {
      for (int i = 0; i < l.retTamanho(); i++)
         this.remElem(l.retElem(i));
   }

   protected void intersec(ConjuntoInteiros l) {
      int nElem = 0, maiorTamanho;
      // A lista auxiliar tem o tamanho igual a maior das duas listas
      if (this.retTamanho() > l.retTamanho())
         maiorTamanho = this.retTamanho();
      else
         maiorTamanho = l.retTamanho();
      
      int[] aux = new int[maiorTamanho];

      // Lista auxiliar guarda os valores em comum nas listas
      for (int i = 0; i < l.retTamanho(); i++) 
         for (int j = 0; j < this.retTamanho(); j++) 
            if (this.retElem(j) == l.retElem(i)) {
               aux[nElem] = l.retElem(i);
               nElem++;
            }
         
      this.lista = new int[nElem];
      for (int i = 0; i < this.retTamanho(); i++)
         this.lista[i] = aux[i];
   }

   protected void imprime() {
      // Imprime o conjunto, com formatacao simples
      System.out.print("[");
      for (int i = 0; i < this.retTamanho(); i++) { 
         if (i == 0)
            System.out.print(this.lista[i]);
         else
            System.out.print("," + this.lista[i]);
      }
      System.out.print("]\n");
   }
}