/*
 * SCE-213: Programa��o Orientada a Objetos
 * Bacharelado em Ci�ncias de Computa��o
 * Professora Renata Pontin M. Fortes
 *
 * Exerc�cio de JAVA 1.1.
 *
 * Anderson Sumitomo Otuka  - 3542803
 * Jefferson Otuka Kuramoto - 3529760
 *
 */

class Programa1_1 {
   public static void main(String argv[]) {
      Texto testef = new Texto("Teste de uso de <TAGS> em POO\ne processamento de <problemas com <mau> uso <de> tags?");
      System.out.println("* Conteudo de entrada *");
      testef.imprime();
      System.out.println("\n* Processamento de TAGS *");
      testef.info();
      System.out.println();
   }
}


class Palavra extends Object implements Const1_1 {
   String conteudo;
   int tag;
   
   public Palavra(String stream) {
      this.conteudo = stream;
      this.classificaTag();
   }
   
   public String toString() {
      return this.conteudo;
   }
   
   public int tipoTag() {
      return this.tag;
   }
   
   public void imprime() {
      System.out.println(this);
   }

   private void classificaTag() {
      if (this.conteudo.charAt(0) != '<')
         this.tag = NOTAG;
      else
         if (this.conteudo.charAt(this.conteudo.length() - 1) != '>')
            this.tag = TAGNG;
         else
            this.tag = TAGOK;
   }
}


class Frase extends Object implements Const1_1 {
   Palavra[] arrayPalavras;
   int numPalavras = 0;
   
   public Frase(String stream) {
      this.contaPalavras(stream);
      this.divideEmPalavras(stream);
   }

   public String toString() {
      String stream = "";
      for (int i = 0; i < this.numPalavras; i++)
         stream += this.arrayPalavras[i] + ((i < this.numPalavras - 1) ? " " : "");
      return stream;
   }
   
   public int nPalavras() { 
      return this.numPalavras;
   }

   public void imprime() {
      System.out.println(this);
   }

   public String palavra(int indice) {
      // Retorna uma string com a palavra do indice dado
      if ((indice >= 0) & (indice < this.numPalavras))
         return this.arrayPalavras[indice].toString();
      else
         return "Indice invalido.";
   }

   private void contaPalavras(String stream) {
      int i, n = stream.length();
      this.numPalavras = 1;
      for (i = 0; i < n; i++) {
         if (stream.charAt(i) == ' ')
           this.numPalavras++;
      }
   }

   private void divideEmPalavras(String stream) {
      int iPalavra = 0;
      int i, nChars = stream.length();
      String buffer = "";
      this.arrayPalavras = new Palavra[this.numPalavras];
      
      // Insere da primeira at� a pen�ltima palavra em um array de palavras
      for (i = 0; i < nChars; i++) {
         if (stream.charAt(i) != ' ')
           buffer += stream.charAt(i);
         else {
            this.arrayPalavras[iPalavra] = new Palavra(buffer);
            iPalavra++;
            buffer = "";
         }
      }
      
      // Armazena a �ltima palavra no array tamb�m
      this.arrayPalavras[iPalavra] = new Palavra(buffer);
   }

   public void info() {
      String stringTagsOK = "";
      int tagsNG = 0, tagsOK = 0;

      // Contagem dos tags e armazenamento do nome dos validos
      for (int i = 0; i < this.numPalavras; i++) {
         if (this.arrayPalavras[i].tipoTag() == TAGNG)
            tagsNG++;
         else if (this.arrayPalavras[i].tipoTag() == TAGOK) {
            tagsOK++;
            stringTagsOK += this.arrayPalavras[i];
         }
      }
      
      System.out.println(numPalavras + " palavras - " + tagsOK + " tags validas (" + stringTagsOK + ") - " +
                         tagsNG + " tags invalidas");
   }
}


class Texto extends Object {
   Frase[] arrayFrases;
   int numFrases = 0;
   
   public Texto(String stream) {
      this.contaFrases(stream);
      this.divideEmFrases(stream);
   }

   public String toString() {
      String stream = "";
      for (int i = 0; i < this.numFrases; i++)
         stream += this.arrayFrases[i] + ((i < this.numFrases - 1) ? "\n" : "");
      return stream;
   }
   
   public int nFrases() { 
      return this.numFrases;
   }
   
   public void imprime() {
      System.out.println(this);
   }

   public String frase(int indice) {
      // Retorna uma string com a frase do indice dado
      if ((indice >= 0) & (indice < this.numFrases))
         return this.arrayFrases[indice].toString();
      else
         return "Indice invalido.";
   }
   
   private void contaFrases(String stream) {
      int i, n = stream.length();
      this.numFrases = 1;
      for (i = 0; i < n; i++) {
         if (stream.charAt(i) == '\n')
         this.numFrases++;
      }
   }

   private void divideEmFrases(String stream) {
      int iFrase = 0;
      int i, nChars = stream.length();
      String buffer = "";
      this.arrayFrases = new Frase[this.numFrases];
      
      // Insere da primeira at� a pen�ltima frase em um array de frases
      for (i = 0; i < nChars; i++) {
         if (stream.charAt(i) != '\n')
           buffer += stream.charAt(i);
         else {
            this.arrayFrases[iFrase] = new Frase(buffer);
            iFrase++;
            buffer = "";
         }
      }
      
      // Armazena a �ltima frase no array tamb�m
      this.arrayFrases[iFrase] = new Frase(buffer);
   }
   
   public void info() {
      for (int i = 0; i < this.numFrases; i++) {
         System.out.print("frase " + (i+1) + " - ");
         this.arrayFrases[i].info();
      }
   }  
}
      