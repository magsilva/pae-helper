public interface Const1_1 {
   final int ID_TEXTO = 0;
   final int ID_FRASE = 1;
   final int ID_PALAV = 2;
   final int ID_TAGOK = 3;
   final int ID_TAGNG = 4;

   final int NOTAG = 0;
   final int TAGOK = 1;
   final int TAGNG = 2;
}