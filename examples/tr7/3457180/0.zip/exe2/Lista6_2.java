/* Programacao Orientada a Objetos
   Lista de Exercicios 6
   Exercicio 2

   Lucas Antiqueira  , 3457180
   Cleber Castro Hage, 3560345
*/

import java.util.*;

//Classe que implementa o comportamento de um conjunto de numeros inteiros.
// Nela, numeros repetidos nao podem ser adicionados e somente numeros
// inteiros podem ser adicionados, como especificado no parametro num do metodo adiciona.
// Os outros metodos implementados no exercicio tambem estao presentes.
class ConjuntoInteiros {

	//Para armazenar os numeros inteiros, a classe Vector eh utilizada
	private Vector vec = new Vector();

	public void adiciona (int num) {
		Integer aux = new Integer(num);
		if (!vec.contains(aux))
			vec.add(aux);
	}

	public void remove (int num) {
		vec.remove(new Integer(num));
	}

	public void imprime () {
		int i;
		for (i = 0; i < vec.size(); i++)
			System.out.print(vec.elementAt(i) + " ");
		System.out.println();
	}

	private int elemento (int i) {	//Retorna o elemento na posicao i
		Integer aux = new Integer(vec.elementAt(i).toString());
		return aux.intValue();
	}

	public ConjuntoInteiros uniao (ConjuntoInteiros outroConj) {
		ConjuntoInteiros aux = new ConjuntoInteiros();
		int i;

		for (i = 0; i < vec.size(); i++)
			aux.adiciona(elemento(i));

		for (i = 0; i < outroConj.vec.size(); i++)
			aux.adiciona(outroConj.elemento(i));

		return aux;
	}

	public ConjuntoInteiros interseccao (ConjuntoInteiros outroConj) {
		ConjuntoInteiros aux = new ConjuntoInteiros();
		int i;

		for (i = 0; i < vec.size(); i++) {
			if (outroConj.vec.contains(vec.elementAt(i)))
				aux.adiciona(elemento(i));
		}

		return aux;
	}

	public ConjuntoInteiros diferenca (ConjuntoInteiros outroConj) {
		ConjuntoInteiros aux = new ConjuntoInteiros();
		int i;

		for (i = 0; i < vec.size(); i++) {
			if (!outroConj.vec.contains(vec.elementAt(i)))
				aux.adiciona(elemento(i));
		}

		return aux;
	}
}

class Lista6_2 {
	public static void main (String[] Args) {
		ConjuntoInteiros conj1 = new ConjuntoInteiros();
		ConjuntoInteiros conj2 = new ConjuntoInteiros();
		int i;

		conj1.adiciona(30);
		conj1.adiciona(56);
		conj1.adiciona(90);
                conj1.adiciona(200);
		conj1.adiciona(10);
                conj1.adiciona(90);
		conj1.adiciona(87);
                conj1.remove(200);
		System.out.print("Conjunto A:      ");
		conj1.imprime();

		conj2.adiciona(65);
		conj2.adiciona(76);
                conj2.adiciona(65);
		conj2.adiciona(40);
		conj2.adiciona(90);
		conj2.adiciona(100);
		conj2.adiciona(56);
		System.out.print("Conjunto B:      ");
		conj2.imprime();

		System.out.print("A Uniao B:       ");
		conj1.uniao(conj2).imprime();
		System.out.print("A Interseccao B: ");
		conj1.interseccao(conj2).imprime();
		System.out.print("A Diferenca B:   ");
		conj1.diferenca(conj2).imprime();

	}
}
