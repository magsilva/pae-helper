/* Programacao Orientada a Objetos
   Lista de Exercicios 6
   Exercicio 1

   Lucas Antiqueira  , 3457180
   Cleber Castro Hage, 3560345
*/

import java.io.*;

//O texto eh lido de um arquivo. A classe abaixo recebe no
// construtor o nome do arquivo a ser lido e fornece o
// metodo leLinha, o qual retorna uma frase do arquivo.
class Texto {
	private BufferedReader arqEntrada;
	Texto(String nome) throws FileNotFoundException {
		arqEntrada = new BufferedReader(new FileReader(nome));
	}
	String leLinha() throws IOException {
		return arqEntrada.readLine();
	}
}


//Esta classe instancia um objeto da classe Texto, para leitura do arquivo,
// e apresenta as informacoes de saida (metodo Avalia), utilizando as
// classes Palavras e Tags.
class Frases {
	private Texto texto;
	private Palavras words = new Palavras();
	private Tags tags = new Tags();
	private int numLines = 0;

	Frases(String nome) throws FileNotFoundException {
		texto = new Texto(nome);
	}

	void Avalia() throws IOException {
		String line;
		line = texto.leLinha();
		while (line != null) {
			numLines++;
			System.out.println("Linha: " + numLines + " - " + words.total(line) + " palavras - " + tags.total(line) + " tags (" + tags.display(line) + ") - " + tags.erros(line) + " tags problema");
			line = texto.leLinha();
		}
	}
}

//Esta classe apresenta um unico metodo, o qual
// conta o numero de palavras numa frase.
class Palavras {
	int total (String frase){
		int numWords = 0;
		boolean inWord = false;
		int i = 0;
		while (i < frase.length()) {
			if (!Character.isWhitespace(frase.charAt(i))) {
				if (!inWord) {
					inWord = true;
					numWords += 1;
				}
			} else {
				if (inWord)
					inWord = false;
			}
			i += 1;
		}
		return numWords;
	}
}


//Nesta classe encontram-se os metodos total, erros e display.
// O metodo total conta o numero de tags numa frase; o metodo erros
// conta o numero de tags inconsistentes numa frase; e o metodo display
// retorna uma String contendo as tags corretas de uma frase.
class Tags {
	int total (String frase) {
		int numTags = 0;
		boolean inTag = false;
		int i = 0;
		while (i < frase.length()) {
			if (frase.charAt(i) == '<') {
				if (!inTag)
					inTag = true;
			} else if (frase.charAt(i) == '>') {
				if (inTag) {
					inTag = false;
					numTags += 1;
				}
			}
			i += 1;
		}		
		return numTags;
	}

	int erros (String frase) {
		int numErros = 0;
		boolean inTag = false;
		int i = 0;		
		while (i < frase.length()) {
			if (frase.charAt(i) == '<') {
				if (inTag)
					numErros += 1;
				inTag = true;
			} else if (frase.charAt(i) == '>') {
				if (!inTag)
					numErros += 1;
				inTag = false;
			}
			i += 1;
		}
		if (inTag)
			numErros += 1;
		return numErros;
	}

	String display (String frase) {
		boolean inTag = false;
		int i = 0;
		String str = new String();
		String aux = new String();
		while (i < frase.length()) {
			if (frase.charAt(i) == '<') {
				if (inTag)
					aux = "";
				inTag = true;
			} else if (frase.charAt(i) == '>') {
				if (inTag) {
					str += aux + '>';
					aux = "";
				}
				inTag = false;
			}
			if (inTag)
				aux += frase.charAt(i);
			i += 1;
		}		
		return str;
	}
}

public class Lista6_1 {
	public static void main(String[] args) throws FileNotFoundException, IOException {
		Frases frasesLidas = new Frases("Lista6_1.txt");
		System.out.println("Texto lido do arquivo: Lista6_1.txt");
		frasesLidas.Avalia();
	}
}