/* Programacao Orientada a Objetos
   Lista de Exercicios 6
   Exercicio 3

   Lucas Antiqueira  , 3457180
   Cleber Castro Hage, 3560345
*/

import java.util.*;

//Utilizamos a classe HashSet para estender. Criamos o metodo adiciona,
// para receber apenas inteiros, e o metodo remove, pelo mesmo motivo.
// Criamos o metodo imprime utilizando o metodo toString.
// Para as outras funcionalidades de um conjunto, utilizamos os seguintes
// metodos da classe HashSet:
//  addAll    -> uniao
//  retainAll -> interseccao
//  removeAll -> diferenca
//
// Na solucao do exercicio 2, podemos implementar o conjunto com uma estrutura
// personalizada, a qual demanda mais codigo a ser implementado. Nesta nova
// solucao, varios metodos ja estao prontos, mas eles podem nao satisfazer
// as necessidades especificas de determinada aplicacao.
class ConjuntoInteiros extends HashSet {
        void adiciona (int i) {
                super.add(new Integer(i));
        }

        void remove (int i) {
                super.remove(new Integer(i));
        }

        void imprime () {
                System.out.println(toString());
        }
}

class Lista6_3 {
	public static void main (String[] Args) {
		ConjuntoInteiros conj1 = new ConjuntoInteiros();
		ConjuntoInteiros conj2 = new ConjuntoInteiros();
                ConjuntoInteiros aux = new ConjuntoInteiros();
		int i;

                conj1.adiciona(30);
		conj1.adiciona(56);
		conj1.adiciona(90);
                conj1.adiciona(200);
                conj1.adiciona(10);
                conj1.adiciona(90);
		conj1.adiciona(87);
                conj1.remove(200);

                aux.addAll(conj1);

		System.out.print("Conjunto A:      ");
                conj1.imprime();

		conj2.adiciona(65);
		conj2.adiciona(76);
                conj2.adiciona(65);
		conj2.adiciona(40);
		conj2.adiciona(90);
		conj2.adiciona(100);
		conj2.adiciona(56);
		System.out.print("Conjunto B:      ");
                conj2.imprime();

                System.out.print("A Uniao B:       ");
                conj1.addAll(conj2);
                conj1.imprime();
                conj1.clear();
                conj1.addAll(aux);

                System.out.print("A Interseccao B: ");
                conj1.retainAll(conj2);
                conj1.imprime();
                conj1.clear();
                conj1.addAll(aux);

                System.out.print("A Diferenca B:   ");
                conj1.removeAll(conj2);
                conj1.imprime();

	}
}
