/*
 *	Exercio numero 1.1 da Lista de Exercicio 6 de Java.
 *	Prof. Renata Pontim.
 *	
 *	Autor: 	
 *		Breno Leitao
 *		Jonatas Kerr
 *
 *	Foi utilizado a versao beta (1.4.2) do Java para a elaboracao 
 *					              desse trabalho.
 *
*/  

import java.io.*;
import java.util.*;


class init{
	public static void main(String[] args){
		int tag=0;
		int valid_tag= 0;
		int line_number = 0;
		int palavra = 0;
		String linha = new String();
		io file = new io();
		try{
			io.open("tag.txt");
		}
		catch(FileNotFoundException e){
			System.err.println("file not found!");
			System.exit(1);
		}

		while (io.available()){
			line_number++;
			linha = io.getLine();
			Text txt = new Text(linha); /* Let's tokenizer */	
			Word word = new Word(); /* Will make the tag tests */
			while (txt.hasMore()){
				String a = new String(txt.getToken());
				word.put(a);
				if (!word.isTag()) {/* Is not a tag */
					//System.out.print(a+" ");
					palavra++;
				}
				else{
					tag++;
					if (word.validTag())
						valid_tag++;
				}
			}
			System.out.print("A linha "+line_number+
				" contem "+palavra+" palavras e "
				+tag+" tags. Sendo "+valid_tag+" validas.\n");

			palavra=0; tag=0; valid_tag=0;
		}
		System.exit(0);
	}
}

class Word{
	String word;
	public boolean isTag(){
		if (word.charAt(0) == '<')
			return true;
		else 
			return false;	
	}
	public void put(String wd){
		word = new String(wd);
	}
	public boolean validTag(){
		if (hm_greater() == hm_minor())
			return true;
		else
			return false;	
	}
	protected int hm_minor(){
		int hm=0;
		for (int i = 0; i <= word.length()-1; i++)
			if (word.charAt(i) == '<')
				hm++;
		return hm;
	}
	protected int hm_greater(){
		int hm=0;
		for (int i = 0; i <= word.length()-1; i++)
			if (word.charAt(i) == '>')
				hm++;
		return hm;
	}
}

class Text{
	StringTokenizer tok;
	String texto;
	public Text(String txt){
		texto = new String(txt);
		tok = new StringTokenizer(texto);
	}
	public String getToken(){
		if (tok.hasMoreTokens())
			return tok.nextToken();
		else 
			return "";
	}

	public boolean hasMore(){
		return tok.hasMoreTokens();
	}

	boolean isTag(String pal){
		return true;	
	}
}

class io{
	static BufferedReader in;
	static String output = new String("");
	public static void open(String file) throws FileNotFoundException{ 
		in = new BufferedReader(new FileReader(file));
	}

	public static String getLine(){
		output = new String("");
		try{
			if (in.ready()) /* ?there is available line? */
				output += in.readLine();
		}
		catch(IOException ioe){
			System.err.println("I/O Error. Don't be pissed off");
		}
		return output;
	}

	public static boolean available(){     /* an alias */
		try{
			return in.ready();
		}
		catch(IOException ioe){
			return false;
		}
	}
}
