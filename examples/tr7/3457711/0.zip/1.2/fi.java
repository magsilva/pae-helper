/* 
 *  Trabalho 1.2 da Lista de Exercicio Java *
 *  Compilado e testado com o j2sdk_1.4.2   *
 *  					    *
 *					    *
 * Autor: Breno H. Leitao 		    *
 */

import java.util.*;
import java.io.*;

import java.io.*;
class first{
	public static void main(String[] args){
		conj_int i = new conj_int();
		conj_int j = new conj_int();

		/* atualizando i */
		System.out.println("Conjunto 1");
		i.interativo_adiciona();
		i.add_int("10");        /* Exemplo */
		i.add_int("12");	/* Exemplo */
		i.print_list();

		System.out.println("\nConjunto 2");
		
		/* Atualizando o j */
		j.interativo_adiciona();
		j.add_int("11");        /* Exemplo */
		j.add_int("12");        /* Exemplo */
		j.add_int("13");	/* Exemplo */
		j.print_list();

		System.out.println("\nSoma");
		i.soma(j).print_list();
		
		System.out.println("\nSubtracao");
		i.subtracao(j).print_list();
		
		System.out.println("\nUniao");
		i.uniao(j).print_list();
		
		System.out.println("\nInterseccao");
		i.inter(j).print_list();
		
	}
}

class conj_int{
	/* Classe de proposito geral para trabalhar com um conjunto de numeros inteiros */
	Vector AllInt = new Vector();
	
	
	public static int read(){
		String a = new String();
		BufferedReader bufread = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Digite o Numero: ");
		try{
			a = bufread.readLine();
		}
		catch (IOException e){
			System.err.println("I/O Error\n");
			return 0;
		}
		try{
			return Integer.parseInt(a);
		}
		catch (NumberFormatException e){
			System.err.print("A entrada nao eh um inteiro\n");	
			/* ?Como cancelar o fluxo? */
			return 0;
		}
	}


	public conj_int subtracao(conj_int other){
		conj_int tmp =  new conj_int();
		boolean other_smaller;
		other_smaller = false;
		int i = 0;

		int menor_tamanho = tamanho();
		other_smaller = false;
		if (other.tamanho() < menor_tamanho)
			menor_tamanho = other.tamanho();
			other_smaller = true;  

		if (false)
			System.out.println("Menor tamanho: " + menor_tamanho);
		for (i = 0; i<= menor_tamanho-1; i++){
			tmp.add(index(i) - other.index(i));	
		}
		if (other_smaller == false){   /* Esse eh o maior */
			for (;i<=tamanho()-1; i++)
				tmp.add(index(i));
		}
		else{
			for (;i<=other.tamanho()-1; i++)
				tmp.add(-other.index(i));
		}
		tmp.print_all();
		return tmp;
	}

	public conj_int soma(conj_int other){
		conj_int tmp =  new conj_int();
		boolean other_smaller;
		other_smaller = false;
		int i = 0;

		int menor_tamanho = tamanho();
		other_smaller = false;
		if (other.tamanho() < menor_tamanho)
			menor_tamanho = other.tamanho();
			other_smaller = true;  

		System.out.println("Menor tamanho: " + menor_tamanho);
		for (i = 0; i<= menor_tamanho-1; i++){
			tmp.add(index(i) + other.index(i));	
		}
		if (other_smaller == false){   /* Esse eh o maior */
			for (;i<=tamanho()-1; i++)
				tmp.add(index(i));
		}
		else{
			for (;i<=other.tamanho()-1; i++)
				tmp.add(other.index(i));
		}
		tmp.print_all();
		return tmp;
	}
	public conj_int inter(conj_int other){
		conj_int tmp = new conj_int();
		for (int i = 0; i<= tamanho()-1; i++){
			if (other.contem(index(i)))
				tmp.add(index(i));
		}
		return tmp;
	}
	public conj_int uniao(conj_int other){
		conj_int tmp = new conj_int();
		for (int i = 0; i<= tamanho()-1; i++){
			tmp.add(index(i));
		}
		for (int i = 0; i<= other.tamanho()-1; i++){
			tmp.add(other.index(i));
		}
		return tmp;
	}

	
	public void interativo_adiciona(){
		add(read());
	}
	
	public void add(int n){           /* Polimorfismo */
		this.add_int(Integer.toString(n));
	}

	public void add(String st){      /* Polimorfismo */
		this.add_int(st);
	}

	public boolean contem(int n){
		if (AllInt.contains(Integer.toString(n)))
			return true;
		else
			return false;
	}
	public void add_int(String num){
		if (AllInt.contains(num)){     /* Checando se jah contem */
			System.err.println("O conjunto jah contem o inteiro "+num);
		}
		else{
			if (false)
				System.err.println("Inserindo o inteiro "+num);
			AllInt.addElement(num);
		}
	}
	public void print_first(){
		System.out.println(AllInt.firstElement());
	}
	public void print_all(){
		System.out.print("Lista dos elementos do conjunto: ");
		for(int i=0; i<AllInt.size();i++){
			System.out.print(AllInt.get(i)+" ");
		}
		System.out.println("");
	}
	public void print_list(){
		System.out.println(AllInt.toString());
	}
	public int tamanho(){
		return AllInt.size();
	}
	public int index(int i){
		String a= AllInt.get(i).toString();
		return Integer.parseInt(a);
	}
	public Object remove(int i){
		return AllInt.remove(i);
	}
	public boolean remove(String num){
		return AllInt.remove(num);
	}
}
