import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class Janela extends JFrame {

	// Objeto da classe que faz o parser
	Parser parser;
	JTextArea campo;
	JLabel texto;
	
	Janela(Parser parser){
		this.setLocation(200,200);
		this.parser = parser;
		try{
			// Pra ficar com a cara do sistema operacional
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		} catch(Exception ex){
		}
		// Nao deixa maximizar a janela nem dar resize
		this.setResizable(false);
		// Arruma o titulo
		this.setTitle("SCE 213 - Trabalho 5");
		// Cria o painel
		JPanel panel = new JPanel();
		panel.setLayout(new BorderLayout());
		// Label com a instru��o
		texto = new JLabel("Digite a frase no campo abaixo e depois clique no bot�o:");
		campo = new JTextArea("",10,30);
		JScrollPane scroll = new JScrollPane(campo);
		// Cria o bot�o
		JButton botao = new JButton("Verifica");
		botao.addActionListener(new Valida());
		// Adiciona os componentes ao painel
		panel.add(texto,BorderLayout.NORTH);
		panel.add(scroll,BorderLayout.CENTER);
		panel.add(botao,BorderLayout.SOUTH);
		// Adiciona o painel ao frame
		this.getContentPane().add(panel);
		this.pack();
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	

	class Valida implements ActionListener{
		
		public void actionPerformed(ActionEvent e){
			// Pega o texto
			parser.frase = campo.getText();
			// Cria a janela pra mostrar o resultado
			JFrame resultado = new JFrame("Resultado");
			JPanel painel = new JPanel();
			painel.setLayout(new BorderLayout());
			JTextArea relat = new JTextArea("",20,70);
			JScrollPane scrl = new JScrollPane(relat);
			painel.add(scrl,BorderLayout.CENTER);
			resultado.getContentPane().add(painel);
			resultado.pack();
			resultado.setLocation(250,250);
			resultado.setVisible(true);

			// Chama a funcao de validacao, que tah na classe Parser e joga o resultado na janela de resultados
			relat.setText(parser.valida(parser.frase));
		}
		
	}
}

