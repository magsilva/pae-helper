class Parser{

	String frase;
	
	// Construtor
	Parser(){
		// Chama a classe que cont�m a interface gr�fica
		Janela jan = new Janela(this);	
	}
	
	public static void main(String args[]){
		
		// Instancia a propria a classe
		Parser parser = new Parser();
	}
	
	// Fun��o que faz a valida��o das tags, contagem de palavras, etc
	String valida(String texto){

		// Variavel que recebe TRUE qdo o texto encontra o caracter "<"
		boolean abriu = false;
		// Armazena o numero de linhas
		int linha = 0;
		// Armazena o numero de palavras
		int palavra = 0;
		// Armazena o numero de tags verdadeiras
		int tagV = 0;
		// Armazena o numero de tags invalidas
		int tagI = 0;
		// Armazena a posicao em que encontrou o caracter "<"
		int posicaoAnterior = 0;
		// Texto que serah impresso na janela de resultado
		String resultado="";
		// Armazena as tags validas
		String validas="";
		
		// Se o texto nao termina com "\n" acrescenta o mesmo ao texto
		if(texto.charAt(texto.length()-1)!='\n') texto = texto+"\n";

		// Loop para percorrer todos os caracteres do texto
		for(int i=0;i<texto.length();i++){
			// Se achou o caracter "<" armazena a posicao e a variavel ABRIU recebe TRUE
			if(texto.charAt(i)=='<'){
				posicaoAnterior = i;
				// Se achar o caracter "<" de novo sem a tag ter sido fechada, adiciona mais um ao contador de tag invalida da linha
				if(abriu) tagI++;
				else abriu = true;
			}
			else if(texto.charAt(i)==' '){
				// Se achar o espa�o depois de um caracter adiciona um ao contador de palavras
				if(i!=0&&texto.charAt(i-1)!=' ') palavra++;
				// Se a variavel ABRIU tinha TRUE, agora recebe FALSE e aumenta um ao contador de tags invalidas da linha
				if (abriu){
					abriu=false;
					tagI++;
				}
			}
			// Se acha o caracter ">"
			else if(texto.charAt(i)=='>'){
				// Se o caracter "<" estava no come�o da palavra, entao a tag estah correta
				if(abriu){
					// Aumenta um ao contador de tags validas na linha
					tagV++;
					// Guarda a tag valida
					validas = validas+texto.substring(posicaoAnterior,i+1);
					// Avisa que a tag foi fechada a variavel ABRIU
					abriu = false;
				}
				// Se achou o caracter ">" sem a tag ter sido aberta, entao acrescenta um ao contador de tags invalidas da linha
				else tagI++;
			}
			// Caso ache o final de linha
			else if(texto.charAt(i)=='\n'){
				if(i!=0&&texto.charAt(i-1)!=' ') palavra++;
				// Se a linha terminou com uma tag aberta que nao foi fechada, acrescenta um ao contador de tags invalidas da linha
				if (abriu) tagI++;
				linha++;
				// Guarda os resultados da linha na variavel que serah impressa na tela de resultados
				resultado = resultado+"Linha "+linha+" - "+palavra+" palavras - "+tagV+" tag(s) v�lida(s) ("+validas+") - "+tagI+" tag(s) inv�lida(s)\n";
				// "Zera" as variaveis para comecar a nova linha
				abriu=false;
				tagV=0;
				tagI=0;
				palavra=0;
				validas="";
			}
		}
		// Retorna o texto com o resultado
		return (resultado);
	}
	
}
