import java.awt.*;
import java.awt.event.*;
import java.util.StringTokenizer;
import javax.swing.*;
import javax.swing.text.*;
import javax.swing.event.*;

public class Tag extends JFrame {
    JTextPane painel;
    DefaultStyledDocument docArea;
    JTextArea resultArea;
    String whiteSpace = " ",newline = "\n";
    JButton OkButton, resetButton;

    

    public Tag() {
        
        super("TAGS");

        //Cria um componente tipo Document para Area de texto.
        docArea = new DefaultStyledDocument();
        
        // Cria novos botoes
        OkButton = new JButton( "OK" );
        resetButton = new JButton( "Reset" );
        resetButton.setToolTipText("Apaga frases e sa�das.");

        //Cria area de entrada das frases.
        painel = new JTextPane(docArea);  
        painel.setCaretPosition(0);
        painel.setMargin(new Insets(2,2,2,2));
        painel.setToolTipText("Frases s�o delimitadas por ponto final");

        //Barra de rolagem para area de texto
        JScrollPane scrollPane = new JScrollPane(painel);
        scrollPane.setPreferredSize(new Dimension(200,200));

        //Cria area de saida dos resultados
        resultArea = new JTextArea(5, 40);
        resultArea.setEditable(false);
        resultArea.setToolTipText("Sa�da");

        //Barra de texto para area de resultados
        JScrollPane scrollPaneForLog = new JScrollPane(resultArea);

        //Cria Barra de separacao entre area de entrada  e saida
        JSplitPane splitPane = new JSplitPane(
                                       JSplitPane.VERTICAL_SPLIT,
                                       scrollPane, scrollPaneForLog);
        splitPane.setOneTouchExpandable(false);

        //Cria Botoes
        JPanel buttonsPane = new JPanel(new GridLayout(1, 2));
        buttonsPane.add(OkButton);
        buttonsPane.add(resetButton);
        
        //Adiciona componentes ao Frame
        JPanel contentPane = new JPanel(new BorderLayout());
        contentPane.add(splitPane, BorderLayout.CENTER);
        contentPane.add(buttonsPane, BorderLayout.SOUTH);
        setContentPane(contentPane);
        
        //Evento : OkButton Acionado
        OkButton.addActionListener(
         new ActionListener() {
            public void actionPerformed( ActionEvent e ){  
            
            int tagRight     = 0, tagError      = 0,
                wordsCounter = 1, phraseCounter = 0;
            
             String stockPhrase ="" , slaveString = "";
             
             String output , bufferTagRight = "";
             
             try {stockPhrase = docArea.getText(0,docArea.getLength());}
             catch (BadLocationException ble) {
               System.err.println("erro");   }
             
             StringTokenizer tokens = new StringTokenizer(stockPhrase);
             
             while ( tokens.hasMoreTokens() ){
             	
             	slaveString = tokens.nextToken();
             	             	
             	if ( (slaveString.indexOf("<") != -1) && (slaveString.indexOf(">") != -1 ) ){
             		
             	     bufferTagRight += slaveString;
             	     tagRight++;}
             	     
                else if ((slaveString.indexOf("<") != -1) && (slaveString.indexOf(">") == -1 ) ) 
                	 tagError++;
                	 
                else if ((slaveString.indexOf("<") == -1) && (slaveString.indexOf(">") != -1 ) ) 
                     tagError++;
                     
                if (slaveString.indexOf(".") == - 1) wordsCounter++;
                     
                else { 
                    phraseCounter++;
                    output = "Resultados :\n\n FRASE  " +  phraseCounter + "- " +
                              wordsCounter+ " palavras - "    + 
                              tagRight     + " tags validas ( "+ bufferTagRight + " )  - "+
                              tagError     + " tags invalidas\n\n";
                              
                    resultArea.setFont( new Font( "Serif", Font.ITALIC, 12 ) );
                    resultArea.append( output );  
                    
                    tagRight     = 0;  tagError      = 0;
                    wordsCounter = 1;  
                    bufferTagRight="";
                    
                    }
                
             }
            }
             
         }
      );
        
        
        // Evento : Reset Pressionado
        resetButton.addActionListener(
         new ActionListener() {
            public void actionPerformed( ActionEvent e )
            { 
             SimpleAttributeSet atribs = new SimpleAttributeSet();
             StyleConstants.setBold(atribs, true);
             
             String output = "" ;
             
	         // 
	         try { 
	              docArea.remove(0,docArea.getLength());
                  docArea.insertString(0, output, atribs);
                  resultArea.setText(output);
             } 
             catch (BadLocationException ble) {
               System.err.println("Error");
             }

           }

         }
      );

    }

    //Main
    public static void main(String[] args) {
        final Tag frame = new Tag();
        frame.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
            public void windowActivated(WindowEvent e) {
                frame.painel.requestFocus();
            }
        });

        frame.pack();
        frame.setVisible(true);
    }
}
