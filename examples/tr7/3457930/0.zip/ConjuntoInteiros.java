


import java.util.*;
import java.io.*;


class ConjuntoInteiros extends Vector
{	
	private int elementInteger;
	Vector ConjA,ConjB;
	public ConjuntoInteiros()
	{
		ConjA = new Vector(100);
            ConjB = new Vector(40);
	}


	public void aditElement (int elementInteger)
	{
		Integer element = new Integer(elementInteger);
		if (vetor.contains(element))
				System.out.println("Elemento ja pertence ao ao conjunto");
		else vetor.addElement(element);

	}
	

	public void dell (int elementInteger){
		
		Integer element = new Integer(elementInteger);
		if (vetor.contains(element))
			vetor.removeElement(element);
		else System.out.println("Elemento nao pertence ao conjunto");
	}

	public void printConj(){
		System.out.println("Esse eh o vetor: " + ConjA);	
	}


	public Vector unionConj(ConjuntoInteiros conjB){
	
		Object ob = new Object();
		for(int i=0;i< conjB.size();i++){
			ob = conjB.elementAt(i);
			if (conjB.contains(ob) == false){
				vetor.addElement(ob);
			}
		}		
		return conjB;
	}

	public Vector inter(ConjuntoInteiros conjB){

		Vector conjC = new Vector(100);
		Object ob = new Object();
		len = conjB.size();
		for(int i=0;i<conjB.size;i++){
			ob = conjB.elementAt(i);
			if (conjB.contains(ob))
				vetorC.addElement(ob);
		}
		return conjC;
	}

	public Vector sub(ConjuntoInteiros conjB){
		
		Object ob = new Object();
		for(int i=0;i<conjB.size;i++){
			ob = conjB.elementAt(i);
			if (conjB.contains(ob))
				conjB.removeElement(ob);
		}
		return conjB;
	}


	public static void main(String[] args){
		ConjuntoInteiros a = new ConjuntoInteiros();
		ConjuntoInteiros b = new ConjuntoInteiros();
	
	}
	
}

