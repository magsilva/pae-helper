/** Lista de Exercic�os de POO - Java - Ex1.1
    Classe para contar o n�mero de palavras em cada linha de um texto,
    exibir as tags e o n�mero de tags v�lidas e inv�lidas. */    
    
import java.util.*;

public class CP {

	public static void main(String[] args) {

		//Texto de entrada
		String txt = "Teste de uso de <TAGS> em POO\ne processamento de <problemas com <mau> uso <de> tags?";

		Texto t = new Texto(txt);
		
		//Declara��o de vari�veis auxiliares		
		int contLinha = 0, contPalavra = 0, contTag = 0, contTInvalido = 0;
		String tags = "";
		String aux, aux2;
	
		Palavra p = new Palavra();
		
		//Procedimento para efetuar as contagens no texto
		while ((aux = t.proxima()) != ""){
			Frase f = new Frase(aux);
			contPalavra = 0; contTag = 0; contTInvalido = 0; tags = "";
			
			while ((aux2 = f.proxima()) != ""){
				contPalavra++;
				if (p.avalia(aux2) == "valido") {
					contTag++; 
					tags += aux2;
				} else if (p.avalia(aux2) == "invalido") {
					contTInvalido++; 
				}
			}
			System.out.println("Linha " + ++contLinha + " - " +
								contPalavra + " palavras - " +
								contTag + " tags validas (" + tags + ") - " +
								contTInvalido + " tags invalidas");
								
		}

	}
}

/** Classe para percorrer e retornar separadamente cada linha do texto*/
class Texto {

	StringTokenizer st;

	public Texto (String txt) {
		st = new StringTokenizer(txt, "\n");
	}

	public String proxima() {
		if (st.hasMoreTokens()){
			return st.nextToken();
		} else {
			return "";
		}
	}
}

/** Classe para percorrer e retornar separadamente cada palavra de cada linha*/
class Frase {

	StringTokenizer st;

	public Frase (String linha) {
		st = new StringTokenizer(linha);
	}

	public String proxima() {
		if (st.hasMoreTokens()){
			return st.nextToken();
		} else {
			return "";
		}
	}
}

/**Classe com um metodo para avaliar se uma palavra � um tag ou um tag invalido*/
class Palavra {
	public String avalia(String pl) {

		if (pl.indexOf('<', 1) == -1 &&  pl.lastIndexOf('>', pl.length() - 2) == -1) {
			if (pl.charAt(0) == '<' && pl.charAt(pl.length() - 1) == '>') {
				return "valido";
			} else if (pl.charAt(0) != '<' && pl.charAt(pl.length() - 1) != '>') {
				return "normal";
			} else {
				return "invalido";
			}
		} else {
			return "invalido";
		}
	}
}