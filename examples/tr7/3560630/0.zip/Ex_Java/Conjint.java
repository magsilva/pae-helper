/**Exerc�cio 1.2*/
 
import java.util.*;

class Inteiros{
	private Vector conj_int;
	Inteiros(){ // construtor
		conj_int = new Vector();
	}	
	void adiciona(int x){
		if (!conj_int.contains(new Integer(x)))
			conj_int.addElement(new Integer(x));	
		//mensagem dada quando tenta inserir um elemento que jah esta no conjunto
		else System.out.println(x + " jah estah no conjunto");
	}

	void remove(int x){
	//remove todas as ocorrencias do elemento x 
		while (conj_int.contains(new Integer(x)))
			conj_int.remove(new Integer(x));
	}
	
	void uniao(Inteiros x, Inteiros y){
	//faz a uniao de x com y 
		int tam1 = x.conj_int.size();
		int tam2 = y.conj_int.size();
		
		for(int i=0; i < tam1; i++)
			this.conj_int.addElement(x.conj_int.get(i));
		for(int i=0; i < tam2; i++){
			if (!this.conj_int.contains(y.conj_int.get(i)))
				this.conj_int.addElement(y.conj_int.get(i));
		}
	
	}
	void interseccao(Inteiros x, Inteiros y){
	//faz a interseccao de x com y
		int tam1 = x.conj_int.size();
		int tam2 = y.conj_int.size();
	
		//ver se os elementos de x estao em y
		for(int i=0; i < tam1; i++){
			if (y.conj_int.contains(x.conj_int.get(i)))
				this.conj_int.addElement(x.conj_int.get(i));
		}
		for(int i=0; i < tam2; i++){
			if (x.conj_int.contains(y.conj_int.get(i)) && !this.conj_int.contains(y.conj_int.get(i)))
				this.conj_int.addElement(y.conj_int.get(i));
		}
				
	}

	void subtracao(Inteiros x, Inteiros y){
		int tam1 = x.conj_int.size();
		for(int i = 0; i < tam1; i ++){
			if (!y.conj_int.contains(x.conj_int.get(i)))
				this.conj_int.addElement(x.conj_int.get(i));
		}
	}
	
	void imprime(String nome){
		System.out.println("-------------------------------");
		System.out.println("Elementos do conjunto " + nome + ":");
		System.out.println(this.conj_int);
	}

}

public class Conjint{
	public static void main(String[] args){
		Inteiros a = new Inteiros();
		//insercao de elementos no conjunto a
		a.adiciona(1);
		a.adiciona(2);
		//segunda insercao do elemento 2,
		//mensagem que este conjuto jah possui o elemento 2 sera dada
		a.adiciona(2);
		a.adiciona(3);
		a.adiciona(4);
		a.adiciona(69);
		a.adiciona(56);
		a.adiciona(34);
		//remocao de dois elementos
		a.remove(4);
		a.remove(1);
		Inteiros b = new Inteiros();
		b.adiciona(100);
		b.adiciona(276);
		b.adiciona(26);
		b.adiciona(390);
		b.adiciona(49);
		b.adiciona(69);
		b.adiciona(56);
		b.adiciona(34);
		b.remove(69);
		b.remove(56);
		Inteiros c = new Inteiros();
		//o conjunto c recebe a uniao de a com b		
		c.uniao(a,b);
		a.imprime("a");
		b.imprime("b");
		c.imprime("c");
		Inteiros d = new Inteiros();
		//d recebe a intersecao de a com c		
		d.interseccao(a,c); 
		d.imprime("d");
		Inteiros e = new Inteiros();
		//e recebe a subtracao de c com b		
		e.subtracao(c,b);
		e.imprime("e");								

	}
}


/**Exerc�cio 1.3
 Para esta resolucao escolheriamos a classe AbstractSet do pacote java.util,
 a qual implementa a interface Set.
 Criariamos os m�todos adiciona e remove utilizando os metodos ja implementados add e remove,
 para adicionar e remover,respectivamente, um elemento no conjunto.
 Criariamos tambem o metodo imprime para retornar os elementos do conjunto
 Modificaria os m�todos addAll, retainAll e removeAll, que implementam respectivamente
 a uniao, a intersecao e a diferenca entre conjuntos. 
 As vantagens desta solu�ao em detrimento � do exercicio 1.2 � a utiliza��o de classes 
 e m�todos prontos que a linguagem java fornece, agilizando a implementa��o.
 Por outro lado deve-se tomar o devido cuidado de utilizar estes metodos para os
 propositos requeridos para que eles retornem o valores esperados*/

