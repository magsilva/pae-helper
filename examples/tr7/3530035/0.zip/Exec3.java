/* Sim, o exercicio 2 poderia ser resolvido utilizando a interface Set
por exemplo . Desse forma na implementa��o anterior eu poderia estender 
a classe ConjuntoInteiros . Eu n�o precisaria dos metodos de remocao 
e de adicao no conjunto de inteiros, pois a interface Set ja tem esses 
metodos implementados . Seria ent�o necessario apenas usar esses
metodos da interface Set.