// programa desenvolvido por:
// Sergio Pavanello Rossi N� 3530035
// Alexandre Lucas N� 3541980


import java.io.*;
import java.lang.*;

public class leitura2 

{

  
  public static void main (String[] args) 
   
   {  
      String frase = " ";
      System.out.println("Entre com a frase :");
      try {
        
	BufferedReader entrada = new BufferedReader(new InputStreamReader(System.in));
        frase = entrada.readLine();
	entrada.close();
	}
      catch (IOException e) {
        System.out.println(" ERRO!!");}
      Texto v = new Texto(frase);
      
   }
 
} 
 class Texto 
   {
     
      public int num_pal = 0 ;
     
     
      public Texto(String palavra)

     {
        int num_linhas = 1;
        int validas = 0;
        int invalidas = 0 ;
        Palavra word;
        String[] palavras;
        palavras = palavra.split(" ");
        num_pal = palavras.length;
        for (int i = 0; i < palavras.length ;i++)
          {
            word = new Palavra(palavras[i]);
            invalidas += word.tags_inv;
            validas += word.tags_v;
          }
     System.out.println("Linha " + num_linhas + " - " + num_pal + " palavras - " + validas + " tags valida(s) - " + invalidas + " tags invalida(s)."); 

     }
 
    }
  
 class Palavra
 {
 	 public  int pos_abre = -1;
   	 public  int pos_fecha = -1;
 	 public  int tags_inv = 0;
     public  int tags_v = 0;
     
 	 public Palavra(String entrada)
 	 {
 	 
 	  	 
 	 	 pos_fecha = entrada.indexOf(">");
 	 	 pos_abre = entrada.indexOf("<");
 	 	  
 	 	
 	   if (((pos_abre != -1) && (pos_fecha != -1)) && (pos_abre < pos_fecha))
 	     tags_v += 1;
 	   if ((pos_fecha != -1) || (pos_fecha < pos_abre))
 	     tags_inv +=1;    	       
 	 }
 } 	 	          