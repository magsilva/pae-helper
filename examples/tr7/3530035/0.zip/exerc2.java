// programa desenvolvido por:
// Sergio Pavanello Rossi N� 3530035
// Alexandre Lucas N� 3541980


import java.io.*;
import java.lang.*;
import java.util.*;

public class exerc2
{
  public static void main(String[] Args)
  {
    ConjuntoInteiros novo;

   novo = new ConjuntoInteiros("1 2 3  5 6");
// testa as operacoes com os dados
   novo.adicao(10);
   novo.remove(3);
   novo.mostra();
  }
}

class ConjuntoInteiros
{
  int[] numeros ;
  int[] vetor_num ;
  
 //classe construtora
  public ConjuntoInteiros(String entrada)
  {
    int i,tamanho, j = 0;
    transforma(entrada); // metodo definido depois
    tamanho = vetor_num.length; // tamanho do vetor
    numeros = new int[tamanho]; // preve tamanho do vetor de inteiros

    for (i = 0; i < tamanho; i++)
      if (!Existe(vetor_num[i], tamanho)) // naum permite q sejam inseridos na lista valores repitidos
      {
        numeros[j] = vetor_num[i];
        j++;
      }

  }

// verifica se numero ja esta na lista e retorna valor booleano
  protected boolean Existe(int num, int tamanho)
  {
    boolean resultado = false;
    int i; 
    for (i = 0; i < tamanho; i++)
          if (numeros[i] == num)
             resultado = true;

    return resultado;
  }
  
// faz a transformacao do vetor de string em vetor de inteiros
  protected void transforma(String entrada)
  {
    String[] novo_vetor;
    Double aux;
    int i, tamanho;

    novo_vetor = entrada.split(" ");
    tamanho = novo_vetor.length;
    vetor_num = new int[tamanho];

    for (i = 0; i < tamanho; i++)
   {
      try // tranformacao
      {aux = Double.valueOf(novo_vetor[i]);
        vetor_num[i] = aux.intValue();}
      catch (Exception erro)
      {System.out.println("Tipo invalido de dados");}
    }
  }

//metodo de remocao na lista
  protected void remove(int entrada)
  {
    int ind_remocao = -1;
    int tamanho = numeros.length;
    int i;    
 	
    for (i = 0; i < tamanho; i++)
      if (numeros[i] == entrada)
    ind_remocao = i;
  	    
    if (ind_remocao != -1) // naum achou numero na lista
      numeros[ind_remocao] = -999;
  	  
  }

// matodo de adicao na lista
  protected void adicao(int entrada)
  {
    int i, tamanho, ind_adicao = -1;
    int[] antigo;
    boolean existe = false;

    tamanho = numeros.length;
    for (i = 0; i < tamanho; i++)
      if (numeros[i] == entrada)  // teste para verificar se o numero eh repetido
        existe = true;

    if (!existe)
    {
      antigo = new int[tamanho];
      for (i = 0; i < tamanho; i++)
        antigo[i] = numeros[i];
      numeros = new int[tamanho+1]; //novo tamanhodo vetor
      for (i = 0; i < tamanho; i++)
        numeros[i] = antigo[i];
      numeros[tamanho] = entrada;
    }           
  }

  protected void mostra() // mostra na tela 
  {
    int i, tamanho = numeros.length;
    for (i = 0; i < tamanho; i++)
      if (numeros[i] != -999)
        System.out.println(numeros[i]);
  }


}