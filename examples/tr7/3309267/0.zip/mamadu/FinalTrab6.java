/*
    AUTORIA DE :Mamad� Bubacar Da Silva Bald�   N� 3538162
                Alecio Elias Vitiello           N�3309267
                
                Trabalho 6 
*/

import java.util.*;
import java.io.*;
class ConjuntoInteiros{
	ArrayList ArrayOfData1;
	ArrayList ArrayOfData2;
	String StringOfData;
	
	public ConjuntoInteiros(){
		this.ArrayOfData1 = new ArrayList();
		this.StringOfData = new String();
		this.ArrayOfData2 = new ArrayList();
		
	}
	
	public void SetData(String StringOfData2, String StringOfData22){
		this.ArrayOfData1.add(StringOfData2);
		this.ArrayOfData2.add(StringOfData22);
		   
	}
	
	public void Intersecao(){
		int i = 0;
		ArrayList InterArray = new ArrayList();
		while (i <= this.ArrayOfData1.size()-1){
			InterArray.add(this.ArrayOfData1.get(i));
			InterArray.add(this.ArrayOfData2.get(i));
			i++;
		}
		
		System.out.println(" INTERSECCAO : ");
		System.out.println(InterArray);
	}
	
	public void Uniao(){
		ArrayList UniaoArray = new ArrayList();
		UniaoArray.add(this.ArrayOfData1);
		UniaoArray.add(this.ArrayOfData2);
		
		System.out.println(" UNIAO : ");
		System.out.println(UniaoArray);
	}
	
	public void Subtracao(){
		    ArrayList SubArray = new ArrayList();
			SubArray.add(ArrayOfData2);
			System.out.println("            ");
			System.out.println(" SUBTRACAO  ");
			System.out.println(SubArray);
		}
		
	
}//fim da classe conjunto inteiros

class FinalTrab6{
	public static void main(String[] args){
		
		ArrayList ArrayOfData1 = new ArrayList();
		ArrayList ArrayOfData2 = new ArrayList();
		
		String StringOfData1 = new String();
		String StringOfData2 = new String();
		String StringOfData11 = new String();
		String StringOfData22 = new String();
		
		int[] vetLastNumber1 = new int[20];
		int[] vetLastNumber2 = new int[20];
		
		int TransData1,TransData2=0, achou=0;
		
		BufferedReader inReader;
		inReader = new BufferedReader( new InputStreamReader(System.in));
		ConjuntoInteiros C = new ConjuntoInteiros();
		  for (int i = 0; i < 20; i++){
		     vetLastNumber1[i] = 0;
		     vetLastNumber2[i] = 0;
		    }
		     
		    
		    int j =0;
			while (TransData2 != -1){
				System.out.println(" MENSAGEM DE AJUDA!");
				System.out.println("              ");
				System.out.println(" Digite -1 para terminar carregar as listas");
				System.out.println("*******************************************");
				try{
					achou = 0;
				System.out.print(" Entre com elemento para a primeira lista : ");
				StringOfData1 = inReader.readLine();
				System.out.print(" Entre com elemento para a segunda lista : ");
				StringOfData11 = inReader.readLine();
				StringOfData2 = StringOfData1;
				StringOfData22 = StringOfData11;
				TransData1 = Integer.parseInt(StringOfData1);
				TransData2 = Integer.parseInt(StringOfData11);
				for (int LastNumber =0 ; LastNumber < 20; LastNumber++)
				    if ((vetLastNumber1[LastNumber] == TransData1) || (vetLastNumber2[LastNumber]==TransData2)){
				    	System.out.println(" Voce digitou um numero que jah existe na lista ");
				    	System.out.println(" Tecle uma tecla para continuar ");
				    	LastNumber = 20;
				    	achou = 1;
				    }
   	            if (achou == 1){
   	            	
   	            }
			    else{
				      ArrayOfData1.add(StringOfData2);
				      ArrayOfData2.add(StringOfData22);
				      C.SetData(StringOfData2,StringOfData22);
				      vetLastNumber1[j] = TransData1;
				      vetLastNumber2[j] = TransData2;
				      j++;
				     } 
			
					
			
		}catch (IOException e){
			System.err.println(e.getMessage());
		}
		
		
		
		
	}//fim do enquanto
	
	C.Uniao();
	C.Intersecao();
	C.Subtracao();
		 System.exit(0);
	}
	
}