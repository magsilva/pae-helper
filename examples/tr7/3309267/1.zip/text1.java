/*
    AUTORIA DE : 
               Mamad� Bubacar Da Silva Bald�         N� 3538162
               Alecio Elias Vitiello                 N� 3309267
               
               
     FUN��O GLOBAL DO PROGRAMA : 
               Este programa tem a fun��o de implementar o exerc�cio pedido na lista de 
                    exerc�cio 6. Ou seja tratar um texto passado como par�metro; cada linha deste texto ser�
                    uma frase, sendo esta composta por palavras(separadas por brancos). As palavras, por sua vez,
                    podem ser tags(delimitadas por "<" e ">"). AS tags inconsistentes (n�o apropriadamente
                    delimitadas por "<" ou ">") devem ser identificaveis.                      
                    
Professora : Renata Pontin
Monitor :    Marcos                    
                 
*/

import java.util.ArrayList;
import javax.swing.JOptionPane;
import java.util.StringTokenizer;  /* pacotes que serao utilizados */

/* classe text*/
public class text1{
	public static void main(String[] args){
		  String AuxStringData;
		  int AuxMaxNumberOfLine;
		  String Entered, EnterData;
	      AuxStringData = JOptionPane.showInputDialog(" ENTRE COM MAXIMO DE LINHAS DO TEXTO QUE VOC� DIGITAR� ");
	      AuxMaxNumberOfLine = Integer.parseInt(AuxStringData);
          int LineNumber = 1; 	
	      while(LineNumber <= AuxMaxNumberOfLine){
	            Entered = JOptionPane.showInputDialog("Entre com a frase "+LineNumber);
     	        EnterData = Entered;
     	        System.out.print("Linha "+LineNumber+"-  ");
     	        Frase F = new Frase(EnterData);
     	        LineNumber++;
	       }
	
			
			System.exit(0);
	}
}
class Frase{
	int countWords;
	ArrayList ArrayOfFrase = new ArrayList();
	public Frase(String EnterData){
		ArrayList ListOfWords = new ArrayList();
		this.countWords =0;
		this.ArrayOfFrase.add(EnterData);
		StringTokenizer wordToken = new StringTokenizer(EnterData, " ");
		while (wordToken.hasMoreTokens()){
		       ListOfWords.add(wordToken.nextToken());	
		       this.countWords++;
		}
		
		Word  W = new Word(ListOfWords);
		System.out.print(" "+this.countWords+"  palavras-  ");
		System.out.print(": "+W.Valid_Tags()+"  Tags validas  (");
		for (int i=1; i <=W.Valid_Tags(); i++){
			System.out.print(W.GetValidTags(i));
		}
		System.out.print(")-   ");
		System.out.println("  "+W.Invalid_Tags()+"  Tags Invalidas");
		
	}
	
	

}


class Word{
	
	int Number_Of_Valid_Tags, Number_Of_Invalid_Tags;
	String[] Tags;
	ArrayList ArrayOfWords = new ArrayList();
	
	public Word(ArrayList EnteredData){
		   String Entered = new String(); 
		   Tags = new String[100];
		   for (int i=0; i < EnteredData.size(); i++)  {
		   	   Entered = (String)EnteredData.get(i);
		   	   if (Entered.indexOf('<')==0 && Entered.indexOf('>')==(Entered.length()-1)){
		   	   	      Number_Of_Valid_Tags++;
		   	   	      Tags[Number_Of_Valid_Tags] = Entered;
		   	   }
		   	   else{
		   	   	     if (Entered.indexOf('<')==0 || Entered.indexOf('>')==(Entered.length()-1))
		   	   	             Number_Of_Invalid_Tags++;
		   	   	    }
		   	   }
		   	   
		   	   
		   }
		     
		   
	
	
	public int GetNumberOfWords(){
		int NumberOfWord = this.ArrayOfWords.size();
		return (NumberOfWord); /* retornando o numero de palavras da frase */
	}
	
	public String GetValidTags(int i){
		    return (this.Tags[i]);/* retornando os tags */
		    
	}
	
	public int Valid_Tags(){
		
		return (Number_Of_Valid_Tags); /* retornando o numero de tags validas */
	}
	
	public int Invalid_Tags(){
		
		return (this.Number_Of_Invalid_Tags); /* retornando o numero de tags invalidas */
	}
}


