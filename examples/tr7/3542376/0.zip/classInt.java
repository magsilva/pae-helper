// Desenvolvido por LUIZ CARLOS GENOVES JR.
//		    KATSUMI ARACKAWA JR.

// Data do desenvolvimento: 28/05/2003, SCE-213

// 2.1: O programa abaixo define uma classe "conjunto de inteiros", que contem uma lista
//      de numeros inteiros. Faz entre objetos desta classe operacoes basicas de conjuntos
      
	
class ConjInt {
  
  private int[] lista = new int[100];
  private int Nelem = 0;
  
  ConjInt ()  {  
  }
  
  ConjInt (int[] l) 
  {
    int i;
    for (i = 0; i < l.length; i++) {
      this.lista[i] = l[i];
    }
    this.SetMax(i);
    //System.out.println("Elementos na lista" + i);
  }

  ConjInt (ConjInt A)
  {
    this.Recebe (A);
  }

  private void SetMax(int x)
  {
    this.Nelem = x;
  }

  private void Print()
  {
    int i;
    String s;
    s = "";
    for (i = 0; i < this.Nelem; i++)
      s += lista[i] + ", ";
    s += "Elem na Lista: " + this.Max();
    System.out.println(s);
  }
  
  private void Add (int Number)
  {
    if (this.Contem(Number))
      return;
    this.lista[this.Max()] = Number;
    this.SetMax( this.Max() + 1 );
  }

  private int Elem(int i)
  {
    return this.lista[i];
  }
  
  private int Max()
  {
    return this.Nelem;
  }
  
  private boolean Contem(int x)
  {
    int i;
    for (i = 0; i < this.Max(); i++)
      if ( this.Elem(i) == x)
        return true;
    return false;
  }
  
  private void Recebe ( ConjInt A)
  {
    int i;
    this.Nelem = A.Max();
    for (i = 0; i < A.Max(); i++)
      this.lista[i] = A.Elem(i);
  }

  private void Inter(ConjInt A, ConjInt B)
  {
    int i;
    ConjInt interAB = new ConjInt();
    if (A.Max() < B.Max() ) {
      for (i=0; i < A.Max(); i++)
        if ( B.Contem( A.Elem(i) ) )
          interAB.Add ( A.Elem(i) );
    } else {
      for (i=0; i < B.Max(); i++)
        if ( A.Contem( B.Elem(i) ) )
          interAB.Add ( B.Elem(i) );
    }
  this.Recebe( interAB );
  }
  
  private void Sub (ConjInt A, ConjInt B)
  {
    int i;
    ConjInt C = new ConjInt();
    for (i = 0; i < A.Max(); i++)
      if ( !B.Contem( A.Elem(i) ) )
        C.Add(A.Elem(i) );
  this.Recebe( C );
  }
  
  private void Uniao( ConjInt A , ConjInt B)
  {
    int i;
    //cria um conjunto C com todos os elementos de A e B
    for (i = 0; i < B.Max(); i++)
      if (! A.Contem ( B.Elem(i) ) )
        A.Add( B.Elem(i) );
    this.Recebe( A );
  }
            


  public static void main(String args[]) 
  {
    ConjInt A = new ConjInt();
    A.Add(5);
    
    A.Print();
    int l[] = {1,2,3,5,9};
    ConjInt B = new ConjInt(l);
    ConjInt C = new ConjInt(B);
    
    B.Print();
    
    B.Inter(A,B);
    B.Print();
    
    B.Uniao(B,C);
    B.Print();
    
    A.Sub(B, A);
    A.Print();
  }
}