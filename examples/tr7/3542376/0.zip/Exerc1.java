import java.lang.*;

public class Exerc1 {
	
	public static void main( String args[] ){
		
	String Texto;
	Texto="O rato >roeu a roupa do rei> de <Roma>. A Rainha de <raiva> roeu o <resto>." ;
	Tag t=new Tag(Texto);
	t.imprime();
	Frase f=new Frase(Texto);
	f.imprimefrase();
	Palavra p=new Palavra(Texto);
	p.imprimepalavras();
	}
}	

class Tag{
	StringBuffer tagcorreta;
	String[] palavras;
	String texto;
	char caracteres[];
	int limite, k=0, j=0, tagerr=0, maior=0, menor=0;
	 
	Tag(String text){
		texto =text;
		}
	void imprime(){
		tagcorreta = new StringBuffer();
		palavras = this.texto.split("\\s");
		
		caracteres = this.texto.toCharArray(); 
		limite = caracteres.length;		
		
		while(k<limite){
		if (caracteres[k]=='<'){
			j=k;
			while (caracteres[j]!='>'){
				tagcorreta.append(caracteres[j]);
				j++;
				}
			if (caracteres[j]=='>'){
				tagcorreta.append(caracteres[j]);}
				
			k=j;
			}
		k++;
		}
		for(k=0;k<limite;k++){
			if (caracteres[k]=='<'){
				menor+=1;
				}
			if (caracteres[k]=='>'){
				maior+=1;
				} 
			}
		if (maior>menor){
			tagerr=maior-menor;
			}
		else
		tagerr=menor-maior;
		
		System.out.println("Numero de Tags invalidas: "+ tagerr);
		System.out.println("Tags Corretas: " );
		System.out.println(tagcorreta + "\n");
		
		}
	
	}

class Frase {
	String texto;
	char caracteres[];
	int k, limite, contfrase;
	
	Frase(String text){
		texto =text;
		}
	void imprimefrase(){	
	caracteres = this.texto.toCharArray(); 	//armazena cada caracter em um array de char
		limite = caracteres.length;
	
	for(k=0;k<limite;k++){
			if (caracteres[k]=='.'){
				contfrase+=1;}
		}
	System.out.println("Numero de Frases: "+ contfrase );
	}
	
	
}	
class Palavra {
	String [] palavras;
	int k=0,tamanho=0,contpalavras;
	String texto;
	Palavra(String text){
		texto =text;
		}
	void imprimepalavras(){	
	palavras = this.texto.split("\\s");
	tamanho=palavras.length;
	
	System.out.println("Palavras classificadas: " );
	for(k=0;k<tamanho; k++){
		System.out.println(palavras[k]);
		}
	System.out.println("Numero de palavras: "+ k);
	}
}

