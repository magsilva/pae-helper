import java.util.*;
import java.io.*;

class ConjuntoInteirosModif extends Vector
{	
	private int numero;
	TreeSet vetor;
	
	public ConjuntoInteirosModif()
	{
		vetor = new TreeSet();
	}


	public void adicionar (int numero)
	{
		Integer integ = new Integer(numero);
		vetor.add(integ);
	}
	

	public void remover(int numero){
		Integer integ = new Integer(numero);
		vetor.remove(integ);
	}

	public void print(){
		System.out.println("Esse eh o vetor: " + vetor);
	}

	public TreeSet uniao(ConjuntoInteirosModif conjB){  //vetor inteiros
		vetor.addAll(conjB.vetor);
		return vetor;
		
	}

	public TreeSet interseccao(ConjuntoInteirosModif conjB){
		vetor.retainAll(conjB.vetor);
		return vetor;
	}

	public TreeSet subtracao(ConjuntoInteirosModif conjB){
		vetor.removeAll(conjB.vetor);
		return vetor;
	}

	public static void main(String[] args){
		ConjuntoInteirosModif a = new ConjuntoInteirosModif();
		ConjuntoInteirosModif b = new ConjuntoInteirosModif();
		TreeSet c = new TreeSet();
		a.adicionar(10);
		a.adicionar(20);
		a.adicionar(30);
		b.adicionar(10);
		b.adicionar(20);
		b.adicionar(30);
		b.adicionar(40);
		b.remover(30);
//		a.print();			p/ testar basta escolher um desses metodos da classe
//		b.print();			
//		c = a.uniao(b);
//		c = a.interseccao(b);
//		c = a.subtracao(b);		
		System.out.println(c);
	}
	
}