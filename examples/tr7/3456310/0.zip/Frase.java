class Frase{
	public String[] palavras;
	public String frase;


	public Frase(String bla){
		frase=bla;

	}

	public String[] separa(){
		palavras = frase.split(" ");
		return palavras; 
		
	}
}




