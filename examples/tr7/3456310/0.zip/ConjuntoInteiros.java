import java.util.*;
import java.io.*;


// no vetor naum eh possivel a inser�ao do numero 100000, pois esse eh utilizado p/ indicar q a posi�ao eh vazia

class ConjuntoInteiros extends Vector
{	
	private int numero;
	Vector vetor;
	public ConjuntoInteiros()
	{
		vetor = new Vector(100);
	}


	public void adicionar (int numero)
	{
		Integer integ = new Integer(numero);
		if (vetor.contains(integ))
				System.out.println("Jah existe esse numero no vetor");
		else vetor.addElement(integ);

	}
	

	public void remover(int numero){
		int len;
		len = vetor.size();
		Integer integ = new Integer(numero);
		if (vetor.contains(integ))
			vetor.removeElement(integ);
		else System.out.println("Esse numero nao pertence ao vetor");
	}

	public void imprimir(){
		System.out.println("Esse eh o vetor: " + vetor);	
	}


//---------------(Faz a uniao dos 2 vetores)-----------=============
	public Vector uniao(ConjuntoInteiros conjB){
		int len,i;
		Object inteir = new Object();
		len = conjB.vetor.size();
		for(i=0;i<len;i++){
			inteir = conjB.vetor.elementAt(i);
			if (vetor.contains(inteir) == false){
				vetor.addElement(inteir);
			}
		}		
		return vetor;
	}
		




//-----------==(Faz a interseccao dos 2 vetores)============----------==========
	public Vector interseccao(ConjuntoInteiros conjB){
		int len,i;
		Vector vetorC = new Vector(100);
		Object inteir = new Object();
		len = conjB.vetor.size();
		for(i=0;i<len;i++){
			inteir = conjB.vetor.elementAt(i);
			if (vetor.contains(inteir))
				vetorC.addElement(inteir);
		}
		return vetorC;
	}


//---------=====(Faz a subtra�ao do vetor A com o vetor B)---------==========
	public Vector subtracao(ConjuntoInteiros conjB){
		int len,i;
		Object inteir = new Object();
		len = conjB.vetor.size();
		for(i=0;i<len;i++){
			inteir = conjB.vetor.elementAt(i);
			if (vetor.contains(inteir))
				vetor.removeElement(inteir);
		}
		return vetor;
	}


	
//------===========(fun�ao main)=--------==========-------------====
	public static void main(String[] args){
		ConjuntoInteiros a = new ConjuntoInteiros();
		ConjuntoInteiros b = new ConjuntoInteiros();
        Vector c = new Vector();
		a.adicionar(10);
		a.adicionar(20);
		a.adicionar(40);
		a.adicionar(50);
		b.adicionar(10);
		b.adicionar(30);
		b.adicionar(40);
		b.remover(40);
//		a.imprimir();
//		c = a.uniao(b);			basta escolher um desses metodos para rodar
//		c = a.interseccao(b);
//		c = a.subtracao(b);
		System.out.println(c);
	
	}
	
}
