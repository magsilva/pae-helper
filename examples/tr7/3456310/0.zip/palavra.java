class Palavra{
        boolean aux;
        public int tag_perf = 0;
	public int tag_imp = 0;
	public int palavras = 0;
	public String palavra;
	public Palavra(String blo){
		palavra=blo;

	}
	public void Conta(){
		if (palavra.charAt(0) == '<'){
                        if (palavra.charAt((palavra.length())-1) == '>' && ((palavra.indexOf('>') < (palavra.length()-1)) || palavra.indexOf('<') > (0))){
				tag_imp = 1;
                                palavras = 1;
			}
			else if((palavra.charAt(palavra.length()-1) == '>')){
                                tag_perf = 1;
                                palavras = 1;
			}
                        else {tag_imp = 1;
                            palavras = 1;
                        }
		}
		else if (palavra.charAt((palavra.length())-1) == '>'){
			if (((palavra.charAt(0) == '<'))&& ((palavra.indexOf('>') < (palavra.length()-1)) || palavra.indexOf('<') > (0)) ){
				tag_imp = 1;
                                palavras = 1;
			}
			else if (palavra.charAt(0) == '<'){
				tag_perf = 1;
                                palavras = 1;
			}
                        else {tag_imp = 1;
                        palavras = 1;
                        }                        
               }
                else palavras = 1;
	}
}
