

public class Principal{

	public static void main(String args[]){
		
		String[] frase;
		String palavras;
		String[] textos= {"Teste de palavras e <Tags>","Teste de problemas com <tags> <perfeitas> e <imperfeitas e <<imperfeitas>>"};
		for (int a = 0 ; a <= ((textos.length) - 1) ; a++){
			int nu_tag_perf = 0;
			int nu_tag_imp = 0;
			int nu_palavras = 0;
			Frase frases= new Frase(textos[a]);
			frase = frases.separa();
			Palavra palavra;
			for (int b = 0 ; b <= ((frase.length) - 1) ; b++){
				palavra = new Palavra(frase[b]);
				palavra.Conta();
				if ((palavra.tag_perf == 1)&&(palavra.palavras ==1)){
					nu_tag_perf ++;
                                        nu_palavras ++;
				}
				else if ((palavra.tag_imp == 1)&&(palavra.palavras ==1)){
					nu_tag_imp ++;
                                        nu_palavras ++;
				}
                                else nu_palavras ++;	
			}
			System.out.println("Frase " + (a+1) + ": " + nu_palavras + " palavra(s) - " + nu_tag_perf + " tag(s) perfeitas - " + nu_tag_imp + " tag(s) imperfeitas");	
		}
		
			
	}


}