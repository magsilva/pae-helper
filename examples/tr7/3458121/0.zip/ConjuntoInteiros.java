/*
Exerc�cio 1.2 - Classes
Nome: M�nica Ribeiro Porto Ferreira - 3458121
Profa. Renata Pontin - Programa��o Orientada � Objetos
*/
import java.io.*;
import javax.swing.*;

public class ConjuntoInteiros {
	public static void main(String[] args){
		
		int[] c1 = new int[50];
		int[] c2 = new int[50];
		int[] c3 = new int[100];

		int opint,aux=0,i=0,j=0,k=0,m=0,ai;
		boolean val,menu;
			
		String a,op,output;
		menu = true;
		while(menu)
		{
				a = JOptionPane.showInputDialog("Digite a op��o desejada: "
												+ "\n1-Criar um novo Conjunto Base de Numeros Inteiros"
												+ "\n2-Adicionar um Inteiro no Conjunto"
												+ "\n3-Remover um Inteiro"
												+ "\n4-Realizar a Uni�o com outro Conjunto"
												+ "\n5-Realizar a Intersec��o com outro Conjunto"
												+ "\n6-Realizar a Subtra��o de Conjunto"
												+ "\n7-Imprimir os numeros do Conjunto Base"
												+ "\n8-Sair");
				ai = Integer.parseInt(a);
				val = false;
				switch(ai){
					case 1: 	for (j=0;j<50;j++)
									c1[j] = 0;
								opint = 100;
								while((opint < 0)||(opint > 50)){
									op = JOptionPane.showInputDialog("Quantos elementos tem o conjunto? <0 - 50>");
									opint = Integer.parseInt(op);
								}
								for (j = 0; j<opint; j++){
									k=j+1;
									c1[j] = Integer.parseInt(JOptionPane.showInputDialog("Entre com o " + k + "o elemento:"));
								}
								menu = true;
								break;
					
					
					
					
					case 2:		if (j<99){
									k=j+1;
									aux = Integer.parseInt(JOptionPane.showInputDialog("Entre com o " + k + "o elemento:"));
									for (i=0; i<j; i++)
										if (aux == c1[i])
											val = true;
									if(!val){
										
										c1[j]=aux;
										JOptionPane.showMessageDialog(null,"Elemento inserido com sucesso!");
										j++;
									}
									else
										JOptionPane.showMessageDialog(null,"Elemento j� existe!");
								}
								else
									JOptionPane.showMessageDialog(null,"O array est� cheio!");
								menu = true;
								break;	
					
					
					
					case 3:		if(j>0){
									
									aux = Integer.parseInt(JOptionPane.showInputDialog("Entre com o elemento a ser removido:"));
									i=0;
									while((i<=j)&&(!val))
										if (aux == c1[i])
											val = true;
										else
											i++;
									if(val){
										for(k=i;k<j;k++)
											c1[k] = c1[k+1];
										c1[j] = 0;
										j--;
										JOptionPane.showMessageDialog(null,"Elemento Removido com sucesso!");
									}
									else
										JOptionPane.showMessageDialog(null,"Elemento n�o existe!");
								}
								else
									JOptionPane.showMessageDialog(null,"O array est� vazio!");
								menu = true;
								break;	
					
					
					
					case 4:		for (k=0;k<50;k++)
									c2[k] = 0;
								for (k=0;k<100;k++)
									c3[k] = 0;
								opint = 100;
								while((opint < 0)||(opint > 50)){
									op = JOptionPane.showInputDialog("Quantos elementos tem o 2o conjunto? <0 - 50>");
									opint = Integer.parseInt(op);
								}
								for (k = 0; k<opint; k++){
									m=k+1;
									c2[k] = Integer.parseInt(JOptionPane.showInputDialog("Entre com o " + m + "o elemento:"));
								}
								for (i=0;i<j;i++)
									c3[i]=c1[i];
								for(m=0;m<opint;m++){
									for(k=0;k<=j;k++)
										if(c2[m]==c1[k])
											val=true;
									if(!val){
										
										c3[i]=c2[m];
										i++;
									} val = false;
								}
								output = "UNI�O: ";
								for(k = 0;k < i;k++)
									output += c3[k] + " ";
								JOptionPane.showMessageDialog(null,output);
								menu = true;
								break;
					
					
					case 5:		for (k=0;k<50;k++)
									c2[k] = 0;
								for (k=0;k<100;k++)
									c3[k] = 0;
								opint = 100;
								while((opint < 0)||(opint > 50)){
									op = JOptionPane.showInputDialog("Quantos elementos tem o 2o conjunto? <0 - 50>");
									opint = Integer.parseInt(op);
								}
								for (k = 0; k<opint; k++){
									m=k+1;
									c2[k] = Integer.parseInt(JOptionPane.showInputDialog("Entre com o " + m + "o elemento:"));
								}
								i=0;
								for(m=0;m<opint;m++){
									for(k=0;k<=j;k++)
										if(c2[m]==c1[k])
											val=true;
									if(val){
										c3[i]=c2[m];
										i++;
									} val = false;
								}
								output = "INTERSEC��O: ";
								for(k = 0;k < i;k++)
									output += c3[k] + " ";
								JOptionPane.showMessageDialog(null,output);
								menu = true;
								break;
					
					
					
					case 6:		for (k=0;k<50;k++)
									c2[k] = 0;
								for (k=0;k<100;k++)
									c3[k] = 0;
								opint = 100;
								while((opint < 0)||(opint > 50)){
									op = JOptionPane.showInputDialog("Quantos elementos tem o 2o conjunto? <0 - 50>");
									opint = Integer.parseInt(op);
								}
								for (k = 0; k<opint; k++){
									m=k+1;
									c2[k] = Integer.parseInt(JOptionPane.showInputDialog("Entre com o " + m + "o elemento:"));
								}
								i=0;
								for(k=0;k<j;k++) {
									for(m=0;m<opint;m++)
										if(c2[m]==c1[k])
											val=true;
									if(!val){
										c3[i]=c1[k];
										i++;
									} val = false;
								}
								output = "SUBTRA��O: ";
								for(k = 0;k < i;k++)
									output += c3[k] + " ";
								JOptionPane.showMessageDialog(null,output);
								menu = true;
								break;
					
					
					
					case 7:		output = "CONJ. BASE: ";
								for(i = 0;i < j;i++)
									output += c1[i] + " ";
								JOptionPane.showMessageDialog(null,output);
								menu = true;
								break;
								
								
								
					case 8:		menu = false;
								break;
								
								
								
					default :	JOptionPane.showMessageDialog(null,"Opc�o Inv�lida!");
								menu = true;
								break;
				}
		}
		
		
		
		
	}				

}