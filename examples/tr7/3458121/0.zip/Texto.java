import java.io.*;
import java.util.*;

public class Texto {
	
public Texto() 
	{
	}	
	
public int contaPalavras(String x) {
		StringTokenizer tokens = new StringTokenizer(x);
		return tokens.countTokens();
}


public void contagem() 
	{
		try {
			DataInputStream in = new DataInputStream (
								  new BufferedInputStream(
								  	new FileInputStream("texto.txt")));
			String linha;
			char linhaArray[];
			String buffer = new String();
			linha = in.readLine();
			
			int l = 1;
			int i,j;
			int tv = 0, ti = 0;
			
			
			if (linha != null){
				linhaArray = linha.toCharArray();
				for (i=0; i<linha.length(); i++){
					if (linhaArray[i].equals("<")){
						j=i+1;
						while ((linhaArray[j].equals(" "))&&(j<linha.length())) {
							if (linhaArray[j].equals(">"))
								tv++;								
							else
								ti++;
							j++;	
						}
					}
				}
				System.out.println("linha " + l + ": " + this.contaPalavras(linha) + " palavras, "
				       				+ tv + " tags validas, " + ti + " tags invalidas.");
			}
						
			while (linha != null) {
				buffer += linha + "\n";
				linha = in.readLine();
				tv = 0;
				ti = 0;
				if (linha != null) 
					{
					  l++;
					  
					  //
					  
					  System.out.println("linha " + l + ": " + this.contaPalavras(linha) + " palavras, "
									+ tv + " tags validas, " + ti + " tags invalidas.");

				}
			}
			
			in.close();

			}
			catch (IOException exc) {
				System.out.println("Erro de IO");
				exc.printStackTrace();
				
			}
	}	
}