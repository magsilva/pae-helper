/*

	Exercicio 3:
	
		Para resolver o problema da classe ConjuntoInteiros, eu poderia utilizar a classe 
	AbstractSet do do pacote java.util, pois essa classe ja possui os metodos de insercao 
	e remocao ja implementados. Entretanto, ainda teria que implementar as opera��es de
	uni�o, intersec��o e divis�o.
		Utilizando uma classe nativa do Java, economizamos tempo, e sua performance � muito
	boa, pois foi desenvolvida por um conjunto de programadores experientes, por�m, mesmo
	assim, ainda teria que fazer algumas modifica��es na classe, e tamb�m h� a desvantagem
	de ter que adaptar o programa que estamos fazendo � classe, o que n�o acontece quando 
	desenvolvemos a classe, j� que a idealizamos direcionada ao nosso programa. Mas agora 
	tem o problema do tempo, j� que isso leva muito mais tempo
	
*/