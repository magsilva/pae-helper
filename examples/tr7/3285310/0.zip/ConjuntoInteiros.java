/**
	Ex2:	

	Classe em java que representa o conjunto dos numeros inteiros
	juntamente com as operacoes cabiveis a ele.

	desenvovlido por:
		Rafael Henrique Manoel		3285310
*/

public class ConjuntoInteiros extends Object{

	//vari�veis membro
	private StringBuffer positivos;		//utilizando uma stringbuffer para armazenar o conjunto de
	private StringBuffer negativos;		//inteiros positivos e outra para os negativos
	

	/**
	  * Construtor padrao
	  */
	ConjuntoInteiros()
	{
		positivos = new StringBuffer();
		negativos = new StringBuffer();
		System.err.println("Conjunto criado");
	}
	

	/**
	  *	Retorna o StringBuffer dos numeros positivos
	  */
	public StringBuffer getPositive(){
		return positivos;
	}// fim getPositive


	/**
	  *	Retorna o StringBuffer dos numeros positivos
	  */
	public StringBuffer getNegative(){
		return negativos;
	}// fim getNegative
	

	/**
	 *  Adiciona o elemento X ao conjunto
	 */
	public void add(int X){
		int indP, indN;


		if (X>=0) {
			indP = buscaP(X);
			if (indP==-1 )
				positivos.append((char) X);
			else
				System.err.println("O numero " + X + " j� est� no conjunto");
		}
		else {
			X = Math.abs(X);
			indN = buscaN(X);
			if (indN==-1)
				negativos.append((char) X);
			else
				System.err.println("O numero -" + X + " j� est� no conjunto");
		}
	}// fim add


	/**
 	  * Remove o elemento X do conjunto
	  */
	public void remove(int X){
		int ind;

		//primeiro deve-se saber se o numero � positivo ou negativo
		if (X>=0) {
			//positivo
			ind = buscaP(X);			//procurando no conjunto
			if (ind > -1) 				//caso exista, entao retire-o do conjunto
				positivos.deleteCharAt(ind);
			else
				System.err.println("O n�mero "+ X +" n�o pertence ao conjunto");				
		}
		else {
			//negativo
			X = Math.abs(X);
			ind = buscaN(X);
			if (ind > -1)
				negativos.deleteCharAt(ind);
			else
				System.err.println("O n�mero -"+ X +" n�o pertence ao conjunto");
		}			
	}// fim remove


	/**
	  * Imprime o conjunto na tela
	  */
	public void print() {
		int i;

		
		System.err.println("Elementos do conjunto:");
		//imprimindo os numeros positivos
		for (i=0; i<positivos.length(); i++)
			System.out.print((int) positivos.charAt(i) + " ");
		//imprimindo os numeros negativos
        for (i=0; i<negativos.length(); i++){
			System.err.print("-" + (int)negativos.charAt(i) + " ");}

	}//fim print


	/**
	  * Funcao privada de busca na parte positiva do conjunto
	  */
	private int buscaP(int X) {
		return positivos.indexOf(String.valueOf((char) X ));
	}// fim buscaP

	/**
	  * Funcao privada de busca na parte negativa do conjunto
	  */
	private int buscaN(int X) {
		return negativos.indexOf(String.valueOf( (char) X ));
	}// fim buscaN



	//
	//	Operacoes entre conjuntos
	//
	
	/**
	  *	Operacao de uniao
	  */
	public void union(ConjuntoInteiros other){
		
		//unindo a parte positiva do conjunto
		positivos.append(other.getPositive());
		
 		//unindo a parte negativa do conjunto
		negativos.append(other.getNegative());		
	}// fim union
	
	
	/**
	  * Operacao de intersec��o
	  */
	public void intersection(ConjuntoInteiros other) {
		int i, j;				//contadores
		StringBuffer result;		//stringbuffer q contera a interseccao
		StringBuffer aux;			//stringbuffer para armazenar a stringbuffer
									//do outro conjunto
	
		result = new StringBuffer();
	
		//pesquisando em ambos objetos por inteiros iguais
		
		//primeiro para a parte positiva	
		aux = other.getPositive();
		for (i=0; i<positivos.length(); i++)
			for (j=0; j<aux.length(); j++)
				if (positivos.charAt(i) == aux.charAt(j)){
					result.append(positivos.charAt(i));
					break;
				}
		
		//trocando o velho StringBuffer de positivos pelo novo
		positivos = result;
		
		result = null;
		result = new StringBuffer();
				
	
		//agora para a parte negativa	
		aux = other.getNegative();
		for (i=0; i<negativos.length(); i++)
			for (j=0; j<aux.length(); j++)
				if (negativos.charAt(i) == aux.charAt(j)){
					result.append(negativos.charAt(i));
					break;
				}
			
		//trocando o velho StringBuffer de positivos pelo novo
		negativos = result;		
		
		result = null;

	}// fim intersec�ao
	


	/**
	  * Programa principal
	  */
	public static void main(String [] args) {
		int i;
		
		//criando algumas instancias da classe ConjuntoInteiros
		ConjuntoInteiros C1 = new ConjuntoInteiros();
		ConjuntoInteiros C2 = new ConjuntoInteiros();
		ConjuntoInteiros C3 = new ConjuntoInteiros();
		


		//
		// Alguns testes para as funcoes implementadas
		//
		
		for (i=-20; i<20; i++)
			C1.add(i);

		for (i=-20; i<20; i+=2)
			C2.add(i);

		for (i=20; i<30; i++)
			C3.add(i);

			
		C1.print();
		System.err.println("");
		C2.print();
		System.err.println("");
		C3.print();
		System.err.println("");		

		C1.intersection(C2);

		for (i=-10; i<=3; i++)
			C1.remove(i);
	
		C1.union(C3);

		C1.print();



	}
}
